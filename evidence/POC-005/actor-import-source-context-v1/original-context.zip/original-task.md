---
schemaVersion: 2
id: POC-005
title: Measure bounded metadata scanning and local OpenList source behavior
titleZh: 700TB 文件数、目录规模、变更率与扫描成本
type: chore
status: in_progress
baseBranch: main
baseSha: 746e23e582501fa08380c3f3301bdc1774902f7c
workBranch: chore/POC-005-metadata-scale
evidencePath: evidence/POC-005
issue: 132
workPackage: WP-M0-POC-05
programPlan: specs/coordination/program-plan.yaml
programTaskId: POC-005
wave: W2
requirementIds: REQ-V1-0001,REQ-V1-0002
moduleIds: MOD-SOURCE,MOD-ASSET,MOD-CONNECTOR
producesContracts: POC-05-EVIDENCE
consumesContracts: POC-PROTOCOL-V1
exitGate: POC-05 具有可复现环境、命令、原始结果、失败限制、退出决策与回滚；新增 local-v1 OpenList 与固定合成目录规模 profile，实际记录文件数/目录深度/增量扫描/版本/限流和故障；原约700TB生产规模及真实提供方 API 配额继续待测，合成样本不冒称真实规模。
taskOwner: ElectricDogCN
coordinator: program-coordinator-agent
implementer: /root
reviewer: /root/gz022_planning_independent_review
integrator: integration-agent
agentRole: implementer
riskLevel: medium
coordinationMode: registry
coordinationGroup: poc-results
dependsOn: GZ-010
handoffPath: evidence/POC-005/handoff.md
integrationStrategy: merge
integrationOrder: 3
leaseExpiresAt: 2026-10-29T16:08:44Z
---

## Current local-v1 exit/report candidate

Independent local exit pass/approved at2026-10-27T05:18:53Z is preserved in evidence/POC-005/local-v1-exit-decision-v1/independent-assessment.json. The exacted8/0101m execution has full frozen execution qualification;008/009 retain their original source identities as report support. The source-labelled scale report includes all13 measurements, actual source traversal/directory/name/change/provider costs and cleanup drift. Formal single010 result/index files now transcribe that real decision; complete profile validation and this new candidate's Task15/CI/source review/integration remain pending. Current Task stays in_progress/implementer; frozen protocols, thresholds, registration/lease and all original results remain unchanged. No production/Ready/main/Task/V1 completion is supplied. See current Evidence summary/handoff before the historical progress notes below.


## 当前已接受结项主线同步

本源将已完整接受的实际结项主线 746e23e582501fa08380c3f3301bdc1774902f7c 普通合入前序 4b17b7e4e2d9f1e48fd5b61be1600f4141aeb160，保留两条真实父线；仅刷新Own Task/Active当前base与Evidence。原请求/调用方代码字节、原13项、冻结POC协议、角色/claims/lease与全部历史失败保持，所有foreign采用已接受主线。下文旧基线和阶段文字保留原source归属，当前基线以frontmatter和本节为准。
旧4161项未跟踪fixture/raw/DB保持，不加入本次提交，不创建新007/v4fixture、服务或模板。前序D的Windows131/限定Linux57组件结果仍只归属于其原source；前序S的CI862重试因旧合成基线对新主线状态回退而实际750pass/2fail，原件保持失败；本次普通合入稳定结项主线后，新固定源15项、全新PR事件CI及完整实验前置另验。Gov主线已完整接受不等于本POC源或资格通过。


## 当前已接受代码主线同步

本源将已完整接受的实际代码主线 2a77cbf9ad838b7b7abc7fbc5ed7aaa5f2f793d4 普通合入前序 dc506b85317cdfa419d9fa6491d87eaa76e88473，保留两条真实父线；仅刷新Own Task/Active当前base与Evidence。原请求/调用方代码字节、原13项、冻结POC协议、角色/claims/lease与全部历史失败保持，所有foreign采用已接受主线。下文旧基线和阶段文字保留原source归属，当前基线以frontmatter和本节为准。
旧4161项未跟踪fixture/raw/DB保持，不加入本次提交，不创建新007/v4fixture、服务或模板。前序D的Windows131/限定Linux57组件结果仍只归属于其原source；新固定源15项、同头CI及完整实验前置另验。Gov主线已完整接受不等于本POC源或资格通过。


# POC-005 本地元数据扫描实现

## Compressed metadata output component accepted; new fixed-source qualification pending

CanonicalScanner exports plain JSONL or deterministic single-member .jsonl.gz according to each explicit output suffix. Gzip has mtime0 and no embedded filename. The three exported metadata schemas and original logical records are unchanged. Observed provider profile-page streams use gzip; exact HTTP bodies, control journals and mutation semantics retain their existing representation. Artifacts charge every actual physical write, including gzip header/footer, before writing. A partial or quota-failed file is retained without a success journal record. Sensitive values are rejected before compression.

The report reader validates the complete original gzip envelope with existing bounded64KiB decoding,2GiB decoded bytes,2million records and64KiB lines before a bounded second read through the same descriptor; CRC, truncation, extra members/trailing bytes and changed file signatures reject the result. Existing frozen metadata readers already support this representation; no checker, Schema, limit or threshold changed. Gzip changes scanner work and memory, so no prior scanner performance or execution qualification is transferred to this runtime.

Actual V3Windows146 tests/56.119s and Linuxrelated47 tests/25.914s passed with real wait0, zero failures/errors/skips and identical before/after working-source hashes. Both original13 small-fixture native chains now genuinely use three gzip exports plus compressed provider pages; plain native lifecycle coverage remains. Canonical tests also use the unchanged frozen reader for all three schemas and perform a real scanner roundtrip. Header/footer physical quota failures retain partial files, existing paths are not overwritten, invalid envelopes/decoded limits and sensitive records are rejected.

V1Windows142pass4fail and Linux43pass4fail remain failures: four new test fixtures collided with an existing input or supplied relative artifact prefixes. Only those fixture paths were corrected. V2Windows146passed; Linux46pass1fail was the unchanged native WALL_CLOCK_CHANGED guard, not suppressed or retagged. A finite21-marker original-Clock observation passed but is not future stability proof. V3 adds native gzip composition coverage and retains raw failure diagnostics before reraising; neither clock code nor thresholds were changed. All six original raw/XML/result sets, clock observation, runners, current code snapshots and hash-matched reconstructed earlier test sources are losslessly retained in compressed-output-v1/index.json with explicit provenance.

Independent96e7da59 accepted this exact working component only. The new committed source still requires its own15 declared native gates, same-head CI and independent full source acceptance before new1m resources/template/window and actual original13/full qualification. Existing c98/009 local100k and8f/00810k retain their original identities. No new scale result, provider production quota, profile terminal index, fullPOC, Ready, mainmerge or V1 completion is claimed. All4171 old untracked artifacts, actual009 records and prior failures remain. Rollback is an ordinary reviewed forward code change with original partial outputs retained.


## Pending producer compression implementation for the required1m sweep

TaskPOC-005/Issue132 remainsin_progress under the existing role/path/lease. Goal: produce bounded single-member gzip metadata so the required1m sweep can preserve complete raw evidence within unchanged1GiB/20k limits. The accepted009/c98 raw177845732B and readonly output-budget assessment motivate this change; the10x projection is not1m evidence. Canonical export will select gzip only for explicit.jsonl.gz outputs; provider profile-page streams will use gzip, while HTTP bodies, control journals, expected counts and opaque identities retain their original meaning. Controller filename reporting must consume the complete finite gzip envelope and reject checksum/member/trailing/line/decoded-budget errors. Physical hashes and artifact accounting must include compressed headers/footer and actual bytes.

Scope: Ownpoc/POC-05-metadata-scale producer/consumer code and regression tests plusOwnTask/Evidence. Frozencheck_program/schema/catalogue/thresholds, Program/Active/claims/roles/lease and old evidence are excluded. Verification: component plain/gzip equality and frozen-reader compatibility; physical quota and failure preservation; existing controlledsource/Windows/Linux regressions; then a new exact sourceTask15/CI and independent review before anynew1m resources/window/execution. No new run is approved. Restore code through an ordinary reviewed forward change; preserve partial outputs and all earlier failures. No new source acceptance, scale1m or fullPOC completion is claimed by this preparation.



## Accepted actual009 local100k qualification; million-scale and full POC remain pending

The exact accepted runtimec98/tree487a completed independently approved009 on the isolated100k-file/500-directory v6 OpenList. Actual work began2026-10-26T02:15:34.916855Z; the real controller wait0 finished02:19:10.349567Z inside its finite window. All13 observations, two501-page/100500-object listings, four controlled faults, three actual mutations and five probes were independently accepted. Selected4116raw artifacts total177845732bytes. Scanner enumeration2204.2128455563393objects/s, incremental0.04323545s and nativePeakWorkingSet32772096bytes are this scanner/configuration only; source HTTP, adapter6000/min and production limits remain separate domains.

Actual4157-path evidence contextda1e85a is a direct child ofc98. Its clean/no-alternates clone ran the entire unchanged frozen validate_execution statuspass call, actualsession36870 exit0/errors[], before==after; checkerSHAee53ccf38e80095fd77ded709aa5dba7808d011a6346e864cd1a9f6482be8cc8. The independent final fa38ac26 accepts this exact local100k execution qualification only. Lossless original results,382-byte full-validation raw, approvals, negative static candidate, precommit pins and final reviews are in qualified-local-100k-attempt009-v1/index.json. Runtime raw/input/control files remain at profiles/local-v1/v1/attempt-009 and inputs-100k-attempt009. Historical pending flags are original preparation facts and were not edited after validation.

The original5ee5 unapproved template had a P2 stale delivery description; its bytes and rejection remain. Revised21e043e8/template199759a2 preceded real suspendedPID11124 and separate33-file finalapprovale58e8341. No old approval was reused. The accepted evidence parent was ordinarily merged intoa8ccb154 with orderedparents[9b988b9,da1e85a], disjoint32+4157=4189 paths and both parents' original blobs preserved; independent7611b11f accepted that actual merge. All4171 olduntracked paths and10 excluded009 databases remain local; all earlier failures and008/8f10k qualification retain their own identity.

Current source code and frozen contracts are unchanged. This new archive metadata HEAD inherits neither source gates nor CI. PR136 remainsDraft/headc98 and unpublished archive metadata is not Ready or main acceptance. Remaining: producer compression and honest budgets needed for1m, exact-source code tests/Task15/CI, independently prepared and approved real1m resources/window/original13/full qualification, formal profile result/index and full POC, integration order3, normal Review/Completion and actual-main verification. A read-only estimate from actual009 suggests profile gzip may reduce retained bytes; it is not1m data or an approval. Preserve original physical bytes and unchanged frozen limits. FullV1 remains incomplete.



## Accepted exact compressed-input runtime c98 source (not new scale qualification)

The exact c98c93f835ea5c6bfcf19eb1256cd66d75efc4b4 runtime/tree487a8d3b40f59c3939f79e5430cc31ccbf8fbace completed all15 native Task gates in a clean ordinary-user/no-alternates clone with actual waits and before==after. Its actual Windows140/Linuxrelated29 code regressions retain their component source pins. Independent publication review permitted only a normal forward update of existing DraftPR136; the actual push8f→c98 returned0 and the remote head matched.

CI867/run40250192169/job121340185232/attempt1 completed successfully:28steps allsuccess,752 distinct verbose PASSED cases in1171.47s, actual generated JUnit and skip audit output OK: No skipped tests. No JUnit artifact was available/downloaded, so direct XML parsing is not claimed. Original decoded connector log1364260bytes/SHA4b19316b11b0de9dcdf84423a7c1bc3bd73ca8e59183525fc65cfcacde10f3e5 is retained. Actual CI checkoutd446c6239ce0815be104ae7a8a270e06edabf676 has official parents[746e23e582501fa08380c3f3301bdc1774902f7c,c98c93f835ea5c6bfcf19eb1256cd66d75efc4b4] and exactly the runtime tree. Independent final f3c2bfb0 accepts that exact source/local gates/complete CI.

Lossless originals: compressed-input-c98-source-validation/index.json. This forward evidence archive does not transfer validation to a new metadata HEAD. Actual8f/008 local10k execution remains bound to that old runtime; c98 source acceptance enables only preparation of a new independently reviewed scale template, not automatic100k/1m inputs/resources/window or execution qualification. Outputs remain plain; actual larger runs, exact budgets, formal result/full POC, integration order3 and normal Review/Completion remain pending. Draft stays Draft; noReady/mainmerge/Task completion. All4171 old untracked raw/DB originals and every failure remain preserved.



## Canonical compressed-input component (new source qualification still pending)

CanonicalPair now consumes plain JSONL and strict single-member .jsonl.gz, independently for baseline and companion. The initial physical SHA/signature pass validates complete gzip EOF/CRC and rejects extra members or trailing bytes with bounded64KiB decoding. The two original physical hashes still bind the checkpoint; stored offsets and EOF use decoded bytes. Limits remain2GiB decoded bytes,2million records and64KiB per line for each stream. Normal pages retain forward readers and reserve two maximum lines before reading, avoiding a backwards seek/redecode per page. No disk spool or new runtime configuration is introduced. Reopening/retrying an older checkpoint can decode its prefix once; this is not a random-access compression index.

Actual Windows140 component tests and the related Linux29 tests passed with real owned wait0 and zero failures/errors/skips. Nine new cases cover mixed representations and exact catalogue export, physical companion re-encoding binding, decoded-offset restart, malformed/CRC/truncated/member/trailing refusal, decoded budgets, real SQLite page rollback and retry, changed input/invalid cursor/duplicate JSON,1800 large rows crossing the page-byte ceiling without a backwards seek, and actual FixtureMap failure cleanup. Windows JUnit reports52.228s and Linux6.6s. Source hashes before/after each run match. The first interactive run had two errors in the new tests' assumptions (tell internally calls a non-moving seek; one short decoded page need not exceed the whole compressed file size); the tests were corrected without changing production code, then the later complete suites passed. No independent file raw is claimed for the interactive-only first run.

EOF/read errors/explicit close release gzip readers; scanner close/constructor failure and FixtureMap construction finally also release them. A SQL transaction error keeps the checkpoint unchanged; its caller can close or retry at that saved cursor. It is not a claim that every SQL error immediately closes the pair. Reversible source, actual raw/JUnit/results, helpers and independent component review are in compressed-input-v1/index.json.

This component does not migrate the accepted8f/008 local10k execution to changed code. New fixed-source Task15/CI, complete independently approved100k/1m inputs/resources/windows and original13 runs, output/artifact budgets, formal result index/full POC, integration order3 and normal Review/Completion remain pending. Outputs are still plain; input support alone does not prove the larger artifact budget fits. No frozen checker, Schema, catalogue, policy, roles, claims or lease was modified. All4171 old untracked raw/DB originals remain retained.



## Accepted actual10k execution qualification; full POC remains pending

The unchanged tested runtime8f7c9a5 (nativeTask15/CI866752 accepted) completed a new independently approved attempt008 on the isolated v5 OpenList. All13 actual observations and4116 selected raw artifacts were independently accepted. The genuine4148-path evidence-only context71b7777 is a direct child of8f; the full unchanged frozen validate_execution call ran in its clean/no-alternates clone and returned0/errors[] with checker ee53ccf3. Its raw538 bytes hash f19bacaa2f1d83a0ed026686f9fedb1b843fc6564d85d0fee6f0880a433b7e02 and independent e7bdb4cf acceptance are retained losslessly in qualified-local-10k-attempt008-v1/index.json.

This result is separate from original007: its13 observations were accepted, but the actual complete qualification returned1 with5 UTC-representation errors. Its original +00:00 approvals, five-error raw/assessment,7dd5550 evidence context and all databases remain unchanged. New008 approved canonicalZ before execution and re-ran the actual workload; no past approval or validator was rewritten. Both actual evidence parents were ordinarily merged into dce6ec3 with ordered parents[7dd5550,71b7777], preserving the disjoint8296-path union, unchanged runtime code/Task metadata and old untracked originals.

Measured008 scanner enumeration is2729.1596044246903objects/s, incremental traversal0.04011685s and native process PeakWorkingSet31.25MiB for10000files/500directories. Adapter quota6000requests/min and the controlled three-change burst are not provider production limits/rates; source HTTP throughput and scanner throughput remain distinct. These numbers are only the recorded local configuration, not700TB or100k/1m scale evidence.

This archive accepts local10k execution qualification only. Profile terminal result/index acceptance, original100k/1m sweeps and compressed-input support, actual provider/production obligations, full Task/Ready/main integration and V1 completion remain pending. No new runtime/experiment permission follows. The local evidence merge/archive is not a new code-source acceptance; latest tested code identity remains8f. Keep all raw outputs, failed histories, bundles and local DBs. Next: complete the remaining scale/domain work and honest profile result before normal fixed-source gates, integration order3, Review/Completion and actual-main validation.



## 当前调用方对齐修复上下文

固定源 1869091239b51960d53b0840c4965e3f84eb10fd 的完整Windows130实际失败（4 failures、10 errors）；遗漏的消费者仍要求旧五字段请求。此修订同步ControlledFixtureMap和loopback gateway到实际四字段请求，网关严格拒绝额外空/非空password或未知字段，原scope、认证、refresh与真实字节/摘要约束保持。新反例重新计算请求摘要后仍须拒绝多余字段，不通过伪造hash结果绕过请求格式校验。

四条工作区代码和完整Windows131已在实际运行中退出0；原结果及此前固定源失败、history31项拒绝均可从 wire-consumer-alignment-v1/index.json 还原。新候选尚未分配提交；工作区通过不等于新固定源、CI或完整资格通过。治理历史归属尚未修复，本候选不重复执行已知会失败的全history/CI，不发布覆盖Draft136；在治理修复后同步最新接受main并补齐全部Task15及同头CI。

本次提交后先执行新固定源完整Windows131和相关限定Linux：原listing/platform/binary HTTP/UTC测试加FixtureMap9与网关权限拒绝用例。原Linux真实clock问题不改阈值、不借此重放旧工作负载。未来环境记录仍须使用真实scanner build字符串、独立工具链字段和明确notReportedProperties；旧006方法/批准/原件均保持，新方法在独立审查和全新批准前不得用于实验。

## 历史请求格式修复上下文

已真实同步完整接受的Review主线 c0d550555dd51a29fd1c5ff1bc5e4713073c0b53；实际双亲合并为 5cc671b27e4d4ccde7c957e0fe3ec040d2dd6e52，父提交为证据交付f162ab3与该main。此前源78a54f4的attempt006在实际批准窗口正常wait退出0、原13观测获独立接受，但完整冻结validate_execution真实拒绝1018条：1015个请求带零长度password字段、OpenList wrapper的passwordMetadataCount命名、tool_versions表示引起subjectVersion不等，以及四个WMI未报告AdapterRAM传播到gpu/driver。全部原始输入、请求/响应、批准、字段、失败与干净验证上下文保留，不改为qualified。

本次Own代码只省略无元数据密码来源不需要的空password请求参数，保持实际发送字节/摘要原样留存、认证Header仅在内存、其余scope/limits/响应安全/分页/身份校验不变。新wire用实际mock HTTP和冻结credential scanner红绿验证；首次绿色尝试的新测试误用parse_page的tuple接口，原失败保留并仅修正测试调用，14项listing suite现已实际通过。未改冻结checker、Schema、原13、数域或安全策略。下一次真实执行仍须新固定源完整验证/CI/独审以及新fixture、正式wrapper和执行前投影方法及具体PID/hash/未来窗批准；不得重放006。

当前源/tree尚未分配；精确15项、本次完整Windows及限定Linux回归和同头CI未执行。角色、原lease、claims与order3保持，仅Own Task/Active刷新base到最新完整接受main。原100k/1m、约700TB/真实提供方配额与完整POC义务不变。

## 历史恢复与验证上下文

已在独立干净副本从原受审源 e1c1ca3d576f552c87bcc016885d733a5b1e9313 正常合入完整接受的解冻主线 e1ef8eda8daa148aaff165712a878c463dfb9fab，真实双亲合并为 ba8d6ec45982df483cdde6b95e9091f568e54d4e。原工作区及4180项未跟踪原件保持；代码未改，Task/Active仅刷新自身基线，角色、lease、claims与order3保持。Program已active，代码修复PR145/09d与解冻PR146/T均有实际主线完整接受；本任务当前固定新源尚未分配、验证未执行。

本轮先执行新源15项、完整Windows129项和Linux平台28/HTTP1/UTC4的有界回归，以及同头完整CI和独立源接受。Linux旧时钟工作负载不在本轮重试。随后重新固定输入、资源、数据域和窗口并独立批准，才可执行新的真实OpenList/规模实验。原10k链路、UTC及33字节416冲突失败仍按其实际结果保存，不改标为资格通过；原13项、阈值及约700TB生产规模/提供方配额边界不变。

当前完整路径清单为evidence/POC-005/changed-files.md；前置原件见thaw-baseline-e1ef8ed/index.json。新源Windows/native检查与实验结果均为PENDING，旧source结果不能替代。

### 历史实现上下文（原文保留）

本次在既有Own范围增加明确Windows原生后端，以实际最终暂停image、创建时原子Job关联、同PID批准后恢复、QPC/Precise FILETIME、独立原生working-set采集和受控handle叶变更执行相同协议。真实SID/DACL限制凭据读取；不使用chmod或伪造Linux/proc身份。调用前后采样保留，不将父post采样当恢复时刻。Linux既有入口及冻结阈值不变；单元HTTP/文件链仍明确不等于OpenList/规模/原13项资格。设计、实际回归与独立审查在evidence/POC-005/windows-*记录，完整实测和新源CI待执行。

第三次实际经独立批准的A9来源尝试已完成两轮各501页/10500对象的完整列表与四类适配器故障观测，随后枚举前因WALL_CLOCK_CHANGED失败，实际父进程wait退出1；未执行变更。失败marker原tick/wall未留，后续独立61样本时钟诊断发现秒级时间源分离，不据此伪造缺失marker偏差或归因。最小Own修复保留拒绝时原读数、完整校准及偏差，括号采样明确不确定性，并向控制器传递真实runtime_failure；原1ms拒绝与冻结1us区间一致性门槛保持。两次有界环境对照均未消除分离，原校时active及tsc已恢复；无来源重试或资格接受。后续需可靠计时环境及全新独立批准。原件、回归red/green和环境记录见evidence/POC-005/source-attempt003-clock-failure/。

2026-10-22 实际进展：4b12002 的Task15、原生90项与独立来源审查通过；两次经独立批准的10k来源尝试分别在首个listing遇到敏感签名拒绝与等价时区文本不一致，均失败并保留原始证据，未执行三类变更。共享OpenList保持原策略，新增隔离实例只服务自建非敏感fixture。当前适配修复将实际RFC3339字段规范化UTC/Z并独立保留小数精度，原HTTP正文/摘要/status不变；无效偏移必须拒绝。原13项均为冻结已知单位，numericDomainReviewRefs应为空，不添加九份自定义单位数域门禁。以下早期“未执行”语句为先前实施上下文；当前仍无完整POC或规模资格接受。

预留PR135/sourcef42e107已正常合入实际main f2e0150265e0c1eeca5f69fe85708b2434e5ee79。源local15/CI814713项/独立内容审查、实际merge parents/tree、主线五项+POC协议+CI816713项/1445.86s（零测试跳过）均已接受；已精确清理已结束的远端预留分支，所有本地ref保留。当前实现从该最新main的正式workBranch启动，未运行本任务实验。旧预留段落是历史登记上下文。

### 本次实现边界与本地接口

在Own路径实现确定性分层元数据样本、按批准版本分页读取的来源适配器、SQLite事务检查点与扫描器、有限重试及原始观测记录。合成来源的objectId独立于path；扫描pass/fixture SHA/sourceId/cursor绑定，整页应用和cursor原子提交，重复ID、版本漂移和cursor循环失败。增量create/update/delete记录独立序号与from/to版本，删除仅是本POC索引中的来源墓碑，不删除Guize逻辑资产。

来源页面采用本POC内部结构：sourceId、snapshotVersion、cursor、nextCursor和records；每条记录带稳定objectId、parentId、name、path、isDirectory、declared sizeBytes及versionId。没有实际媒体负载；10k/100k/1m指文件数，目录另计；深度与文件名分布由实际扫描得到。检查点最多保存一页对象于内存，持久化索引不将整个清单载入内存。原协议另以五字段基础记录和八字段文件名记录成对固定输入，双SHA绑定检查点；相对路径/depth按冻结Schema验证，虚拟锚点不进入枚举数量。完整目录及变更事件从实际事务索引导出，不能复制生成器统计。

新增本POC只读WebDAV观测接口，先固定loopback /dav/前缀、PROPFIND Depth1/HEAD/GET、响应大小/超时和不跟随重定向，原始响应与metadata白名单绑定SHA及实际时钟；凭据仅在内存中从私有配置引用。DAV href/ETag不冒充稳定对象ID/快照token/变更日志，其条目只作来源观测，不接入合成身份扫描。真实OpenList需通过其实际HTTP/WebDAV观测单独适配与验证；缺失稳定提供方ID时明确报告，不能把路径冒充资产唯一身份。生产700TB与百度配额不在合成/本地结果中宣称完成。只有固定真实输入/资源/数域/窗口获得独立批准后才执行规模与来源实验。

本次补齐真实来源控制：固定scope和未来窗口的只读loopback网关保留上游原字节/status，执行有限适配器配额及明确注入的429/5xx/断连/网关授权过期；不宣称提供方生产配额或OpenList令牌过期。受控叶文件变更先验证批准的路径/前后负载摘要，实际变更并完整远端复查后才产生带证据的观测事件。完整重复listing与原五类Range/validator响应用于组装冻结scan/resource/profiling报告及原13指标；负响应body/缺失validator原样保留，生成报告不等于资格通过。

## 背景与目标

本次实现已审设计的Linux真实生命周期：不可变code/argv manifest预留等待PID，独立批准绑定实际reservation与配置/未来窗口，复核后同PID exec。真实程序入口与OS出生/交接分开；控制器先执行独立原生采样才放行enumeration，changeStream只接收真实受控来源观测引用，incremental实际回放。外部只读进程在阶段后重读完整post目录；末次原生计数后才放行退出，真实wait退出码决定三个typedphase，统一校准时钟保留原ticks/墙钟样本。入口及真实外部退出均须在批准窗口内；窗外退出保存失败facts，禁止成功capture，不改时间或延窗。单元IPC/文件fixture不能冒称真实OpenList或批准规模实验；原13及完整验收义务保持。

独立原生内存collector读取/proc/PID/status原字节，前后核批准PID/bootId/startTicks/exe及argv摘要和同用户归属，验证唯一Pid/VmHWM/VmRSS，再以独占创建保存原始计数。stdout回执保留真实时间/collector PID/argv/代码与输出摘要；自采样、死亡/复用/替换PID、错误平台或既有输出均失败。后续控制器以独立首末采样包围全部工作；窗口前预留launcher、批准后同PID exec，scanner入口与OS出生分开记录，实际退出决定阶段成功。当前设计核查不等于任何具体实验或输入/资源/窗口批准。

本次增加受控fixture身份绑定：固定双摘要canonical输入与OpenList客户端endpoint/scope，在Own隔离SQLite保存批准映射和各次实际观测。只从映射取得opaque objectId/versionId；名称、路径、深度、类型、大小和时间必须从真实响应解析并完整比较，不能用期望值补齐观测。逐页校验真实请求/响应摘要、实际Date、cursor连续性及完整人口；完成后的文件名清单从实际观测表导出，不从批准表复制。映射不赋予提供方原生稳定ID、快照、生产规模或POC资格接受。

本次在Own路径增加固定OpenList v4.2.6的只读POST /api/fs/list分页接口，显式固定loopback origin及reader相对前缀、refresh=false、页/响应/对象上限。HTTP状态与JSON code分别验证；token仅内存引用，含token或签名/缩略图能力、或无法完整无歧义解码检查的响应不保留正文并失败，保留实际摘要、省略原因及原传输错误。独立SQLite存储遍历队列和实际路径观测，不将全目录清单装入内存；页基数、目录total漂移、重复路径、深度和完整终止分别检查。driver遍历cursor不冒充提供方快照。提供方缺失ID/version保持null，后续受控fixture映射另行固定；本次不批准来源/规模实验或改变原13项。

Issue #132：https://github.com/ElectricDogCN/Guize/issues/132 。GZ-010及BASELINE-GZ-021/GZ-022的普通Completion已在实际接受main中完成；本次实现基线为f2e0150265e0c1eeca5f69fe85708b2434e5ee79。原W2的POC-003/005均正常完成后才能进入依赖W3任务，不改变冻结波次和依赖。

预留已完整接受；Own分页源与事务扫描器已完成首轮真实Windows OpenList10k原13项观测。该轮执行正常退出，但冻结资格校验拒绝UTC表示，实际416非空正文与冻结合同也冲突；旧批准已消费、原件与脏fixture保留。当前前向修复时间序列化和输入证据保留，不宣称资格通过。Program原issue=null保持；实际Issue132只通过Task/Registry关联。

## 输入与输出

- 输入：specs/poc/plans/POC-005.yaml、POC-PROTOCOL-V1及原policy/resources/samples/Schema，REQ-V1-0001/0002、NFR-V1-CAP-003、module-ownership.yaml、AGENTS/Never Rules和已接受GZ-021/022。
- 预留合并并完整接受后，在自己的实现分支从届时最新main开发分页源、流式扫描、确定性create/update/delete、checkpoint和故障/限流驱动。先固定10k，再100k/1m档；独立批准实际字节/资源/适用数域/窗口后才执行。
- 原13项：file_count,directory_count,directory_depth_max,average_file_size,source_api_quota,source_change_frequency,enumeration_rate,incremental_scan_cost,memory_peak,filename_characteristics_profiled,provider_characteristics_profiled,range_support_profiled,etag_behavior_profiled。
- 分开报告固定合成元数据与实际本地OpenList受控小集合；合成声明大小不是700TB真实数据，注入配额不是提供方生产配额。百度生产接入后置，原生产规模义务保持。
- 历史仓外fixture和OpenList4.2.6只是候选；实际进程、版本、配置、来源权限和输入字节在执行前重新核实。凭据只引用外部私有配置，不写Git或日志。
- local-v1/v1正式结果只使用evidence/POC-005/profiles/local-v1/v1/唯一slot；真实原始输入、输出、配置、执行/结果及独立review按既有规则绑定，不以未跟踪路径或生成统计冒充qualified artifact。

## 允许范围

- 当前可在已预留Own路径实施上述扫描/分页/检查点/故障驱动；Task/Active仅更新自己in_progress/implementer及当前基线，Program只更新自己tasks/pocs状态。
- `poc/POC-05-metadata-scale/**`
- `evidence/POC-005/**`
- 共享：`adr/**`、`specs/poc/results-index.yaml`，只改自己结果行。

## 禁止范围

- 不修改冻结POC plans/program/policy/resources/samples/Schema/templates/checker、治理scripts/tests/workflow、其他Task/租约/结果/历史账本、backend/services/edge及生产数据或凭据。
- 不改GZ-010 executionEnabled=false，不把本地结果冒称百度/700TB生产结果，不调整原13项和阈值。

## 依赖与集成顺序

- 原dependsOn=GZ-010，poc-results/W2/order3和模块MOD-SOURCE/MOD-ASSET/MOD-CONNECTOR保持。BASELINE-GZ-021与GZ-022均已真实完成；本次只预留自己，不依赖未合并的POC-003实现。当前main只存在POC-003一项medium预留，加入本项后不超过3活动/1高风险限制。

- POC-003与本任务独占路径分离；共享ADR/结果按order2→3串行集成。两者的ATS延迟/磁盘与metadata吞吐/RSS测量窗口在同一物理主机不得重叠，Windows/WSL不能当独立机器；每次实验留实际负载/时间窗口。注册允许后续开发，不批准当前任何测量。

## 独占写范围

- `poc/POC-05-metadata-scale/**`
- `evidence/POC-005/**`

## 共享修改范围

- `adr/**`
- `specs/poc/results-index.yaml`，只修改自己的结果行。

## 协作与交接

- Owner ElectricDogCN；Coordinator program-coordinator-agent；Implementer/Executor task-owner-agent；Reviewer independent-review-agent；Integrator integration-agent。Reviewer独立于实际实现者/执行者。
- 当前in_progress/implementer；历史登记分支chore/POC-005-metadata-scale-reservation已结束，正式实现分支chore/POC-005-metadata-scale，base 746e23e582501fa08380c3f3301bdc1774902f7c。UTC lease 2026-10-22T16:08:44Z→2026-10-29T16:08:44Z，最长168h，不自动续租。
- 精确源/tree/文件/命令退出码/CI/共享范围/回滚和下一角色动作记录在evidence/POC-005/handoff.md。

登记源真实检查、同头CI、独立审查、正常合并和实际主线接受已完成；实际受测ca1源通过Task15、Windows125和CI827/713零跳过。首轮真实10k观测的有限执行与原始证据获独立接受，资格未通过；当前修复代码的独立内容审查通过、完整Windows129开发测试通过，提交后源验证与CI另行执行。源版本、有限观测、完整资格、普通Review/Completion和完整V1分别按事实判断。

## 验收标准

- [ ] 实现保持Own路径；Program issue/定义/政策/兄弟Task和原POC-003记录保持。
- [ ] 实现前登记已接受；执行前固定实际immutable输入、资源及适用booking、measurementDomainReview、testedSource和executionWindow。
- [ ] 原13项、typed报告、实际argv/PID/退出码/UTC/输入输出字节和原始观测齐全，固定合成规模与实际OpenList来源分别验收。
- [ ] 分页/身份/版本、增量/断连恢复、限流/退避、文件名/深度、Range/ETag和权限失败保留真实输出，不以生成器统计替代扫描结果。
- [ ] 测量不与POC-003重叠；失败/未测与生产限制如实记录；只更新自己结果行。
- [ ] 实现/源CI/独立结果审查/实际主线接受后正常Review和Completion，不提前关闭Issue或释放登记。

## 必须执行的测试

```bash
git diff --check 746e23e582501fa08380c3f3301bdc1774902f7c...HEAD
python scripts/check-task-file.py --task POC-005
python scripts/check-project-readiness.py
python scripts/check-schemas.py
python scripts/check-program-plan-integrity.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-program-plan-history.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005 --branch-name chore/POC-005-metadata-scale
python scripts/check-program-plan-transitions.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005 --branch-name chore/POC-005-metadata-scale
python scripts/check-program-plan-finalization.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005
python scripts/check-program-lifecycle-guards.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005 --branch-name chore/POC-005-metadata-scale
python scripts/run-program-lifecycle-gate.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005 --branch-name chore/POC-005-metadata-scale
python scripts/run-agent-coordination-gate.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-005 --branch-name chore/POC-005-metadata-scale
python scripts/run-task-scope-gate.py --task POC-005 --base 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-evidence.py --task POC-005
python specs/poc/check_program.py --task POC-005 --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-markdown.py
```

以上十五项须对当前实际提交执行；同头完整治理CI必须零失败/错误/跳过。正式实现另执行自己的驱动与原13项，并运行`python specs/poc/check_program.py --profile local-v1 --require-results --poc POC-05`。首轮已有实际实验和定向冻结拒绝证据，尚无完整结果checker通过声明。

## 风险

同机资源竞争、合成/真实来源混淆、输入版本变更、配额/权限/Secrets和测量方法失真。使用原协议及独立批准，不以放宽门槛修复失败。

## 回滚

未合并可撤回登记；已合并按合法取消释放自己的租约。实验仅操作明确自建的沙箱/前缀/进程，停止后核端口与恢复；保留实际输入、Evidence和历史，不重启Docker/WSL或其他项目服务。缺陷用受审查的前向修复/回滚。

## Evidence

evidence/POC-005/记录真实源、命令、退出码、限制和交接；首轮固定样本/资源/PID/窗口已独立批准并实际执行，原批准已消费；数域引用保持{}。windows-attempt004-observed-unqualified/保留原件与独立结果结论，metadata-qualification-issues.md记录未解决资格问题。新提交检查、后续规模、资格与集成仍未完成，当前不是完整POC/V1完成。
