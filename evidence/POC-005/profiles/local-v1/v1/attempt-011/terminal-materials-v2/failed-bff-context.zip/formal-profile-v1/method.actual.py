"""Run the unchanged complete formal011 profile in a clean native Linux checkout."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

t=Path(__file__).resolve().parent
context=json.loads((t/'poc005-attempt011-formal-profile-context-v1/results.json').read_text(encoding='utf-8'))
head='bff619272ec770969804f0f853cf87a3ddc85c68'
assert context['head']==head and context['actualCommitWaitCompleted'] and context['commitExitCode']==0
assert sys.platform=='linux' and os.geteuid()!=0
bundle=t/Path(context['bundle'].replace('\\','/')).name
raw=bundle.read_bytes()
assert len(raw)==context['bundlePin']['bytes'] and hashlib.sha256(raw).hexdigest()==context['bundlePin']['sha256']
root=Path('/home/sur/.cache/guize-takeover/poc005-attempt011-formal-profile-bff6192-v1')
out=t/'poc005-attempt011-formal-profile-linux-v1'
assert not root.exists() and not out.exists()
out.mkdir()
clone_argv=['git','-c','core.longpaths=true','clone','--quiet','--branch',context['branch'],
    '--config','core.autocrlf=false',str(bundle),str(root)]
with (out/'clone.stdout.raw').open('xb') as stdout,(out/'clone.stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(clone_argv,stdout=stdout,stderr=stderr)
    clone_code=child.wait()
if clone_code:raise RuntimeError('Clone failed; preserve raw and do not reuse target')
g=lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-C',str(root),*a],text=True).strip()
state=lambda:dict(head=g('rev-parse','HEAD'),tree=g('rev-parse','HEAD^{tree}'),status=g('status','--porcelain=v1','--untracked-files=all'))
before=state()
assert before['head']==head and before['tree']==context['tree'] and not before['status']
assert not (root/'.git/objects/info/alternates').exists()
checker=root/'specs/poc/check_program.py'
checker_sha=hashlib.sha256(checker.read_bytes()).hexdigest()
assert checker_sha=='ee53ccf38e80095fd77ded709aa5dba7808d011a6346e864cd1a9f6482be8cc8'
command=[sys.executable,'-B','specs/poc/check_program.py','--profile','local-v1','--require-results','--poc','POC-05']
started=datetime.now(timezone.utc).isoformat();tick=time.monotonic()
raw_path=out/'formal-profile.raw'
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
with raw_path.open('xb') as stream:
    stream.write(('Source Commit: '+head+'\nCommand: '+subprocess.list2cmdline(command)+'\n').encode());stream.flush()
    child=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
    progress=dict(kind='ACTUAL_COMPLETE_FORMAL011_PROFILE_RUNNING',head=head,tree=before['tree'],root=str(root),
        command=command,pid=child.pid,startedAt=started,checkerSha256=checker_sha,
        clonePid=child.pid,cloneExitCode=clone_code,cloneClean=True,noAlternates=True,
        platform=platform.platform(),pythonVersion=sys.version,uid=os.getuid(),
        actualWaitCompleted=False,formalProfileValidated=False)
    # The actual checker PID above is authoritative; no claim of process birth/wait is inferred from a lock file.
    with (out/'progress.json').open('x',encoding='utf-8') as f:json.dump(progress,f,indent=2)
    print(json.dumps(progress),flush=True)
    code=child.wait()
    stream.write(('\nExit Code: '+str(code)+'\n').encode());stream.flush()
elapsed=time.monotonic()-tick
after=state()
raw=raw_path.read_bytes()
result=dict(kind='ACTUAL_COMPLETE_FORMAL011_PROFILE_LINUX_RESULT',before=before,after=after,
    sourceContextUnchanged=before==after,command=command,pid=child.pid,startedAt=started,
    endedAt=datetime.now(timezone.utc).isoformat(),elapsedSeconds=elapsed,actualWaitCompleted=True,exitCode=code,
    root=str(root),noAlternates=True,platform=platform.platform(),pythonVersion=sys.version,uid=os.getuid(),
    checkerSha256=checker_sha,raw=raw_path.name,rawPin=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),
    originalCiJobBudgetSeconds=1800,thisFormalCommandWithinCiJobBudget=elapsed<1800,
    entireCiJobWithinBudgetProven=False,independentProfileAccepted=False,sourceQualified=False,
    published=False,taskCompleted=False,v1Completed=False)
with (out/'results.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'exitCode':code,'actualWaitCompleted':True,'elapsedSeconds':elapsed,
    'sourceContextUnchanged':before==after,'thisCommandWithin30Minutes':elapsed<1800,'taskCompleted':False}),flush=True)
assert before==after
raise SystemExit(code)
