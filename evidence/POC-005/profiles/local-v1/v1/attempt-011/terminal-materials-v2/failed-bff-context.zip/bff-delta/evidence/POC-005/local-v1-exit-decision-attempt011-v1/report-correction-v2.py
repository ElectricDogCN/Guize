"""Forward report correction; retain the original unapproved report and archive."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

t = Path(__file__).resolve().parent
r = t / 'poc005-feature-actor-import-v1'
old = r / 'evidence/POC-005/local-v1-scale-exit-report-attempt011-v1.md'
assert hashlib.sha256(old.read_bytes()).hexdigest() == 'c453151a6d475c9e171e33a608271dc2768e52d2a763cc7ddc79fc399e88279a'
new = r / 'evidence/POC-005/local-v1-scale-exit-report-attempt011-v2.md'
folder = r / 'evidence/POC-005/qualified-local-1m-attempt011-v1'
fanout = json.loads((folder / 'observed-directory-fanout.json').read_text(encoding='utf-8'))
source = old.read_text(encoding='utf-8')
assert source.count('每页最多128对象且有字节预算') == 1
source = source.replace('每页最多128对象且有字节预算',
    '011固定扫描器运行配置的pageSize=200；来源HTTP列表请求的perPage=1000，两者均受各自字节预算约束')
source = source.replace('## 来源行为与规模模型', '''## 来源行为与规模模型

完整观察目录的实测直接子项扇出：500个记录目录中59个为空，最大2273；root直接子项2264，root与500目录的父路径计数合计1000500对象。包含零子项的目录扇出分布为 `''' + json.dumps(fanout['representedDirectoryFanoutHistogram'], ensure_ascii=False) + '''`。精确父路径计数、定义、输入摘要及分离的root/虚拟父项见[完整扇出推导](qualified-local-1m-attempt011-v1/observed-directory-fanout.json)，[可复现推导方法](qualified-local-1m-attempt011-v1/observed-directory-fanout-derivation.py)只读取已资格核验的完整观察流。

两次完整OpenList列表遍历分别耗时779.823936秒与712.158422秒；来自[原分页journal](profiles/local-v1/v1/attempt-011/source-artifacts/000002.jsonl)每轮首个requestedAt与末个finishedAt，涵盖客户端分页、传输和重试间隔。它们与下述scanner枚举速率分别记录；不将局部阶段速度当整个来源接入成本。''')
with new.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
shutil.copyfile(t / 'derive_poc005_attempt011_observed_fanout_once.py', folder / 'observed-directory-fanout-derivation.py')
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
supplement = dict(kind='FORWARD_REPORT_CORRECTION_AND_QUALIFIED_CATALOGUE_FANOUT',
    preparedAt=datetime.now(timezone.utc).isoformat(), originalReport=old.relative_to(r).as_posix(),
    originalReportPin=pin(old), currentReport=new.relative_to(r).as_posix(), currentReportPin=pin(new),
    correction='Original unapproved report incorrectly said128; actual scanner pageSize200 and source HTTP perPage1000 are distinct.',
    priorQualificationIndex='index.json', priorQualificationIndexPin=pin(folder / 'index.json'),
    supplementaryFiles={p.name:pin(p) for p in (folder / 'observed-directory-fanout.json', folder / 'observed-directory-fanout-derivation.py')},
    profileExitApproved=False, newExperimentExecuted=False)
with (folder / 'index-v2.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(supplement, ensure_ascii=False, indent=2) + '\n')
paths = [old, new, folder / 'artifacts.zip', folder / 'index.json', folder / 'index-v2.json',
         folder / 'observed-directory-fanout.json', folder / 'observed-directory-fanout-derivation.py']
candidate = dict(kind='UNAPPROVED_CURRENT011_EXIT_REPORT_V2', parent='8aa353c42c98aa62d147d0d3295b836f021537d6',
    currentReport=new.relative_to(r).as_posix(), files={p.relative_to(r).as_posix():pin(p) for p in paths},
    oldReportRetainedAsUnapprovedNegative=True, profileExitApproved=False, formalProfileValidated=False)
with (t / 'poc005-attempt011-exit-report-v2-current-candidate.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(candidate, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'currentReport':candidate['currentReport'], 'currentReportPin':pin(new),
                  'oldReportPreserved':True, 'paths':len(paths), 'profileExitApproved':False}))
