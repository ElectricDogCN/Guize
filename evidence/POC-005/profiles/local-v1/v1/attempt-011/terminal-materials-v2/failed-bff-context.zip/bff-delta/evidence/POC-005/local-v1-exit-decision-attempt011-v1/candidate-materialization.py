"""Transcribe the actual independent011 decision and export a clean tracked context."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import yaml
import jsonschema

t = Path(__file__).resolve().parent
r = t / 'poc005-feature-actor-import-v1'
parent = '8aa353c42c98aa62d147d0d3295b836f021537d6'
branch = 'chore/POC-005-metadata-scale'
g = lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*a])
assert g('rev-parse','HEAD').decode().strip() == parent
assert g('branch','--show-current').decode().strip() == branch
assert not g('diff','--name-only') and not g('diff','--cached','--name-only')
read = lambda p:json.loads(p.read_text(encoding='utf-8'))
pin = lambda raw:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
candidate = read(t / 'poc005-attempt011-exit-report-v2-current-candidate.json')
for name, expected in candidate['files'].items():
    assert pin((r/name).read_bytes()) == expected,name
assert set(filter(None,g('ls-files','--others','--exclude-standard','-z').decode().split('\0'))) == set(candidate['files'])
review_path = t / 'poc005-attempt011-local-v1-exit-independent-review.json'
review_raw = review_path.read_bytes()
assert pin(review_raw)['sha256'] == '184edc445493767cd26c1582788c6576a5eae9363689abdfd2a778fa04d0e6ad'
review = json.loads(review_raw)
assert not review['mustFix']
record = review['approvedResultRecordFields']
assert record['reviewer'] == '/root/gz022_planning_independent_review' and record['approvedAt'] == '2026-10-29T07:31:14Z'
assert record['executionRef'] == 'evidence/POC-005/profiles/local-v1/v1/attempt-011/execution-candidate.json'
assert record['decision'] == record['status'] == 'pass' and record['approval'] == 'approved'
schema = yaml.safe_load((r/'specs/poc/result-record.schema.yaml').read_text(encoding='utf-8'))
jsonschema.Draft202012Validator(schema).validate(record)
prefix = 'evidence/POC-005/profiles/local-v1/v1'
result_ref = prefix + '/attempt-011/result.json'
index_ref = prefix + '/index.yaml'
index = dict(schemaVersion=2,pocId='POC-05',pocTaskId='POC-005',ownerTask='POC-005',
             acceptanceProfile=dict(id='local-v1',version=1,bindingRevision=1,scope='LOCAL_FULL_V1'),resultRef=result_ref)
definitions = yaml.safe_load((r/'specs/poc/program.schema.yaml').read_text(encoding='utf-8'))['$defs']
jsonschema.Draft202012Validator(definitions['profileEvidenceIndex']).validate(index)
for name, value in ((result_ref, record),(index_ref,index)):
    with (r/name).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
decision = r/'evidence/POC-005/local-v1-exit-decision-attempt011-v1'
decision.mkdir()
copies = {
    'approved-exit-review.json':review_path,
    'negative-report-v1-review.json':t/'poc005-attempt011-local-v1-exit-v1-independent-review.json',
    'report-candidate-v2.json':t/'poc005-attempt011-exit-report-v2-current-candidate.json',
    'report-correction-v2.py':t/'correct_poc005_attempt011_exit_report_v2_once.py',
    'candidate-materialization.py':Path(__file__),
}
for name,source in copies.items():
    with (decision/name).open('xb') as f:f.write(source.read_bytes())
(decision/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
note = '''## Current011 local-v1 exit decision; complete formal profile check pending

The independent reviewer /root/gz022_planning_independent_review actually approved the current15d/011 local-v1 exit at2026-10-29T07:31:14Z. Exact signed fields are retained in local-v1-exit-decision-attempt011-v1/approved-exit-review.json and transcribed into profiles/local-v1/v1/attempt-011/result.json; the newly activated current profile index refers only to this011 result. The older010 result, retired invalid index and all historical observations remain unchanged.

The current report is local-v1-scale-exit-report-attempt011-v2.md: all five frozen criteria/13 actual observations, complete fanout/profile/source pagination costs and honest environment retention are independently accepted. Its original v1 page-size error and negative review are retained. Qualification/source/raw/CI and actual tracked-context provenance are in qualified-local-1m-attempt011-v1/index.json and index-v2.json. Scanner/controller/supervisor ended0; the complete frozen execution call on exact8aa ended0 and was independently accepted. The idle provider was later observed absent with zero15535 listeners; its exit code/cause/time were not observed, no new stop was executed,10DBs/fixture/private directories and controlled drift remain.

This metadata candidate has not yet run the mandatory complete formal profile command. Next export the exact clean Git context and run python specs/poc/check_program.py --profile local-v1 --require-results --poc POC-05, retain actual target-platform time under the unchanged30-minute CI policy, then perform all declared Task gates/same-head CI and independent whole-source/result review. NoReady/main, Task or fullV1 completion is granted. Original Task creationbase, concrete roles, original lease, Program/Active, frozen checkers/schema/policy/thresholds and previous raw remain unchanged; use a reviewed normal forward rollback.

Historical records below keep their original source and status:

'''
for name in ('summary.md','handoff.md'):
    path=r/'evidence/POC-005'/name
    path.write_bytes(note.encode('utf-8')+path.read_bytes())
task=r/'specs/tasks/POC-005.md'
old=task.read_bytes()
assert old.startswith(b'---')
end=old.find(b'---',3)+3
assert end>3
task.write_bytes(old[:end]+b'\n\n'+note.encode('utf-8')+old[end:])
commands=r/'evidence/POC-005/commands.txt'
commands.write_bytes(b'Current011 metadata candidate, formal command NOT YET RUN:\npython specs/poc/check_program.py --profile local-v1 --require-results --poc POC-05\nAll Task gates/same-head CI and final source review remain pending. See current summary and exact approved011 decision.\n\n'+commands.read_bytes())
paths=sorted(set(candidate['files'])|{result_ref,index_ref,'specs/tasks/POC-005.md',
    'evidence/POC-005/summary.md','evidence/POC-005/handoff.md','evidence/POC-005/commands.txt'}|
    {p.relative_to(r).as_posix() for p in decision.iterdir() if p.is_file()})
assert len(paths)==19
out=t/'poc005-attempt011-formal-profile-context-v1'
out.mkdir()
for offset in range(0,len(paths),30):g('add','--',*paths[offset:offset+30])
assert sorted(g('diff','--cached','--name-only').decode().splitlines())==paths
for name in paths:assert g('show',':'+name)==(r/name).read_bytes(),name
started=datetime.now(timezone.utc).isoformat()
argv=['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),'commit','-m',
      'chore(POC-005): record current011 approved local profile result','-m','Refs #132. Preserve exact concrete-actor decision, full raw qualification, original negative report and retention facts. Formal profile/source gates pending.']
with (out/'commit.stdout.raw').open('xb') as stdout,(out/'commit.stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    code=child.wait()
assert code==0 and not g('status','--porcelain')
head=g('rev-parse','HEAD').decode().strip()
tree=g('rev-parse','HEAD^{tree}').decode().strip()
assert g('rev-parse','HEAD^').decode().strip()==parent
assert sorted(g('diff','--name-only',parent,head).decode().splitlines())==paths
bundle=t/('poc005-attempt011-formal-profile-'+head[:7]+'.bundle')
assert not bundle.exists()
g('bundle','create',str(bundle),branch)
result=dict(kind='ACTUAL_TRACKED_CURRENT011_APPROVED_PROFILE_CANDIDATE_NOT_FORMAL_VALIDATION',
            parent=parent,head=head,tree=tree,branch=branch,paths=paths,rawBytesEqualStagedBlobs=True,
            commitPid=child.pid,commitStartedAt=started,commitEndedAt=datetime.now(timezone.utc).isoformat(),
            actualCommitWaitCompleted=True,commitExitCode=code,trackedTreeClean=True,
            independentExitReviewSha256=pin(review_raw)['sha256'],bundle=str(bundle),bundlePin=pin(bundle.read_bytes()),
            formalProfileValidated=False,sourceQualified=False,published=False,taskCompleted=False)
with (out/'results.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('paths','bundlePin')}))
