"""Fast-forward only source-bound metadata; preserve all legacy untracked data."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
t=Path(__file__).resolve().parent;w=t/'poc005-feature-actor-import-v1';out=t/'poc005-attempt011-author-evidence-integration-v1';out.mkdir()
source='15dcd6cd22a576821cdbe0f936002ad9a1be69e3';target='8aa353c42c98aa62d147d0d3295b836f021537d6'
receipt=json.loads((t/'poc005-attempt011-tracked-validation-context.json').read_bytes())
assessment=t/'poc005-attempt011-full-execution-validation-independent-review.json'
assert hashlib.sha256(assessment.read_bytes()).hexdigest()=='0e020d2391ef57860cd6c5c36f09171930fbccb11c14c08936e6d68363a65080'
assert json.loads(assessment.read_bytes())['qualificationAccepted']
bundle=t/receipt['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt['bundleSha256']=='2e6bdc97826ed3dba09fa483b1fbc9777270954b17c8a509b0c12ad20079914f'
def g(*a):return subprocess.check_output(['git','-c','core.longpaths=true','-C',str(w),*a])
assert g('rev-parse','HEAD').decode().strip()==source and g('branch','--show-current').decode().strip()=='chore/POC-005-metadata-scale'
assert not g('diff','--name-only') and not g('diff','--cached','--name-only')
legacy=g('ls-files','--others','--exclude-standard','-z');legacy_paths=set(legacy.split(b'\0')[:-1]);assert len(legacy_paths)==0
incoming=receipt['changedPaths'];assert len(incoming)==11274 and not legacy_paths.intersection(p.encode() for p in incoming)
assert all(p.startswith(('evidence/POC-005/profiles/local-v1/v1/attempt-011/','evidence/POC-005/profiles/local-v1/v1/inputs-1m-attempt011/')) for p in incoming)
commands=[]
def run(label,*args):
 argv=['git','-c','core.longpaths=true','-C',str(w),*args];started=datetime.now(timezone.utc).isoformat()
 with (out/(label+'.stdout.raw')).open('xb') as stdout,(out/(label+'.stderr.raw')).open('xb') as stderr:
  child=subprocess.Popen(argv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW);code=child.wait()
 commands.append({'argv':argv,'pid':child.pid,'actualWaitCompleted':True,'exitCode':code,'startedAt':started,'finishedAt':datetime.now(timezone.utc).isoformat()})
 if code:raise RuntimeError(label+' failed; no reset/rebase/replay')
run('fetch-qualified-bundle','fetch','--no-tags',str(bundle),'chore/POC-005-metadata-scale')
assert g('rev-parse','FETCH_HEAD').decode().strip()==target
assert g('show','-s','--format=%P',target).decode().strip()==source
assert set(g('diff','--name-only',source,target).decode().splitlines())==set(incoming)
run('fast-forward-evidence','merge','--ff-only',target)
assert g('rev-parse','HEAD').decode().strip()==target and g('rev-parse','HEAD^{tree}').decode().strip()==receipt['validationContextTree']
assert g('ls-files','--others','--exclude-standard','-z')==legacy
assert not g('diff','--name-only') and not g('diff','--cached','--name-only')
result={'kind':'ACTUAL_LOCAL_SOURCE_BOUND_EVIDENCE_FAST_FORWARD_NOT_RUNTIME_OR_MAIN_ACCEPTANCE',
 'parent':source,'head':target,'tree':receipt['validationContextTree'],'paths':len(incoming),
 'legacyUntrackedCount':len(legacy_paths),'legacyUntrackedPathNulSha256':hashlib.sha256(legacy).hexdigest(),
 'legacyUntrackedPathsUnchanged':True,'legacyFilesDeleted':False,'trackedTreeClean':True,
 'commands':commands,'published':False,'profileTerminalIndexAccepted':False,'taskCompleted':False}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='commands'}))
