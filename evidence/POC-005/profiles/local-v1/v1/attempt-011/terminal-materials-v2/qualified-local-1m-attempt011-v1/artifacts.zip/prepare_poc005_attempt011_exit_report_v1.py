"""Prepare an unapproved source-labelled local exit report from qualified011 facts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile
import yaml

t = Path(__file__).resolve().parent
r = t / 'poc005-feature-actor-import-v1'
parent = '8aa353c42c98aa62d147d0d3295b836f021537d6'
g = lambda *a: subprocess.check_output(['git', '-c', 'core.longpaths=true', '-C', str(r), *a], text=True).strip()
assert g('rev-parse', 'HEAD') == parent and not g('status', '--porcelain')
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
pin = lambda raw: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
review_path = t / 'poc005-attempt011-full-execution-validation-independent-review.json'
assert pin(review_path.read_bytes())['sha256'] == '0e020d2391ef57860cd6c5c36f09171930fbccb11c14c08936e6d68363a65080'
review = read(review_path)
assert review['qualificationAccepted'] and review['formalProfileTerminalMaterialsPreparationMayProceed'] and not review['mustFix']
relative = Path('evidence/POC-005/profiles/local-v1/v1/attempt-011/execution-candidate.json')
execution = read(r / relative)
assert execution['executor'] == '/root' and execution['environmentCaptured']['testedSource']['commit'] == '15dcd6cd22a576821cdbe0f936002ad9a1be69e3'
metrics = {row['id']: row['actual'] for row in execution['measurements']}
assert len(metrics) == 13 and metrics['file_count'] == 1000000
profiling = read(r / execution['environmentCaptured']['metadataProfilingRef'])
scan = read(r / execution['environmentCaptured']['metadataScanRef'])
retention_path = t / 'poc005-attempt011-environment-close-observation-v1/results.json'
retention = read(retention_path)
assert retention['actualWaitCompleted'] and retention['exitCode'] == 0
assert not retention['observation']['providerProcessPresent'] and retention['observation']['matchingListenerCount'] == 0
assert len(retention['retainedDatabases']) == 10 and not retention['filesDeleted']
out = r / 'evidence/POC-005/qualified-local-1m-attempt011-v1'
out.mkdir()
origins = [
    t / 'poc005-attempt011-resource-preparation-result-independent-review.json',
    t / 'poc005-attempt011-full-template-independent-review.json',
    t / 'poc005-attempt011-final-reservation-independent-review.json',
    t / 'poc005-attempt011-observations-independent-review.json',
    t / 'poc005-attempt011-tracked-validation-context.json', review_path,
    t / 'poc005-profile-retirement-final-source-independent-review.json',
    t / 'poc005-profile-retirement-ci896/analysis.json',
    t / 'validate_poc005_attempt011_full_execution.py',
    t / 'import_poc005_qualified_attempt011_evidence_once.py',
    t / 'observe_poc005_attempt011_retained_environment_once.py', Path(__file__),
]
for folder in ('poc005-attempt011-full-validation-run', 'poc005-attempt011-full-execution-validation',
               'poc005-attempt011-author-evidence-integration-v1', 'poc005-attempt011-environment-close-observation-v1'):
    origins.extend(p for p in sorted((t / folder).iterdir()) if p.is_file())
assert len(origins) == len(set(origins)) and all(p.is_file() and p.stat().st_size < 64 * 1024 * 1024 for p in origins)
entries = []
with zipfile.ZipFile(out / 'artifacts.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for p in origins:
        raw = p.read_bytes()
        name = p.relative_to(t).as_posix()
        archive.writestr(name, raw)
        entries.append(dict(ref=name, **pin(raw), original=str(p)))
with zipfile.ZipFile(out / 'artifacts.zip') as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(entries)
    for row in entries:
        assert pin(archive.read(row['ref'])) == {k: row[k] for k in ('bytes', 'sha256')}
index = dict(kind='QUALIFIED_CURRENT011_LOCAL_EXECUTION_NOT_FORMAL_PROFILE_EXIT',
             preparedAt=datetime.now(timezone.utc).isoformat(), source=execution['environmentCaptured']['testedSource'],
             validationContext=parent, executionRef=relative.as_posix(), executionPin=pin((r / relative).read_bytes()),
             archive='artifacts.zip', archivePin=pin((out / 'artifacts.zip').read_bytes()), entries=entries,
             original13Accepted=True, completeFrozenExecutionQualificationAccepted=True,
             profileExitDecisionApproved=False, formalProfileValidated=False, taskCompleted=False)
with (out / 'index.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
report = r / 'evidence/POC-005/local-v1-scale-exit-report-attempt011-v1.md'
plan = yaml.safe_load((r / 'specs/poc/plans/POC-005.yaml').read_text(encoding='utf-8'))
lines = [
    '# POC-005 local-v1 百万规模退出报告：15d / attempt011', '',
    '本报告供独立退出审查。实际原13项观察和完整冻结执行资格已接受；正式profile退出结果、完整profile命令、新材料源检查/CI、主线及任务收口尚待办理。', '',
    '执行源为 `15dcd6cd22a576821cdbe0f936002ad9a1be69e3`，完整tracked验证上下文为 `8aa353c42c98aa62d147d0d3295b836f021537d6`。实际实现者 `/root`，独立审查者 `/root/gz022_planning_independent_review`。唯一主执行为 [011 execution](profiles/local-v1/v1/attempt-011/execution-candidate.json)；历史008/009/010只保留其原来源与判断，不向011转移资格。', '',
    '## 五项退出条件与原13项观察', '',
    '| 原测量 | 实际结果 | 单位 |', '| --- | --- | --- |',
]
for row in plan['protocol']['measurements']:
    lines.append('| ' + row['id'] + ' | ' + json.dumps(metrics[row['id']], ensure_ascii=False) + ' | ' + row['unit'] + ' |')
lines += [
    '', '1. 固定来源中实测100万文件、500目录、最大深度12及平均1792字节；实际负载总计1,792,000,000字节。6000请求/分钟来自本地适配器批准配额文档，不是百度或生产提供方额度。',
    '2. 实际create/update/delete各一项，变更窗口为 `' + scan['changeStream']['startedAt'] + '`–`' + scan['changeStream']['finishedAt'] + '`；频率由3次变化和该窗口计算，不能外推生产变更率。',
    '3. 枚举、独立文件名观察、两次完整来源遍历与后置完整版本清单覆盖同一固定总体；2770个分页记录对应两次各1385页、各1000500对象。原始目录/文件名/深度、完整比较、分页和quota/故障事实均由已接受的冻结校验核验。',
    '4. 枚举窗口为 `' + scan['enumeration']['startedAt'] + '`–`' + scan['enumeration']['finishedAt'] + '`；1981.6786164472037对象/秒仅描述scanner枚举阶段。两次完整OpenList来源遍历、受控变化、完整后置观察与故障/探针耗时另计，不能把该速率当端到端接入吞吐。增量实测0.0311704秒仅对应此次3项变化；同一scanner原生峰值32.9453125MiB覆盖批准测量窗口。',
    '5. 文件名及提供方行为、Range与ETag按下列来源观察记录；完整原始记录仍在execution引用中。', '',
    '## 来源行为与规模模型', '',
    '文件名分布：', '', '```json', json.dumps(profiling['filenameDistributions'], ensure_ascii=False, indent=2), '```', '',
    '来源页实际使用稳定对象/版本、目录父子关系和游标；本次两轮终止且全量一致。探针状态依次为200、200、206、416、200；416正文完整保留33字节。ETag对未变对象稳定，受控更新后改变。四项故障案例保留其真实请求、回退/重试和拒绝记录，未把单元夹具当实际来源故障。', '',
    '规模由文件数、目录扇出/深度、名称分布、来源分页和变更率联合决定；每页最多128对象且有字节预算，扫描检查点/索引持久化而不把百万条记录全部驻留内存。实际模型仅覆盖这套本地合成总体与OpenList适配器。生产约700TB的文件规模、真实提供方配额、变化分布和成本仍须独立测量；不得按1792字节平均值推算700TB文件数、时长或费用。直接全枚举成本过高时，按原方案评估变更日志/token、分阶段索引和有界退避；这些未来替代方案不继承本次性能结果。', '',
    '## 真实终态、保留与漂移', '',
    '原supervisor/controller/scanner已于2026-10-28T04:46:13Z实际正常退出。完整冻结 `validate_execution(status=pass)` 在干净tracked上下文实际退出0、errors=[]、源码/树未变，内部耗时2445.874020秒；其原始调用、结果及独立接受保存在[资格材料索引](qualified-local-1m-attempt011-v1/index.json)。Windows约41分钟构成原30分钟CI预算风险，尚无Ubuntu必然超时的证据；原门禁和所有检查保持。', '',
    '2026-10-29的只读原生查询确认原专用provider PID60532已不存在，15535端口没有监听。没有执行新停止动作；provider退出原因、退出时间和退出码未被采集，不能记为自然零退出或本代理已强制停止。精确查询与原始输出见同一资格材料归档。', '',
    '10个原运行数据库仍保留，逻辑字节合计3,169,824,768；fixture、私有OpenList目录和3项受控变更未删除或还原。该DB量与578,050,220字节选定原始材料分别记录。旧失败、身份不合格索引和原始许可/窗口保留原归属。凭据与私有配置未读取或复制到Git；本次不声称文件系统已还原。', '',
    '## 正式退出与后继', '',
    '独立审查本报告后，以实际审查身份和当时时间形成当前011的单一result。保留旧result，当前profile index只能引用新011结果。真实Git上下文中必须完整运行：', '',
    '```text', 'python specs/poc/check_program.py --profile local-v1 --require-results --poc POC-05', '```', '',
    '随后仍须新材料源全部Task检查、同头CI、独立源/结果接受、普通集成与实际主线验证，以及正常Review/Completion。本地退出不替代生产规模/提供方义务、完整Task或完整V1验收。', '',
]
with report.open('x', encoding='utf-8', newline='\n') as f:
    f.write('\n'.join(lines))
candidate = dict(kind='UNAPPROVED_CURRENT011_EXIT_REPORT', parent=parent,
                 files={p.relative_to(r).as_posix():pin(p.read_bytes()) for p in (report, out / 'index.json', out / 'artifacts.zip')},
                 source=execution['environmentCaptured']['testedSource'],
                 executionRef=relative.as_posix(), frozenQualificationReviewSha256=pin(review_path.read_bytes())['sha256'],
                 profileExitApproved=False, formalProfileValidated=False)
with (t / 'poc005-attempt011-exit-report-v1-current-candidate.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(candidate, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report':str(report), 'reportPin':pin(report.read_bytes()), 'qualificationArchiveEntries':len(entries),
                  'archivePin':index['archivePin'], 'profileExitApproved':False}))
