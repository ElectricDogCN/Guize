"""Observe already absent private provider and retained files; never stop or delete."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

t = Path(__file__).resolve().parent
out = t / 'poc005-attempt011-environment-close-observation-v1'
out.mkdir()
command = ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
    "$ErrorActionPreference='Stop'; $providerProcess=Get-CimInstance Win32_Process -Filter 'ProcessId=60532'; $allListeners=@(Get-NetTCPConnection -State Listen); $matching=@($allListeners | Where-Object { $_.LocalPort -eq 15535 }); [pscustomobject]@{providerPid=60532; providerProcessPresent=($null -ne $providerProcess); matchingListenerCount=$matching.Count; owningPids=@($matching | Select-Object -ExpandProperty OwningProcess)} | ConvertTo-Json -Compress; if (($null -ne $providerProcess) -or ($matching.Count -ne 0)) { exit 1 }"]
started = datetime.now(timezone.utc).isoformat()
with (out / 'stdout.raw').open('xb') as stdout, (out / 'stderr.raw').open('xb') as stderr:
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    code = child.wait()
observation = json.loads((out / 'stdout.raw').read_text(encoding='utf-8-sig')) if code == 0 else None
runtime = t / 'poc005-attempt011-runtime-15dcd6c'
slot = runtime / 'evidence/POC-005/profiles/local-v1/v1/attempt-011'
databases = []
for path in sorted(slot.rglob('*')):
    if path.is_file() and path.suffix == '.sqlite':
        info = path.stat()
        databases.append(dict(relativeToRuntime=path.relative_to(runtime).as_posix(), bytes=info.st_size,
                              modifiedTimeNs=info.st_mtime_ns))
fixture = Path('C:/Users/13997/.codex/local-lab/poc005-native-windows-v8-1m-attempt011/fixture')
provider = Path('C:/Users/13997/.codex/local-lab/poc005-windows-openlist-v8-1m-attempt011')
result = dict(kind='ACTUAL_ABSENCE_AND_RETENTION_OBSERVATION_NOT_PROVIDER_EXIT_RECEIPT',
              startedAt=started, finishedAt=datetime.now(timezone.utc).isoformat(),
              argv=command, pid=child.pid, exitCode=code, actualWaitCompleted=True,
              observation=observation, terminationRequested=False, providerExitCodeObserved=False,
              providerExitCauseObserved=False, earlierProviderIdentityCreation100ns=134376322844061664,
              filesDeleted=False, credentialsReadOrChanged=False, configurationRestored=False,
              fixturePresent=fixture.is_dir(), privateProviderDirectoryPresent=provider.is_dir(),
              retainedDatabases=databases, retainedDatabaseLogicalBytes=sum(x['bytes'] for x in databases),
              stdoutSha256=hashlib.sha256((out / 'stdout.raw').read_bytes()).hexdigest(),
              stderrSha256=hashlib.sha256((out / 'stderr.raw').read_bytes()).hexdigest(),
              experimentRerun=False)
with (out / 'results.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
assert code == 0 and observation['providerProcessPresent'] is False and observation['matchingListenerCount'] == 0
assert fixture.is_dir() and provider.is_dir() and len(databases) == 10
print(json.dumps({'actualWaitCompleted':True, 'exitCode':code, 'providerAbsent':True,
                  'matchingListeners':0, 'retainedDatabaseCount':len(databases),
                  'retainedDatabaseLogicalBytes':result['retainedDatabaseLogicalBytes'],
                  'providerExitCodeObserved':False, 'filesDeleted':False}))
