"""Normal canonical FF and full recovery bundle after accepted ordinary POC003 migration merge."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
T=Path(__file__).resolve().parent;R=T.parent/'Guize'
import argparse
p=argparse.ArgumentParser();p.add_argument('--actual-main',required=True);args=p.parse_args()
H=args.actual_main;c=json.loads((T/'poc003-blocked-lease-v2-current-candidate.json').read_bytes());S,B,TREE=c['source'],c['base'],c['tree']
assert len(H)==40 and all(c in '0123456789abcdef' for c in H)
git=lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*a]).decode().strip()
review=json.loads((T/'poc003-blocked-lease-v2-source-final-independent-review.json').read_bytes());assert review['source']==S and review['base']==B and review['tree']==TREE and review['actualMergeApproved'] and review['fullCiAccepted'] and not review['mustFix']
merge=json.loads((T/'poc003-blocked-lease-v2-merge-api-result-v1.json').read_bytes())['structuredContent'];assert merge['merged'] and merge['sha']==H
assert git('rev-parse','HEAD')==B and git('branch','--show-current')=='main' and not git('status','--porcelain=v1','--untracked-files=all')
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[H,'refs/heads/main']
refs=lambda:dict(line.split(' ',1) for line in git('for-each-ref','--format=%(refname) %(objectname)').splitlines())
before=refs();out=T/('poc003-blocked-lease-v2-'+H[:7]+'-canonical-main');out.mkdir()
result=dict(actualMain=H,source=S,base=B,tree=TREE,beforeRefs=before,commands=[],startedAt=datetime.now(timezone.utc).isoformat(),actualMainAccepted=False,fullMainCiAccepted=False,newExperimentApproved=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(label,*a):
 argv=['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*a]
 with (out/(label+'.stdout.raw')).open('xb') as stdout,(out/(label+'.stderr.raw')).open('xb') as stderr:
  p=subprocess.Popen(argv,stdout=stdout,stderr=stderr);code=p.wait()
 result['commands'].append(dict(label=label,argv=argv,pid=p.pid,actualWaitCompleted=True,exitCode=code));save();assert code==0
# Install only repository-local filters; hydrate from the exact reviewed raw
# recovery object. Official source/main CI separately proves remote download.
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
raw=(T/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
assert len(raw)==4096 and hashlib.sha256(raw).hexdigest()==oid
cache=R/'.git/lfs/objects'/oid[:2]/oid[2:4]
cache.mkdir(parents=True,exist_ok=True)
object_file=cache/oid
if object_file.exists():
 assert object_file.read_bytes()==raw
else:
 with object_file.open('xb') as f:f.write(raw)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:
 run('repo-local-'+key.rsplit('.',1)[1],'config','--local',key,value)
run('fetch','fetch','origin','refs/heads/main:refs/remotes/origin/main')

assert git('rev-parse','origin/main')==H and git('show','-s','--format=%P',H).split()==[B,S] and git('rev-parse',H+'^{tree}')==TREE
run('ff-only','merge','--ff-only','origin/main')
assert git('rev-parse','HEAD')==H and git('branch','--show-current')=='main' and not git('status','--porcelain=v1','--untracked-files=all')
assert (R/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==raw
result['probeHydrationMode']='exact verified local LFS cache; remote hydration separately required by official CI'
after=refs();allowed={'refs/heads/main','refs/remotes/origin/main','refs/remotes/origin/HEAD'}
assert set(before)==set(after) and all(before[k]==after[k] for k in before if k not in allowed)
bundle=T/('poc003-blocked-lease-v2-actual-main-'+H[:7]+'-full.bundle');assert not bundle.exists()
run('bundle','bundle','create',str(bundle),'--all')
h=hashlib.sha256()
with bundle.open('rb') as f:
 for block in iter(lambda:f.read(65536),b''):h.update(block)
candidate=dict(actualMain=H,source=S,base=B,tree=TREE,parents=[B,S],bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=h.hexdigest(),canonical=str(R),canonicalClean=True,actualMainSevenAllExitZero=False,fullMainCiAccepted=False,leaseMaintenanceMainAccepted=False,createdAt=datetime.now(timezone.utc).isoformat())
with (T/'poc003-blocked-lease-v2-actual-main-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(candidate,indent=2)+'\n')
result.update(afterRefs=after,preservedOtherReferences=True,canonicalClean=True,bundle=candidate['bundle'],bundleBytes=candidate['bundleBytes'],bundleSha256=candidate['bundleSha256'],finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(candidate))
