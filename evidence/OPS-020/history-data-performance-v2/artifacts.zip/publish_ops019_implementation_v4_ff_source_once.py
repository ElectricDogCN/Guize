"""Advance exactly one reviewed source ref by ordinary fast-forward; no LFS upload."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess
import yaml
t=Path(__file__).resolve().parent
S='3459ded7edd0623908d869cf1d57507896065f16'
M='7d82fb61f434f57bb97cb9d80f4613cee3be2721'
TREE='3a8d79f2db5abfe25403fb1ff2e8630225119eee'
OLD='2e6ef2d3fc07d1c91aaf99db7071e92efd354dfc'
B='chore/OPS-019-controlled-lfs-delivery'
REF='refs/heads/'+B
OID='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
R=t/'ops019-controlled-lfs-implementation-v1'
URL='https://github.com/ElectricDogCN/Guize.git'
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);args=p.parse_args()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
review_path=t/'ops019-implementation-v4-publication-independent-review.json'
assert sha(review_path)==args.review_sha256
review=read(review_path)
assert review['source']==S and review['base']==M and review['tree']==TREE
assert review['publicationApproved'] and review['ordinaryFastForwardPublicationApproved'] and not review['mustFix']
assert review['expectedOldRemoteSha']==OLD and review['noLfsUpload'] is True
assert review['publisherMethodSha256']==sha(__file__)
candidate_path=t/'ops019-implementation-v4-current-candidate.json'
assert review['candidateSha256']==sha(candidate_path)
candidate=read(candidate_path)
assert candidate['source']==S and candidate['base']==M and candidate['tree']==TREE and candidate['branch']==B
for name,key in [('ops019-implementation-v1-native-specialized-v9','specializedChecksPassed'),
                 ('ops019-implementation-v1-native-source14-v4','declared14Passed')]:
    folder=t/name;data=read(folder/'results.json')
    assert data['source']==S and data[key] and review['validationResultsSha256'][name]==sha(folder/'results.json')
    for row in data['commands']:
        raw=folder/row['raw']
        assert row['actualWaitCompleted'] and row['exitCode']==0 and raw.stat().st_size==row['bytes'] and sha(raw)==row['sha256']
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
def git(*argv):
    return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*argv],
                                   env=env,timeout=120).decode().strip()
assert git('rev-parse','HEAD')==S and git('rev-parse','HEAD^{tree}')==TREE
assert git('branch','--show-current')==B and git('merge-base',M,S)==M
assert git('show','-s','--format=%P',S)==OLD and git('merge-base',OLD,S)==OLD
assert set(git('diff','--name-only',OLD,S).splitlines())=={'scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py','evidence/OPS-019/implementation-v1/README.md','evidence/OPS-019/implementation-v1/ci943-cancelled.json'}
for file in git('diff','--name-only',OLD,S).splitlines():
    assert git('check-attr','filter','--',file).endswith(': unspecified')
assert git('status','--porcelain=v1','--untracked-files=all')==''
assert git('diff','--name-only',M,S).splitlines()==candidate['changedPaths']
for row in candidate['fileSnapshot']:
    assert (R/row['path']).stat().st_size==row['bytes'] and sha(R/row['path'])==row['sha256']
assert git('remote','get-url','origin')==URL
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main']
assert git('ls-remote','--heads','origin',REF).split()==[OLD,REF]
active=yaml.safe_load((R/'specs/coordination/active-work.yaml').read_bytes())
own=next(row for row in active['tasks'] if row['taskId']=='OPS-019')
assert own['status']=='in_progress' and own['agentRole']=='implementer' and own['baseSha']==M and own['branch']==B
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
assert len(active['tasks'])==3 and sum(row['riskLevel'] in {'high','critical'} for row in active['tasks'])==1
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
probe=R/'evidence/OPS-019/implementation-v1/lfs-probe.bin'
cached=R/'.git/lfs/objects'/OID[:2]/OID[2:4]/OID
assert probe.stat().st_size==cached.stat().st_size==4096 and sha(probe)==sha(cached)==OID
pointer=subprocess.check_output(['git','-C',str(R),'show',S+':evidence/OPS-019/implementation-v1/lfs-probe.bin'])
assert pointer==('version https://git-lfs.github.com/spec/v1\noid sha256:'+OID+'\nsize 4096\n').encode()
out=t/'ops019-implementation-v4-publication'
out.mkdir()
results=dict(source=S,base=M,tree=TREE,branch=B,expectedOldRemoteSha=OLD,publicationReviewSha256=args.review_sha256,
             startedAt=datetime.now(timezone.utc).isoformat(),operations=[],fullCiAccepted=False,
             actualMergeApproved=False,actualMigrationApproved=False,largePocMediaUploaded=False)
save=lambda:(out/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
def run(label,argv):
    row=dict(label=label,argv=argv,startedAt=datetime.now(timezone.utc).isoformat())
    with (out/(label+'.stdout.raw')).open('xb') as so,(out/(label+'.stderr.raw')).open('xb') as se:
        child=subprocess.Popen(argv,env=env,stdout=so,stderr=se)
        row['pid']=child.pid;results['operations'].append(row);save()
        code=child.wait()
    row.update(exitCode=code,actualWaitCompleted=True,finishedAt=datetime.now(timezone.utc).isoformat())
    save()
    assert code==0,label+' failed; preserve raw output'
# All LFS pointer/attribute bytes are unchanged from the previously uploaded
# source. Four ordinary text changes need only the single guarded ref update.
assert subprocess.check_output(['git','-C',str(R),'show',OLD+':evidence/OPS-019/implementation-v1/lfs-probe.bin'])==pointer
assert git('diff',OLD,S,'--','evidence/OPS-019/.gitattributes')==''
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main']
assert git('ls-remote','--heads','origin',REF).split()==[OLD,REF]
hooks=out/'hooks';hooks.mkdir()
(hooks/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n  test "$local_ref" = "'+REF+'"\n  test "$local_sha" = "'+S+'"\n  test "$remote_ref" = "'+REF+'"\n  test "$remote_sha" = "'+OLD+'"\n  count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf-8',newline='\n')
run('single-source-ref-push',['git','-c','core.longpaths=true','-c','credential.interactive=never',
    '-c','core.hooksPath='+hooks.as_posix(),'-C',str(R),'push','--porcelain','origin',REF+':'+REF])
actual=git('ls-remote','--heads','origin',REF).split()
assert actual==[S,REF] and git('status','--porcelain=v1','--untracked-files=all')==''
results.update(finishedAt=datetime.now(timezone.utc).isoformat(),actualRemoteAfter=actual,
               existingUnchangedLfsObject={'oid':OID,'bytes':4096},newLfsBytesUploaded=0,forceOptionUsed=False)
save()
print(json.dumps(dict(source=S,published=True,newLfsBytesUploaded=0,fullCiAccepted=False)),flush=True)
