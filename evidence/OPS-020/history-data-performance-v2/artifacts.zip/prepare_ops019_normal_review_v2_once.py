"""Prepare a normal metadata-only Review only after accepted implementation main."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,json,os,re,subprocess
import yaml
t=Path(__file__).resolve().parent
canonical=t.parent/'Guize'
author=t/'ops019-controlled-lfs-review-v1'
branch='chore/OPS-019-controlled-lfs-review'
source='3459ded7edd0623908d869cf1d57507896065f16'
reservation='7d82fb61f434f57bb97cb9d80f4613cee3be2721'
p=argparse.ArgumentParser();p.add_argument('--main-review-sha256',required=True);args=p.parse_args()
receipt=t/'ops019-implementation-pr187-final-actual-main-independent-review.json'
assert hashlib.sha256(receipt.read_bytes()).hexdigest()==args.main_review_sha256
accepted=json.loads(receipt.read_bytes())
actual=accepted['actualMain']
assert accepted['source']==source and accepted['base']==reservation
assert accepted['actualImplementationMainAccepted'] and accepted['fullMainCiAccepted']
assert accepted['ownMainSevenAccepted'] and not accepted['mustFix']
def git(root,*argv):
    env={key:value for key,value in os.environ.items() if key!='GIT_LFS_SKIP_SMUDGE'}
    return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*argv],env=env)
def dec(root,*argv):
    return git(root,*argv).decode().strip()
assert dec(canonical,'rev-parse','HEAD')==actual and dec(canonical,'branch','--show-current')=='main'
assert not dec(canonical,'status','--porcelain=v1','--untracked-files=all')
assert dec(canonical,'ls-remote','--heads','origin','refs/heads/main').split()==[actual,'refs/heads/main']
assert not dec(canonical,'ls-remote','--heads','origin','refs/heads/'+branch)
assert not author.exists()
subprocess.run(['git','-c','core.longpaths=true','-c','core.autocrlf=false','clone','--no-local',
    '--quiet','--branch','main','--config','core.longpaths=true','--config','core.autocrlf=false',
    str(canonical),str(author)],check=True,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'))
assert not (author/'.git/objects/info/alternates').exists()
git(author,'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git')
git(author,'switch','--no-track','-c',branch,actual)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
data=(t/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
cache=author/'.git/lfs/objects'/oid[:2]/oid[2:4]
cache.mkdir(parents=True,exist_ok=True)
if (cache/oid).exists():
    assert (cache/oid).read_bytes()==data
else:
    with (cache/oid).open('xb') as f:f.write(data)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),
                  ('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:
    git(author,'config','--local',key,value)
git(author,'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin')
assert (author/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data
assert not dec(author,'status','--porcelain=v1','--untracked-files=all')
plan_path='specs/coordination/program-plan.yaml'
active_path='specs/coordination/active-work.yaml'
task_path='specs/tasks/OPS-019.md'
pb=(author/plan_path).read_text(encoding='utf-8')
ab=(author/active_path).read_text(encoding='utf-8')
tb=(author/task_path).read_text(encoding='utf-8')
plan,active=yaml.safe_load(pb),yaml.safe_load(ab)
expected_plan=copy.deepcopy(plan)
own=next(row for row in expected_plan['foundationTasks'] if row['taskId']=='OPS-019')
assert own['status']=='in_progress'
own['status']='review'
updated,count=re.subn(r'(?m)^(  - taskId: OPS-019\n    title: [^\n]+\n    status: )in_progress$',r'\1review',pb)
assert count==1 and yaml.safe_load(updated)==expected_plan
(author/plan_path).write_text(updated,encoding='utf-8',newline='\n')
expected_active=copy.deepcopy(active)
entry=next(row for row in expected_active['tasks'] if row['taskId']=='OPS-019')
assert entry['status']=='in_progress' and entry['agentRole']=='implementer'
assert entry['baseSha']==reservation and entry['branch']=='chore/OPS-019-controlled-lfs-delivery'
assert entry['implementer']=='/root' and entry['reviewer']=='/root/independent_review'
assert datetime.now(timezone.utc)<datetime.fromisoformat(entry['lease']['expiresAt'].replace('Z','+00:00'))
oldbranch,oldbase=entry['branch'],entry['baseSha']
entry.update(status='review',agentRole='reviewer',baseSha=actual,branch=branch)
match=re.search(r'(?ms)^- taskId: OPS-019\n.*?(?=^- taskId:|\Z)',ab)
assert match
block=match[0]
changes=[('status','in_progress','review'),('agentRole','implementer','reviewer'),
         ('baseSha',oldbase,actual),('branch',oldbranch,branch)]
for key,old,new in changes:
    block,count=re.subn(r'(?m)^  '+key+': '+re.escape(old)+'$','  '+key+': '+new,block)
    assert count==1
updated_active=ab[:match.start()]+block+ab[match.end():]
assert yaml.safe_load(updated_active)==expected_active
(author/active_path).write_text(updated_active,encoding='utf-8',newline='\n')
parts=tb.split('---',2)
front,body=parts[1:]
for key,old,new in [('status','in_progress','review'),('agentRole','implementer','reviewer'),
                    ('baseSha',oldbase,actual),('workBranch',oldbranch,branch)]:
    front,count=re.subn(r'(?m)^'+key+': '+re.escape(old)+'$',key+': '+new,front)
    assert count==1
fence=chr(96)*3
sections=list(re.finditer(fence+r'bash\n(.*?)\n'+fence,body,re.S))
assert len(sections)==1
s=sections[0]
commands=s.group(0).replace(oldbase,actual).replace(oldbranch,branch)
body=body[:s.start()]+commands+body[s.end():]
intro='\n\n# Normal Review stage\n\nImplementation main '+actual+' has independent source/main full CI and own-main-seven acceptance. This branch records only the normal independent Review lifecycle and Own Evidence. The mechanism still requires normal Completion and capacity release. A specific conditional migration approval, if independently accepted, is to be introduced in a separate preceding commit during the future normal Completion source; it is not created by this method.\n'
(author/task_path).write_text('---'+front+'---'+intro+body,encoding='utf-8',newline='\n')
evidence=author/'evidence/OPS-019/review-v1'
evidence.mkdir()
(evidence/'accepted-code-main-independent-review.json').write_bytes(receipt.read_bytes())
context=dict(kind='OPS019_NORMAL_REVIEW_METADATA_PREPARATION',base=actual,source=source,branch=branch,
    acceptedImplementationMainReviewSha256=args.main_review_sha256,claims=entry['exclusivePaths'],
    lease=entry['lease'],status='review',agentRole='reviewer',sourceGatePassed=False,
    fullReviewCiAccepted=False,taskCompleted=False,actualPocMigrationApproved=False,
    conditionalMigrationApprovalCreated=False,createdAt=datetime.now(timezone.utc).isoformat())
(evidence/'context.json').write_text(json.dumps(context,indent=2)+'\n',encoding='utf-8',newline='\n')
(evidence/'README.md').write_text('# Normal OPS-019 Review\n\nExact implementation main '+actual+' accepted. Only own lifecycle metadata/Evidence prepared. New14/sourceCI/mainCI remain UNEXECUTED. Completion/capacity release and specific independent prospective approval remain required before any migration.\n',encoding='utf-8',newline='\n')
for name in ['summary.md','handoff.md','commands.txt','test-results/README.md']:
    with (author/'evidence/OPS-019'/name).open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n\n# Normal Review preparation\nBase '+actual+'; branch '+branch+'; review/reviewer. Implementation acceptance is source-bound; this metadata source still requires its own complete checks and CI. Original lease/claims/actors unchanged.\n')
assert hashlib.sha256((author/'evidence/OPS-019/delivery-migration-intent.json').read_bytes()).hexdigest()=='6a563cd81331c9ebc6141e12f1b678b9e97a808daeb816d5b2c4794abbc9cec4'
assert not (author/'evidence/OPS-019/implementation-v1/migration-approval.json').exists()
for path in entry['exclusivePaths']+['specs/poc/program.schema.yaml','specs/poc/program.yaml',
    'specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md',
    'specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
    assert (author/path).read_bytes()==git(author,'show',actual+':'+path)
paths=sorted(set(dec(author,'diff','--name-only').splitlines())|
             set(dec(author,'ls-files','--others','--exclude-standard').splitlines()))
assert all(path in {plan_path,active_path,task_path} or path.startswith('evidence/OPS-019/') for path in paths)
with (t/'ops019-normal-review-v1-precommit.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(dict(context,author=str(author),changedPaths=paths),indent=2)+'\n')
print(json.dumps(dict(base=actual,branch=branch,metadataPaths=len(paths),conditionalApprovalCreated=False)),flush=True)
