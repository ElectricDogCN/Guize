"""Fast-forward exactly the existing registered POC005 remote after precise review."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args();t=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
rp=t/'poc005-registered-ip-lease-v1-publication-independent-review.json';assert sha(rp.read_bytes())==a.review_sha256
r=json.loads(rp.read_bytes());assert r['publicationApproved'] and not r['mustFix'] and r['publisherMethodSha256']==sha(Path(__file__).read_bytes())
c=json.loads((t/'poc005-registered-ip-lease-v1-current-candidate.json').read_bytes());S,B,BRANCH=c['source'],c['base'],c['branch'];REF='refs/heads/'+BRANCH;R=Path(c['author'])
assert (r['source'],r['base'])==(S,B) and BRANCH=='chore/POC-005-metadata-scale'
assert datetime.now(timezone.utc)<datetime.fromisoformat(c['leaseExpiresAt'].replace('Z','+00:00'))
results=t/'poc005-registered-ip-lease-v1-native-source15';checks=json.loads((results/'results.json').read_bytes())
assert checks['source']==S and checks['base']==B and checks['declared15Passed'] and checks['before']==checks['after'] and len(checks['commands'])==15
for row in checks['commands']:
 raw=(results/row['raw']).read_bytes();assert row['actualWaitCompleted'] and row['exitCode']==0 and len(raw)==row['bytes'] and sha(raw)==row['sha256']
cr=json.loads((t/'poc003-blocked-lease-v2-merge-api-result-v1.json').read_bytes())['structuredContent'];assert cr['merged'] and cr['sha']==B
# Publication of this reversible metadata candidate does not claim parent main-CI acceptance.
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
def git(*x):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*x],env=env).decode().strip()
assert git('rev-parse','HEAD')==S and git('rev-parse','HEAD^{tree}')==c['tree'] and git('show','-s','--format=%P',S).split()==c['expectedParents'] and git('branch','--show-current')==BRANCH and not git('status','--porcelain=v1','--untracked-files=all')
assert git('diff','--name-only',B,S).splitlines()==c['changedPaths'] and len(c['changedPaths'])==13
for pin in c['fileSnapshot']:
 raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
assert sha((R/'evidence/OPS-019/implementation-v1/migration-approval.json').read_bytes())=='758bb3faea013495648de11bbb450642dd327c4b224ebe037557d25904c6d185'
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[B,'refs/heads/main'] and git('ls-remote','--heads','origin',REF).split()==[c['expectedOldRemoteTip'],REF]
assert git('merge-base',c['expectedOldRemoteTip'],S)==c['expectedOldRemoteTip']
assert git('remote','get-url','origin')=='https://github.com/ElectricDogCN/Guize.git'
O=t/'poc005-registered-ip-lease-v1-publication';O.mkdir();H=O/'hooks';H.mkdir()
(H/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n test "$local_ref" = "'+REF+'"\n test "$local_sha" = "'+S+'"\n test "$remote_ref" = "'+REF+'"\n test "$remote_sha" = "'+c['expectedOldRemoteTip']+'"\n count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf-8',newline='\n')
argv=['git','-c','core.longpaths=true','-c','credential.interactive=never','-c','core.hooksPath='+H.as_posix(),'-C',str(R),'push','--porcelain','origin',REF+':'+REF]
result=dict(source=S,base=B,branch=BRANCH,argv=argv,publicationReviewSha256=a.review_sha256,startedAt=datetime.now(timezone.utc).isoformat(),actualWaitCompleted=False,forceUsed=False,fullCiAccepted=False,actualMigrationAccepted=False)
save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');save()
with (O/'stdout.raw').open('xb') as so,(O/'stderr.raw').open('xb') as se:
 child=subprocess.Popen(argv,env=env,stdout=so,stderr=se);result['pid']=child.pid;save();code=child.wait();result.update(actualWaitCompleted=True,exitCode=code,finishedAt=datetime.now(timezone.utc).isoformat());save()
assert code==0
remote=git('ls-remote','--heads','origin',REF).split();result['actualRemoteAfter']=remote;save();assert remote==[S,REF] and not git('status','--porcelain=v1','--untracked-files=all')
result['postValidationPassed']=True;save();print(json.dumps(dict(source=S,base=B,branch=BRANCH,actualWaitExitCode=code,postValidationPassed=True)),flush=True)
