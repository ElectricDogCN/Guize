"""Read-only exact Completion merge preflight. Never merges or releases capacity."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,yaml
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);p.add_argument('--method-review-sha256',required=True);p.add_argument('--pr',type=int,required=True);p.add_argument('--run',type=int,required=True);p.add_argument('--job',type=int,required=True);a=p.parse_args()
t=Path(__file__).resolve().parent
read=lambda n:json.loads((t/n).read_bytes())
sha=lambda n:hashlib.sha256((t/n).read_bytes()).hexdigest()
c=read('ops019-normal-completion-v2-current-candidate.json');S,B,TREE=c['source'],c['base'],c['tree']
assert (S,B,TREE)==('c58089f4d97546591d98ebc4151cad0502e4ada9','daede2ac652f03d05fcdf22c40504edde07067ac','effe74ec476e11b81d0e0a5d8bc581f5ec6c125b')
rn='ops019-normal-completion-v2-source-final-independent-review.json';assert sha(rn)==a.review_sha256
addendum_name='ops019-normal-completion-v2-direct-guard-independent-addendum.json';assert sha(addendum_name)==a.method_review_sha256
addendum=read(addendum_name);assert addendum['directGuardMethodsAccepted'] and not addendum['mustFix'] and addendum['source']==S and addendum['base']==B and addendum['preflightMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
r=read(rn);assert (r['source'],r['base'],r['tree'])==(S,B,TREE)
assert r['finalSourceAccepted'] and r['fullCiAccepted'] and r['actualMergeApproved'] and not r['mustFix'] and not r.get('bootstrapExceptionAccepted',False)
for pin in r['evidencePins']:
 f=t/pin['path'];assert f.stat().st_size==pin['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
ci=read('ops019-normal-completion-v2-source-ci-final/capture.json')
assert ci['source']==S and ci['base']==B and ci['tree']==TREE and ci['phase']=='source' and ci['pullRequest']==a.pr
assert ci['run']==a.run and ci['job']==a.job and ci['attempt']==1 and ci['conclusion']=='success'
assert ci['uniquePassed']==867 and ci['original842Plus25Exact'] and ci['failedErroredSkippedXfailXpass']==0
assert ci['orderedParents']==[B,S] and ci['totalSteps']==ci['successSteps']==28 and ci['conditionalSkippedSteps']==[] and ci['jobSeconds']<1800 and ci['realLfsFetchAndHydratedProbePassed']
g=read('ops019-normal-completion-v2-fresh-final-merge-guard-direct.json');at=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'));fresh=lambda:0<=(datetime.now(timezone.utc)-at).total_seconds()<120
assert fresh() and g['main']['object']['sha']==B
pr=g['pr'];assert pr['number']==a.pr and pr['state']=='open' and not pr['merged'] and not pr['draft'] and pr['mergeable'] is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==S and pr['head']['ref']==c['branch'] and pr['base']['sha']==B and pr['base']['ref']=='main' and pr['changed_files']==23
assert g['issue']['number']==185 and g['issue']['state']=='closed' and g['issue']['state_reason']=='completed'
run=g['run'];assert run['id']==a.run and run['run_attempt']==1 and run['head_sha']==S and run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert g['jobs']['total_count']==len(g['jobs']['jobs'])==1
job=g['jobs']['jobs'][0];assert job['id']==a.job and job['run_id']==a.run and job['run_attempt']==1 and job['status']=='completed' and job['conclusion']=='success'
assert len(job['steps'])==28 and all(x['status']=='completed' and x['conclusion']=='success' for x in job['steps'])
latest=g['latest']['workflow_runs'];assert latest and latest[0]['id']==a.run and latest[0]['run_attempt']==1 and latest[0]['conclusion']=='success'
assert not any(not x['is_resolved'] for x in g['threads'])
reviews={}
for x in g['reviews']:reviews[x['user']['login']]=x
assert not any(x['state']=='CHANGES_REQUESTED' for x in reviews.values())
git=lambda root,*x:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*x])
dec=lambda root,*x:git(root,*x).decode().strip()
R=Path(c['author'])
for root,head,branch in [(R,S,c['branch']),(t.parent/'Guize',B,'main')]:
 assert dec(root,'rev-parse','HEAD')==head and dec(root,'branch','--show-current')==branch and not dec(root,'status','--porcelain=v1','--untracked-files=all')
assert dec(R,'ls-remote','--heads','origin','refs/heads/main').split()==[B,'refs/heads/main'] and dec(R,'ls-remote','--heads','origin','refs/heads/'+c['branch']).split()==[S,'refs/heads/'+c['branch']]
assert dec(R,'rev-parse',S+'^{tree}')==TREE and dec(R,'diff','--name-only',B,S).splitlines()==c['changedPaths']
assert dec(R,'rev-list','--reverse',B+'..'+S).splitlines()==c['sourceChain'] and c['sourceChain']==[c['approvalCreator'],c['completionMetadataCommit'],S]
assert sha(c['bundle'])==c['bundleSha256']
for pin in c['fileSnapshot']:
 f=R/pin['path'];assert f.stat().st_size==pin['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
old=yaml.safe_load(git(R,'show',B+':specs/coordination/program-plan.yaml'));new=yaml.safe_load(git(R,'show',S+':specs/coordination/program-plan.yaml'))
own=next(x for x in old['foundationTasks'] if x['taskId']=='OPS-019');assert own['status']=='review' and own['completionRef']=='ISSUE-185' and own['mergeCommit'] is None
own.update(status='completed',completionRef='PR-187',mergeCommit='02997ddaee951e054a5ce106e0566847f546d8cd');assert old==new
old=yaml.safe_load(git(R,'show',B+':specs/coordination/active-work.yaml'));new=yaml.safe_load(git(R,'show',S+':specs/coordination/active-work.yaml'))
own=next(x for x in old['tasks'] if x['taskId']=='OPS-019');assert own['status']=='review' and own['agentRole']=='reviewer' and own['branch']=='chore/OPS-019-controlled-lfs-review' and own['baseSha']=='02997ddaee951e054a5ce106e0566847f546d8cd' and own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
old['tasks']=[x for x in old['tasks'] if x['taskId']!='OPS-019'];assert old==new and len(new['tasks'])==2 and not any(x['riskLevel'] in ('high','critical') for x in new['tasks'])
old=git(R,'show',B+':specs/tasks/OPS-019.md').split(b'---',2);new=git(R,'show',S+':specs/tasks/OPS-019.md').split(b'---',2);assert old[2]==new[2]
f=yaml.safe_load(old[1]);f.update(status='completed',agentRole='integrator',baseSha=B,workBranch=c['branch']);assert f==yaml.safe_load(new[1])
APP='evidence/OPS-019/implementation-v1/migration-approval.json';assert hashlib.sha256((R/APP).read_bytes()).hexdigest()==c['conditionalApprovalRecordSha256']
assert dec(R,'show','-s','--format=%P',c['approvalCreator'])==B and dec(R,'diff-tree','--no-commit-id','--name-only','-r',c['approvalCreator']).splitlines()==[APP]
for n in ['.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/coordination/task-completions.yaml','specs/tasks/POC-003.md','specs/tasks/POC-005.md','evidence/OPS-019/delivery-migration-intent.json']:
 assert git(R,'show',B+':'+n)==git(R,'show',S+':'+n)
assert fresh()
result=dict(source=S,base=B,tree=TREE,pullRequest=a.pr,expectedHeadSha=S,mergeMethod='merge',freshGuardPassed=True,fullCiAccepted=True,bootstrapExceptionAccepted=False,sourceReviewSha256=a.review_sha256,capturedAt=g['capturedAt'],checkedAt=datetime.now(timezone.utc).isoformat(),actualMergePerformed=False,directGuardMethodReviewSha256=a.method_review_sha256,authorityNormalCompletionAccepted=False,actualPocMigrationApproved=False)
with (t/'ops019-normal-completion-v2-final-merge-preflight-result.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
