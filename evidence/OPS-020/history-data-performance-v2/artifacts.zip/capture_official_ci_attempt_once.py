"""Preserve one completed official attempt verbatim. Does not declare CI acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,subprocess,urllib.error,urllib.parse,urllib.request
p=argparse.ArgumentParser()
p.add_argument('--run',type=int,required=True);p.add_argument('--attempt',type=int,required=True)
p.add_argument('--expected-head',required=True);p.add_argument('--folder',required=True)
a=p.parse_args();T=Path(__file__).resolve().parent;O=(T/a.folder).resolve()
assert O.is_relative_to(T) and O!=T and not O.exists()
assert a.run>0 and a.attempt>0 and re.fullmatch('[0-9a-f]{40}',a.expected_head)
credential=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never'))
assert credential.returncode==0,'Existing GitHub login unavailable'
fields=dict(line.split(b'=',1) for line in credential.stdout.splitlines() if b'=' in line)
assert fields.get(b'password'),'Existing GitHub login has no credential'
token=fields[b'password'].decode('utf-8')
BASE='https://api.github.com/repos/ElectricDogCN/Guize/'
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
def download(endpoint):
    assert endpoint.startswith(BASE);url=endpoint
    for _ in range(5):
        headers={'User-Agent':'guize-official-attempt-preservation','Accept':'application/vnd.github+json'}
        if url==endpoint:headers['Authorization']='Bearer '+token
        try:response=opener.open(urllib.request.Request(url,headers=headers),timeout=45)
        except urllib.error.HTTPError as error:
            if error.code not in (301,302,303,307,308):raise RuntimeError('Official request failed: HTTP '+str(error.code)) from None
            location=urllib.parse.urljoin(url,error.headers['Location']);parsed=urllib.parse.urlparse(location)
            assert parsed.scheme=='https' and (parsed.hostname=='api.github.com' or parsed.hostname.endswith('.blob.core.windows.net') or parsed.hostname.endswith('.actions.githubusercontent.com'))
            url=location;continue
        with response:
            assert response.status==200;raw=response.read(8*1024*1024+1);assert len(raw)<=8*1024*1024
        raw.decode('utf-8',errors='strict');return raw
    raise RuntimeError('Too many official redirects')
run_endpoint=BASE+'actions/runs/'+str(a.run)+'/attempts/'+str(a.attempt)
run_raw=download(run_endpoint);run=json.loads(run_raw)
assert run['id']==a.run and run['run_attempt']==a.attempt and run['head_sha']==a.expected_head and run['status']=='completed'
jobs_endpoint=run_endpoint+'/jobs?per_page=100';jobs_raw=download(jobs_endpoint);jobs=json.loads(jobs_raw)
assert jobs['total_count']==len(jobs['jobs'])==1
job=jobs['jobs'][0];assert job['run_id']==a.run and job['run_attempt']==a.attempt and job['status']=='completed'
O.mkdir();manifest=[]
def preserve(name,raw,endpoint):
    with (O/name).open('xb') as stream:stream.write(raw)
    manifest.append(dict(path=name,endpoint=endpoint,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
preserve('run.json',run_raw,run_endpoint);preserve('jobs.json',jobs_raw,jobs_endpoint)
log_endpoint=BASE+'actions/jobs/'+str(job['id'])+'/logs';log_raw=download(log_endpoint)
preserve('job-log.official-direct-download.utf8.txt',log_raw,log_endpoint)
lines=[re.sub(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?','',line).rstrip('\r') for line in log_raw.decode().splitlines()]
positions=[index for index,line in enumerate(lines) if re.fullmatch(r'\[command\].*git log -1 --format=%H',line)]
assert len(positions)==1;checkout_sha=lines[positions[0]+1];assert re.fullmatch('[0-9a-f]{40}',checkout_sha)
if run['event']=='push':assert checkout_sha==a.expected_head
else:assert run['event']=='pull_request'
checkout_endpoint=BASE+'git/commits/'+checkout_sha;checkout_raw=download(checkout_endpoint);checkout=json.loads(checkout_raw);assert checkout['sha']==checkout_sha
preserve('checkout.json',checkout_raw,checkout_endpoint)
receipt=dict(endpoint=log_endpoint,job=job['id'],run=a.run,attempt=a.attempt,expectedConnectorSha256=None,
    authentication='Existing Git credential manager; memory only; never printed or persisted',noFragmentReconstructionUsed=True,
    directDownloadAccepted=True,status=200,bytes=len(log_raw),sha256=hashlib.sha256(log_raw).hexdigest(),acquisitionMode='DIRECT_UNMODIFIED_OFFICIAL_HTTP',source=a.expected_head,
    matchesCompleteOfficialConnectorResponse=False,finishedAt=datetime.now(timezone.utc).isoformat(),runConclusion=run['conclusion'],jobConclusion=job['conclusion'],completeCiAcceptanceClaimed=False)
with (O/'official-direct-download-authenticated-result.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(receipt,indent=2)+'\n')
with (O/'official-http-acquisition-manifest.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(dict(kind='derived_acquisition_manifest',records=manifest),indent=2)+'\n')
print(json.dumps(dict(run=a.run,attempt=a.attempt,job=job['id'],conclusion=run['conclusion'],head=a.expected_head,checkout=checkout_sha,logBytes=len(log_raw),logSha256=receipt['sha256'],completeCiAcceptanceClaimed=False,folder=O.name)),flush=True)
