"""Commit one independently reviewed nine-path blocked-state lease candidate."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args();t=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
prep=json.loads((t/'poc003-blocked-lease-v3-precommit.json').read_bytes());rp=t/'poc003-blocked-lease-v3-precommit-independent-review.json'
assert sha(rp.read_bytes())==a.review_sha256
r=json.loads(rp.read_bytes());assert r['candidateCommitAllowed'] and r['fixedSource15ChecksAllowed'] and not r['mustFix'] and r['commitMethodSha256']==sha(Path(__file__).read_bytes())
R=Path(prep['author']);B=prep['base'];branch=prep['branch'];assert r['base']==B and r['branch']==branch and branch=='chore/POC-003-blocked-lease-20261105'
assert datetime.now(timezone.utc)<datetime.fromisoformat(prep['newLease']['expiresAt'].replace('Z','+00:00'))
git=lambda *x:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*x])
dec=lambda *x:git(*x).decode().strip()
assert dec('rev-parse','HEAD')==B and dec('branch','--show-current')==branch 
existing_staged=dec('diff','--cached','--name-only').splitlines()
assert existing_staged==[x for x in prep['changedPaths'] if x!='evidence/POC-003/blocked-lease-v2/attempt-records-v3.json']
paths=sorted(set(dec('diff','--name-only').splitlines())|set(existing_staged)|set(dec('ls-files','--others','--exclude-standard').splitlines()));assert paths==prep['changedPaths'] and len(paths)==10
assert r['fileSnapshot']==prep['fileSnapshot']
for pin in prep['fileSnapshot']:
 raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
git('add','--',*paths);assert dec('diff','--cached','--name-only').splitlines()==paths
for pin in prep['fileSnapshot']:
 raw=git('show',':'+pin['path']);assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
git('diff','--cached','--check')
git('commit','-m','chore(POC-003): record blocked state and renew lease prospectively','-m','Refs #131. Evidence: evidence/POC-003/blocked-lease-v2/')
S=dec('rev-parse','HEAD');assert dec('show','-s','--format=%P',S)==B and not dec('status','--porcelain=v1','--untracked-files=all')
bundle=t/('poc003-blocked-lease-v2-'+S[:7]+'-increment.bundle');assert not bundle.exists();git('bundle','create',str(bundle),branch,'^'+B)
out=dict(prep,source=S,parents=[B],tree=dec('rev-parse',S+'^{tree}'),bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=sha(bundle.read_bytes()),contentReview=rp.name,contentReviewSha256=a.review_sha256,expectedCommands=15,expectedHostedGovernanceTests=867,currentLocal15Accepted=False,hostedCiAccepted=False,actualMigrationAccepted=False,leaseAcceptedOnMain=False,leaseExpiresAt=prep['newLease']['expiresAt'],createdAt=datetime.now(timezone.utc).isoformat())
with (t/'poc003-blocked-lease-v2-current-candidate.json').open('x',encoding='utf-8') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(source=S,base=B,tree=out['tree'],paths=paths,bundle=bundle.name)),flush=True)
