"""Delete one exact ended OPS019 remote only after full actual Completion acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,yaml
p=argparse.ArgumentParser();p.add_argument('--which',choices=['review','completion'],required=True);p.add_argument('--main-review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;R=t.parent/'Guize'
load=lambda n:json.loads((t/n).read_bytes())
rn='ops019-normal-completion-v2-final-actual-main-independent-review.json';assert hashlib.sha256((t/rn).read_bytes()).hexdigest()==a.main_review_sha256
accepted=load(rn);assert accepted['actualCompletionMainAccepted'] and accepted['fullMainCiAccepted'] and accepted['ownMainSevenAccepted'] and not accepted['mustFix']
c=load('ops019-normal-completion-v2-actual-main-candidate.json');source='c58089f4d97546591d98ebc4151cad0502e4ada9';base='daede2ac652f03d05fcdf22c40504edde07067ac';main=c['actualMain']
assert c['source']==accepted['source']==source and c['base']==base and accepted['actualMain']==main and c['parents']==[base,source]
choices={'review':(188,'chore/OPS-019-controlled-lfs-review','efc97542bd476670c302872d12f45eb7a807b3ce',base),'completion':(189,'chore/OPS-019-controlled-lfs-completion',source,main)}
number,branch,tip,merge=choices[a.which];ref='refs/heads/'+branch
prefix='ops019-ended-completion-v2-'+a.which;g=load(prefix+'-fresh-guard.json');at=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'));fresh=lambda:0<=(datetime.now(timezone.utc)-at).total_seconds()<120
assert fresh() and g['main']['object']['sha']==main
pr=g['pr'];assert pr['number']==number and pr['state']=='closed' and pr['merged'] and pr['head']['ref']==branch and pr['head']['sha']==tip and pr['merge_commit_sha']==merge
assert len(g['openPrs'])<100 and not any(x['head']['ref']==branch or x['base']['ref']==branch for x in g['openPrs'])
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
def git(root,*argv):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*argv],env=env).decode().strip()
refs=lambda root:git(root,'for-each-ref','--format=%(refname) %(objectname)')
remotes=lambda:dict(line.split('\t')[::-1] for line in git(R,'ls-remote','--heads','origin').splitlines())
review=Path(load('ops019-normal-review-v3-current-candidate.json')['author']);completion=Path(load('ops019-normal-completion-v2-current-candidate.json')['author'])
roots=[R,review,completion]
assert git(R,'rev-parse','HEAD')==main and git(R,'branch','--show-current')=='main' and git(R,'show','-s','--format=%P',main).split()==[base,source]
assert git(review,'rev-parse','HEAD')==choices['review'][2] and git(completion,'rev-parse','HEAD')==source
for root in roots:assert not git(root,'status','--porcelain=v1','--untracked-files=all')
active=yaml.safe_load((R/'specs/coordination/active-work.yaml').read_bytes());assert len(active['tasks'])==2 and not any(x['taskId']=='OPS-019' or x['riskLevel'] in ('high','critical') or x.get('branch')==branch for x in active['tasks'])
archive=review if a.which=='review' else completion
assert git(archive,'rev-parse',ref)==tip and git(R,'merge-base',tip,main)==tip
bundle=t/c['bundle']
with bundle.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==c['bundleSha256']
assert bundle.stat().st_size==c['bundleBytes'];subprocess.run(['git','-C',str(R),'bundle','verify',str(bundle)],check=True,capture_output=True)
before_remote=remotes();assert before_remote['refs/heads/main']==main and before_remote[ref]==tip
before={str(root):dict(refs=refs(root),worktrees=git(root,'worktree','list','--porcelain')) for root in roots}
out=t/(prefix+'-cleanup');out.mkdir();hooks=out/'hooks';hooks.mkdir()
(hooks/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n  test "$local_ref" = "(delete)"\n  test "$local_sha" = "'+'0'*40+'"\n  test "$remote_ref" = "'+ref+'"\n  test "$remote_sha" = "'+tip+'"\n  count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf-8',newline='\n')
assert fresh();url=git(R,'remote','get-url','origin');assert url=='https://github.com/ElectricDogCN/Guize.git'
argv=['git','-c','core.longpaths=true','-c','credential.interactive=never','-c','core.hooksPath='+hooks.as_posix(),'-C',str(R),'push','--porcelain',url,':'+ref]
result=dict(acceptedMain=main,source=source,removedRemote=ref,expectedOldRemoteSha=tip,mainReviewSha256=a.main_review_sha256,argv=argv,pid=None,actualWaitCompleted=False,exitCode=None,forceUsed=False,beforeRemote=before_remote,beforeLocal=before,postValidationPassed=False,wrapperExitCode=None,startedAt=datetime.now(timezone.utc).isoformat(),sourcePocQualificationGranted=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');save()
try:
 with (out/'stdout.raw').open('xb') as so,(out/'stderr.raw').open('xb') as se:
  child=subprocess.Popen(argv,env=env,stdout=so,stderr=se);result['pid']=child.pid;save();code=child.wait();result.update(actualWaitCompleted=True,exitCode=code,childFinishedAt=datetime.now(timezone.utc).isoformat());save()
 assert code==0
 after=remotes();result['afterRemote']=after;save();expected=dict(before_remote);expected.pop(ref);assert after==expected
 for root in roots:
  assert refs(root)==before[str(root)]['refs'] and git(root,'worktree','list','--porcelain')==before[str(root)]['worktrees'] and not git(root,'status','--porcelain=v1','--untracked-files=all')
 assert git(archive,'rev-parse',ref)==tip
 result.update(postValidationPassed=True,wrapperExitCode=0,allLocalRefsAndWorktreesPreserved=True,archivedLocalBranchRetained=True,completedAt=datetime.now(timezone.utc).isoformat());save()
except BaseException as exc:
 result.update(wrapperExitCode=1,postValidationError=type(exc).__name__+': '+str(exc));save();raise
print(json.dumps(dict(removedRemote=ref,actualExitCode=code,postValidationPassed=True,localRefsPreserved=True)),flush=True)
