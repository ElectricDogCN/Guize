"""Commit reviewed prospective metadata M before any newly claimed H write."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent
receipt=t/'ops020-history-data-performance-v1-scope-precommit-independent-review.json'
assert hashlib.sha256(receipt.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(receipt.read_bytes())
assert v['scopeAmendmentCandidateAccepted'] and v['normalMetadataCommitMAllowed'] and v['hImplementationAfterMAllowed'] and not v['mustFix']
c=json.loads((t/'ops020-history-data-performance-v1-scope-precommit.json').read_bytes());r=Path(c['author'])
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*args])
dec=lambda *args:git(*args).decode().strip()
assert dec('rev-parse','HEAD')==c['base'] and dec('branch','--show-current')==c['branch']
assert not dec('diff','--cached','--name-only')
paths=c['changedPaths'];assert len(paths)==11 and set(paths)==set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines())
assert {pin['path'] for pin in v['fileSnapshot']}==set(paths)
for pin in v['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
for name in c['claims']+['evidence/OPS-020/recovery-intent.json','specs/coordination/program-plan.yaml','specs/coordination/task-completions.yaml','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','.github/workflows/governance-gate.yml']:
 assert (r/name).read_bytes()==git('show',c['base']+':'+name),name
git('add','--',*paths)
assert set(dec('diff','--cached','--name-only').splitlines())==set(paths)
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check')
git('commit','-m','chore(OPS-020): prospectively scope history data performance repair','-m','Refs #191. Metadata-only M reserves one H path before child implementation N. Initial reservation and intent remain immutable; no H code, authority cache, CI exception or POC action.')
source=dec('rev-parse','HEAD')
assert dec('show','-s','--format=%P',source)==c['base'] and not dec('status','--porcelain=v1','--untracked-files=all')
result=dict(source=source,parent=c['base'],branch=c['branch'],tree=dec('rev-parse','HEAD^{tree}'),author=str(r),changedPaths=paths,
 claims=c['claims'],scopeReviewSha256=a.review_sha256,normalMetadataMCommitted=True,hCodeWritten=False,fullCiAccepted=False,
 actualMainAccepted=False,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-history-data-performance-v1-scope-m-commit.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
