"""Fresh ordinary PR188 code-merge preflight. Does not merge or migrate."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
import yaml
t=Path(__file__).resolve().parent
S='a8ae2472033c41c674e9761a79b695540575c189'
M='02997ddaee951e054a5ce106e0566847f546d8cd'
TREE='248a18a07deada8e168082ac91313780a7e5c4fb'
BRANCH='chore/OPS-019-controlled-lfs-review'
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);args=p.parse_args()
read=lambda file:json.loads(Path(file).read_bytes())
sha=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
review_file=t/'ops019-normal-review-pr188-source-final-independent-review.json'
assert sha(review_file)==args.review_sha256
r=read(review_file)
assert (r['source'],r['base'],r['tree'])==(S,M,TREE)
assert r['finalSourceAccepted'] and r['fullCiAccepted'] and r['actualMergeApproved'] and not r['mustFix']
assert not r.get('bootstrapExceptionAccepted',False)
ci=r['ci']
assert ci['run']==41576678591 and ci['job']==125721684809 and ci['uniquePassed']==867
assert ci['original842Plus25Exact'] and ci['failedErroredSkippedXfailXpass']==0
for pin in r['evidencePins']:
    file=t/pin['path']
    assert file.stat().st_size==pin['bytes'] and sha(file)==pin['sha256']
g=read(t/'ops019-normal-review-pr188-fresh-final-merge-guard.json')
captured=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'))
fresh=lambda:0<=(datetime.now(timezone.utc)-captured).total_seconds()<120
assert fresh() and g['main']['object']['sha']==M
pr=g['pr']
assert pr['number']==188 and pr['state']=='open' and not pr['merged'] and not pr['draft']
assert pr['mergeable'] is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==S and pr['head']['ref']==BRANCH
assert pr['base']['sha']==M and pr['base']['ref']=='main' and pr['changed_files']==10
assert g['issue']['number']==185 and g['issue']['state']=='open'
run=g['run']
assert run['id']==41576678591 and run['run_attempt']==1 and run['head_sha']==S
assert run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert g['jobs']['total_count']==len(g['jobs']['jobs'])==1
job=g['jobs']['jobs'][0]
assert job['id']==125721684809 and job['run_id']==run['id'] and job['run_attempt']==1
assert job['status']=='completed' and job['conclusion']=='success' and len(job['steps'])==28
assert all(step['status']=='completed' and step['conclusion']=='success' for step in job['steps'])
latest=g['latest']['workflow_runs']
assert latest and latest[0]['id']==run['id'] and latest[0]['run_attempt']==1 and latest[0]['conclusion']=='success'
assert not any(not thread['is_resolved'] for thread in g['threads'])
reviews={}
for review in g['reviews']:
    reviews[review['user']['login']]=review
assert not any(review['state']=='CHANGES_REQUESTED' for review in reviews.values())
candidate=read(t/'ops019-normal-review-v2-current-candidate.json')
assert candidate['source']==S and candidate['base']==M and candidate['tree']==TREE
author=Path(candidate['author']);canonical=t.parent/'Guize'
def git(root,*argv):
    return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*argv])
def dec(root,*argv):
    return git(root,*argv).decode().strip()
for root,head,branch in [(author,S,BRANCH),(canonical,M,'main')]:
    assert dec(root,'rev-parse','HEAD')==head and dec(root,'branch','--show-current')==branch
    assert not dec(root,'status','--porcelain=v1','--untracked-files=all')
assert dec(author,'merge-base',M,S)==M and dec(author,'rev-parse','HEAD^{tree}')==TREE
assert dec(author,'diff','--name-only',M,S).splitlines()==candidate['changedPaths']
precommit=read(t/'ops019-normal-review-v2-precommit-independent-review.json')
assert sha(t/'ops019-normal-review-v2-precommit-independent-review.json')==candidate['precommitReviewSha256']
for pin in precommit['fileSnapshot']:
    file=author/pin['path']
    assert file.stat().st_size==pin['bytes'] and sha(file)==pin['sha256']
assert dec(author,'ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main']
assert dec(author,'ls-remote','--heads','origin','refs/heads/'+BRANCH).split()==[S,'refs/heads/'+BRANCH]
for path in ['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py',
             'specs/poc/test_program.py','docs/18-testing-and-acceptance.md']:
    assert (author/path).read_bytes()==git(author,'show',M+':'+path)
before=yaml.safe_load(git(author,'show',M+':specs/coordination/active-work.yaml'))
active=yaml.safe_load((author/'specs/coordination/active-work.yaml').read_bytes())
rows=lambda d:{row['taskId']:row for row in d['tasks']}
own,registered=rows(active)['OPS-019'],rows(before)['OPS-019']
assert len(active['tasks'])==3 and sum(row['riskLevel'] in {'high','critical'} for row in active['tasks'])==1
assert own['status']=='review' and own['agentRole']=='reviewer' and own['baseSha']==M and own['branch']==BRANCH
assert own['exclusivePaths']==registered['exclusivePaths'] and own['sharedPaths']==[]
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
assert own['lease']==registered['lease'] and datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
for name in own['exclusivePaths']:
    assert (author/name).read_bytes()==git(author,'show',M+':'+name)
assert not (author/'evidence/OPS-019/implementation-v1/migration-approval.json').exists()
for task in ('POC-003','POC-005'):
    assert rows(active)[task]==rows(before)[task]
checkout=read(t/'ops019-normal-review-pr188-source-ci946-final/checkout.json')
assert [parent['sha'] for parent in checkout['parents']]==[M,S] and checkout['tree']['sha']==TREE
assert fresh()
result=dict(source=S,base=M,tree=TREE,pullRequest=188,expectedHeadSha=S,mergeMethod='merge',
    freshGuardPassed=True,fullCiAccepted=True,bootstrapExceptionAccepted=False,
    sourceReviewSha256=args.review_sha256,capturedAt=g['capturedAt'],
    checkedAt=datetime.now(timezone.utc).isoformat(),actualMergePerformed=False,
    actualPocMigrationApproved=False,authorityNormalCompletionAccepted=False)
with (t/'ops019-normal-review-pr188-final-merge-preflight-result.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
