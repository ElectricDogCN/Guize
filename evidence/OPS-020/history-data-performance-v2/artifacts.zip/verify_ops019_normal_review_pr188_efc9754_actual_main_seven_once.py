"""Separate actual-main no-task gates in an independent Python3.11 clone."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,shlex,subprocess,sys
from live_github_transport import start_bridge

t=Path(__file__).resolve().parent
c=json.loads((t/'ops019-normal-review-pr188-actual-main-candidate.json').read_bytes())
actual,source,base,tree=[c[k] for k in ('actualMain','source','base','tree')]
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
assert source=='efc97542bd476670c302872d12f45eb7a807b3ce' and base=='02997ddaee951e054a5ce106e0566847f546d8cd'
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
repo=Path('/home/sur/.cache/guize-takeover/ops019-normal-review-pr188-main-seven-'+actual[:7]);assert not repo.exists()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],GIT_LFS_SKIP_SMUDGE='1')
subprocess.run(['git','clone','--quiet','--branch','main',str(bundle),str(repo)],check=True)
assert not (repo/'.git/objects/info/alternates').exists()
subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
raw=(t/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
assert len(raw)==4096 and hashlib.sha256(raw).hexdigest()==oid
cache=repo/'.git/lfs/objects'/oid[:2]/oid[2:4]
cache.mkdir(parents=True,exist_ok=True)
object_file=cache/oid
if object_file.exists():
 assert object_file.read_bytes()==raw
else:
 with object_file.open('xb') as f:f.write(raw)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:
 subprocess.run(['git','-C',str(repo),'config','--local',key,value],check=True,capture_output=True)
os.environ.pop('GIT_LFS_SKIP_SMUDGE')
hydration=subprocess.run(['git','-C',str(repo),'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin'],check=True,capture_output=True)
assert (repo/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==raw

state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),parents=git('show','-s','--format=%P','HEAD').split(),branch=git('branch','--show-current'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before['head']==actual and before['tree']==tree and before['parents']==[base,source] and before['branch']=='main' and not before['status']
candidate=json.loads((t/'ops019-normal-review-v3-current-candidate.json').read_bytes())
assert git('diff','--name-only',base,actual).splitlines()==candidate['changedPaths']
out=t/('ops019-normal-review-pr188-'+actual[:7]+'-native-main-seven');out.mkdir()
for key in ('GITHUB_HEAD_REF','GITHUB_BASE_REF','PYTHONHOME','GITHUB_TOKEN'):os.environ.pop(key,None)
os.environ.update(GITHUB_REF_NAME='main',GITHUB_EVENT_NAME='push',EVENT_NAME='push',PUSH_BEFORE=base,PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize')
start_bridge(out)
commands=[('integrity',['scripts/check-program-plan-integrity.py','--base-ref',base])]
for label,name in [('history','check-program-plan-history.py'),('transitions','check-program-plan-transitions.py'),('finalization','check-program-plan-finalization.py'),('raw-lifecycle','check-program-lifecycle-guards.py')]:
    commands.append((label,['scripts/'+name,'--base-ref',base,'--head-ref',actual]))
commands += [('coordination',['scripts/run-agent-coordination-gate.py']),('poc-protocol',['specs/poc/check_program.py','--repo-root',str(repo)])]
result=dict(c,before=before,python=sys.version,commands=[],nativeMainChecksAccepted=False,fullMainCiAccepted=False,bootstrapExceptionAccepted=False,actualReviewMainAccepted=False,taskCompleted=False,newResourcesOrExperimentApproved=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for label,args in commands:
    argv=[sys.executable,'-B',*args];row=dict(label=label,argv=argv,startedAt=datetime.now(timezone.utc).isoformat())
    with (out/(label+'.raw')).open('x',encoding='utf-8',buffering=1) as raw:
        raw.write('Source Commit: '+actual+'\nCommand: '+shlex.join(argv)+'\n')
        p=subprocess.Popen(argv,cwd=repo,stdout=raw,stderr=subprocess.STDOUT);row['pid']=p.pid;result['commands'].append(row);save()
        code=p.wait();raw.write('\nExit Code: '+str(code)+'\n')
    data=(out/(label+'.raw')).read_bytes();row.update(actualWaitCompleted=True,exitCode=code,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());save()
    print(label+': exit '+str(code),flush=True)
    if code:raise SystemExit(code)
assert state()==before
result.update(after=state(),nativeMainChecksAccepted=True,actualMainSevenAllExitZero=True,finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(actualMain=actual,actualMainSevenAllExitZero=True,fullMainCiAccepted=False)),flush=True)
