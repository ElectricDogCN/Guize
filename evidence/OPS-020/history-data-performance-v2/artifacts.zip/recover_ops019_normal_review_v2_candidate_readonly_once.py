"""Read-only recovery of candidate metadata after successful ordinary commit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,re,shlex
T=Path(__file__).resolve().parent;R=T/'ops019-controlled-lfs-review-v2'
c=json.loads((T/'ops019-normal-review-v2-precommit.json').read_bytes())
review=T/'ops019-normal-review-v2-precommit-independent-review.json'
sha=hashlib.sha256(review.read_bytes()).hexdigest();assert sha=='13cd1dbddd45f0d0f7d482b35f1b650ccf7b9a2aa3caed673666c92326817fbc'
v=json.loads(review.read_bytes());assert v['metadataCandidateAccepted'] and v['localMetadataCommitAllowed'] and not v['mustFix']
S='a8ae2472033c41c674e9761a79b695540575c189';base=c['base'];branch=c['branch']
git=lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*a])
assert git('rev-parse','HEAD').decode().strip()==S and git('show','-s','--format=%P',S).decode().strip()==base and git('branch','--show-current').decode().strip()==branch
assert not git('status','--porcelain=v1','--untracked-files=all').strip()
assert set(git('diff','--name-only',base,S).decode().splitlines())==set(c['changedPaths'])
for pin in v['fileSnapshot']:
 raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'] and git('show',S+':'+pin['path'])==raw
bundle=T/'ops019-normal-review-v2-a8ae247-increment.bundle';assert bundle.stat().st_size==5878
fence=chr(96)*3;sections=re.findall(fence+r'bash\n(.*?)\n'+fence,(R/'specs/tasks/OPS-019.md').read_text(encoding='utf-8'),re.S);assert len(sections)==1
commands=[shlex.split(x) for x in sections[0].splitlines() if x.strip()];assert len(commands)==14
result=dict(source=S,base=base,branch=branch,tree=git('rev-parse','HEAD^{tree}').decode().strip(),author=str(R),changedPaths=c['changedPaths'],metadataOnly=True,conditionalApprovalCreated=False,commands=commands,bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),precommitReviewSha256=sha,currentSourceChecksPassed=False,fullCiAccepted=False,expectedFullGovernanceCases=867,postcommitWrapperFailurePreserved=True,createdAt=datetime.now(timezone.utc).isoformat())
with (T/'ops019-normal-review-v2-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=S,tree=result['tree'],bundleBytes=result['bundleBytes'],candidateRecovered=True,gitMutation=False)),flush=True)
