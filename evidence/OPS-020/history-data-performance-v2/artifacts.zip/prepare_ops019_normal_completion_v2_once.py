"""Normal OPS019 Completion preparation, gated on accepted actual Review main.
Creates the independently approved immutable conditional record in a preceding
review-state commit; only then prepares ordinary Completion metadata. No POC
migration, experiment, release on actual main, push or merge is performed.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,json,os,re,shlex,subprocess,zipfile
import yaml
p=argparse.ArgumentParser()
for arg in ['review-main-receipt-sha256','issue-closure-sha256','approval-review-sha256']:p.add_argument('--'+arg,required=True)
a=p.parse_args();t=Path(__file__).resolve().parent
R=t/'ops019-normal-completion-v1';canonical=t.parent/'Guize'
B='chore/OPS-019-controlled-lfs-completion';Code='02997ddaee951e054a5ce106e0566847f546d8cd'
ReviewSource='efc97542bd476670c302872d12f45eb7a807b3ce'
APP='evidence/OPS-019/implementation-v1/migration-approval.json'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
read=lambda f:json.loads(Path(f).read_bytes())
receipt=t/'ops019-normal-review-pr188-final-actual-main-independent-review.json'
assert sha(receipt)==a.review_main_receipt_sha256
accepted=read(receipt)
assert accepted['source']==ReviewSource and accepted['base']==Code and accepted['actualReviewMainAccepted'] and accepted['fullMainCiAccepted'] and accepted['ownMainSevenAccepted'] and accepted['normalCompletionMayStart'] and not accepted['mustFix']
base=accepted['actualMain'];assert re.fullmatch('[0-9a-f]{40}',base) and base!=Code
code_receipt=t/'ops019-implementation-pr187-final-actual-main-independent-review.json'
assert sha(code_receipt)=='470399eb24c80ad7b2de24736799b86c00a38a3ca6c9241a8cc569cf9169908a'
code_accepted=read(code_receipt);assert code_accepted['actualMain']==Code and code_accepted['actualImplementationMainAccepted'] and code_accepted['fullMainCiAccepted'] and not code_accepted['mustFix']
closure=t/'ops019-normal-completion-v1-issue185-closed-completed-official.json'
assert sha(closure)==a.issue_closure_sha256
issue=read(closure);assert issue['number']==185 and issue['state']=='closed' and issue['state_reason']=='completed'
apreviewfile=t/'ops019-normal-completion-v1-prospective-approval-independent-review.json'
assert sha(apreviewfile)==a.approval_review_sha256
apreview=read(apreviewfile)
assert apreview['conditionalApprovalAccepted'] and apreview['normalCompletionPreparationAllowed'] and not apreview['mustFix']
assert apreview['reviewMain']==base and apreview['codeMain']==Code and apreview['preparationMethodSha256']==sha(__file__)
apfile=t/'ops019-normal-completion-v1-migration-approval.json';assert sha(apfile)==apreview['approvalRecordSha256']
record=read(apfile)
c=read(t/'ops019-normal-review-pr188-actual-main-candidate.json')
assert c['actualMain']==base and c['source']==ReviewSource and c['base']==Code
bundle=t/c['bundle'];assert bundle.stat().st_size==c['bundleBytes'] and sha(bundle)==c['bundleSha256']
def git(root,*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*args])
def dec(root,*args):return git(root,*args).decode().strip()
assert dec(canonical,'rev-parse','HEAD')==base and dec(canonical,'branch','--show-current')=='main' and not dec(canonical,'status','--porcelain=v1','--untracked-files=all')
assert dec(canonical,'ls-remote','--heads','origin','refs/heads/main').split()==[base,'refs/heads/main']
assert not dec(canonical,'ls-remote','--heads','origin','refs/heads/'+B) and not R.exists()
subprocess.run(['git','-c','core.longpaths=true','-c','core.autocrlf=false','clone','--quiet','--branch','main','--config','core.longpaths=true','--config','core.autocrlf=false',str(bundle),str(R)],check=True,timeout=300,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'))
assert dec(R,'rev-parse','HEAD')==base and dec(R,'rev-parse','HEAD^{tree}')==c['tree'] and not (R/'.git/objects/info/alternates').exists()
git(R,'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git');git(R,'switch','--no-track','-c',B,base)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b';data=(t/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
cache=R/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True)
if (cache/oid).exists():assert (cache/oid).read_bytes()==data
else:
 with (cache/oid).open('xb') as f:f.write(data)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:git(R,'config','--local',key,value)
git(R,'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin')
assert (R/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data and not dec(R,'status','--porcelain=v1','--untracked-files=all')
paths=dict(plan='specs/coordination/program-plan.yaml',active='specs/coordination/active-work.yaml',task='specs/tasks/OPS-019.md')
before={k:(R/name).read_bytes() for k,name in paths.items()};plan=yaml.safe_load(before['plan']);active=yaml.safe_load(before['active'])
rows=lambda d:{x['taskId']:x for x in d['tasks']}
own=rows(active)['OPS-019'];target=rows(active)['POC-003']
assert own['status']=='review' and own['agentRole']=='reviewer' and own['baseSha']==Code and own['branch']=='chore/OPS-019-controlled-lfs-review'
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review' and len(active['tasks'])==3
assert set(own['exclusivePaths'])=={'.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py'} and own['sharedPaths']==[]
assert own['lease']=={'acquiredAt':'2026-11-02T23:44:30Z','expiresAt':'2026-11-09T23:44:30Z'}
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
expected_record=dict(schemaVersion=1,kind='conditional_prospective_work_branch_migration',authorityTaskId='OPS-019',taskId='POC-003',reservation='7d82fb61f434f57bb97cb9d80f4613cee3be2721',implementationCommit=Code,intentSha256='6a563cd81331c9ebc6141e12f1b678b9e97a808daeb816d5b2c4794abbc9cec4',oldBranch='chore/POC-003-ats-range',newBranch='chore/POC-003-qualified-lfs-evidence-v1',originalCreationBase='760f6c5838597d1d66c0a536ecbf440ef5a7dfec',oldUnmergedCandidate='3564346d2bdfbd80f2f705ae3dd4f7ba79103cb6',beforeRegistrySha256=hashlib.sha256(json.dumps(target,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),beforeTaskSha256=sha(R/'specs/tasks/POC-003.md'),reviewer='/root/independent_review',approvedAt=record['approvedAt'],decision='approved',condition='normal_authority_completion_full_ci_capacity_release_and_fresh_main')
assert record==expected_record and len(record)==17 and not (R/APP).exists()
when=datetime.fromisoformat(record['approvedAt'].replace('Z','+00:00'))
assert datetime.fromisoformat(target['lease']['acquiredAt'].replace('Z','+00:00'))<=when<datetime.now(timezone.utc)<datetime.fromisoformat(target['lease']['expiresAt'].replace('Z','+00:00'))
(R/APP).write_bytes(apfile.read_bytes());git(R,'add','--',APP)
assert dec(R,'diff','--cached','--name-only')==APP
git(R,'diff','--cached','--check');git(R,'commit','-m','review(OPS-019): bind conditional prospective migration approval','-m','Refs #185. This immutable condition requires actual normal Completion, full official CI, released capacity and fresh main; it does not perform migration.')
creator=dec(R,'rev-parse','HEAD');assert dec(R,'show','-s','--format=%P',creator)==base
assert all((R/name).read_bytes()==before[key] for key,name in paths.items())
creator_receipt=dict(source=creator,parent=base,approvalRecordSha256=sha(apfile),approvalReviewSha256=a.approval_review_sha256,actualGitCommitCompleted=True,taskRemainsReview=True,actualCapacityReleased=False,actualMigrationApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops019-normal-completion-v1-approval-creator-commit.json').open('x',encoding='utf-8') as f:f.write(json.dumps(creator_receipt,indent=2)+'\n')
expected=copy.deepcopy(plan);foundation=next(x for x in expected['foundationTasks'] if x['taskId']=='OPS-019')
assert foundation['status']=='review' and foundation['completionRef']=='ISSUE-185' and foundation['mergeCommit'] is None
foundation.update(status='completed',completionRef='PR-187',mergeCommit=Code)
raw=before['plan'].decode('utf-8');m=re.search(r'(?ms)^  - taskId: OPS-019\n.*?(?=^  - taskId:|^[A-Za-z$]|\Z)',raw);assert m
block=m[0]
for key,value in [('status','completed'),('completionRef','PR-187'),('mergeCommit',Code)]:
 block,count=re.subn(r'(?m)^    '+key+r':[^\n]*$','    '+key+': '+value,block);assert count==1
updated=raw[:m.start()]+block+raw[m.end():];assert yaml.safe_load(updated)==expected
(R/paths['plan']).write_text(updated,encoding='utf-8',newline='\n')
raw=before['active'].decode('utf-8');m=re.search(r'(?ms)^- taskId: OPS-019\n.*?(?=^- taskId:|\Z)',raw);assert m
updated=raw[:m.start()]+raw[m.end():];expected=copy.deepcopy(active);expected['tasks']=[x for x in expected['tasks'] if x['taskId']!='OPS-019']
assert yaml.safe_load(updated)==expected and len(expected['tasks'])==2 and not any(x['riskLevel'] in ('high','critical') for x in expected['tasks'])
(R/paths['active']).write_text(updated,encoding='utf-8',newline='\n')
parts=before['task'].decode('utf-8').split('---',2);front,body=parts[1:]
for key,old,new in [('status','review','completed'),('agentRole','reviewer','integrator'),('workBranch','chore/OPS-019-controlled-lfs-review',B),('baseSha',Code,base)]:
 front,count=re.subn(r'(?m)^'+key+': '+re.escape(old)+'$',key+': '+new,front);assert count==1
(R/paths['task']).write_text('---'+front+'---'+body,encoding='utf-8',newline='\n')
assert (R/paths['task']).read_bytes().split(b'---',2)[2]==before['task'].split(b'---',2)[2]
fence=chr(96)*3;sections=re.findall(fence+r'bash\n(.*?)\n'+fence,body,re.S);assert len(sections)==1
historical=[shlex.split(x) for x in sections[0].splitlines() if x.strip()];assert len(historical)==14
commands=[[v.replace(Code,base).replace('chore/OPS-019-controlled-lfs-review',B) for v in argv] for argv in historical]
files=[receipt,closure,apreviewfile,apfile,t/'ops019-normal-completion-v1-approval-creator-commit.json',t/'ops019-implementation-pr187-final-actual-main-independent-review.json',t/'ops019-normal-review-v3-current-candidate.json',t/'ops019-normal-review-v3-publication-independent-review.json',t/'ops019-normal-review-pr188-efc9754-source-final-independent-review.json',t/'ops019-normal-review-pr188-merge-api-result-v1.json',t/'ops019-normal-review-pr188-actual-main-candidate.json']
folders=['ops019-implementation-pr187-source-ci944-final','ops019-implementation-pr187-main-ci945-final','ops019-normal-review-pr188-source-ci947-final','ops019-normal-review-pr188-main-ci-final','ops019-implementation-v1-native-specialized-v9','ops019-implementation-v1-native-source14-v4','ops019-implementation-pr187-02997dd-native-main-seven','ops019-normal-review-v3-native-source14','ops019-normal-review-pr188-'+base[:7]+'-native-main-seven']
for folder in folders:
 d=t/folder;assert d.is_dir();files.extend(sorted(x for x in d.iterdir() if x.is_file() and (x.name.endswith('.json') or x.name.endswith('.raw') or x.name.endswith('.txt') or x.name.endswith('.xml'))))
assert len(files)==len(set(files))
# Preserve small pinned provenance transitively; large recovery bundles remain
# local backups, not archive members. No arbitrary workspace enumeration.
files.extend(sorted(x for x in (t/'ops019-implementation-pr187-02997dd-canonical-main').iterdir() if x.is_file() and x.suffix in {'.json','.raw','.txt','.xml'}))
files.extend(sorted(x for x in (t/('ops019-normal-review-pr188-'+base[:7]+'-canonical-main')).iterdir() if x.is_file() and x.suffix in {'.json','.raw','.txt','.xml'}))
closure={};queue=list(files)
def add_pin_records(doc):
 if isinstance(doc,dict):
  for key,value in doc.items():
   if key=='evidencePins':
    assert isinstance(value,list)
    for pin in value:
     name=pin.get('path',pin.get('ref')).removeprefix('.takeover-tools/')
     file=t/name;assert not Path(name).is_absolute() and '..' not in Path(name).parts
     assert file.resolve().is_relative_to(t.resolve()) and file.is_file() and not file.is_symlink()
     raw=file.read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
     queue.append(file)
   else:add_pin_records(value)
 elif isinstance(doc,list):
  for value in doc:add_pin_records(value)
while queue:
 file=queue.pop();assert file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(t.resolve())
 raw=file.read_bytes();assert len(raw)<8*1024*1024
 name=file.relative_to(t).as_posix()
 if name in closure:assert closure[name]==raw;continue
 closure[name]=raw
 if file.suffix=='.json':add_pin_records(json.loads(raw))
assert len(closure)<400 and sum(map(len,closure.values()))<24*1024*1024
files=[t/name for name in sorted(closure)]
phase=R/'evidence/OPS-019/completion-v1';phase.mkdir();records=[]
with zipfile.ZipFile(phase/'prerequisites.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in files:
  raw=file.read_bytes();name=file.relative_to(t).as_posix();assert len(raw)<64*1024*1024;z.writestr(name,raw);records.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
assert (phase/'prerequisites.zip').stat().st_size<20*1024*1024
(phase/'index.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
(phase/'commands.txt').write_text('\n'.join(shlex.join(x) for x in commands)+'\n',encoding='utf-8',newline='\n')
context=dict(taskId='OPS-019',phase='normalCompletion',base=base,branch=B,codeMain=Code,codePr=187,reviewSource=ReviewSource,reviewPr=188,approvalCreator=creator,reviewMainReceiptSha256=a.review_main_receipt_sha256,issueClosureSha256=a.issue_closure_sha256,approvalReviewSha256=a.approval_review_sha256,approvalRecordSha256=sha(apfile),originalTaskBodyPreserved=True,historicalTaskCommands=historical,actualCompletionCommands=commands,currentCompletionChecksExecuted=False,currentCompletionFullCiAccepted=False,actualCapacityReleased=False,actualMigrationApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
(phase/'context.json').write_text(json.dumps(context,indent=2)+'\n',encoding='utf-8',newline='\n')
(phase/'README.md').write_text('# OPS-019 normal Completion proposal\n\nAccepted Code PR187/main '+Code+' and normal Review PR188/main '+base+'; Issue185 closed/completed. Conditional prospective migration approval was introduced in preceding review-state commit '+creator+'. This proposal completes only Own metadata and releases only Own registry entry on later accepted actual main. New source14/867 official CI and actual Completion main7/fullCI/independent acceptance remain pending. No POC migration, new execution or transfer of old results occurs.\n',encoding='utf-8',newline='\n')
current_paths=list(paths.values())+[APP]+['evidence/OPS-019/'+name for name in ['summary.md','handoff.md','commands.txt','changed-files.md','test-results/README.md']]+[x.relative_to(R).as_posix() for x in phase.iterdir()]
assert len(current_paths)==len(set(current_paths))==14
note='\n\n## Normal Completion proposal\nBase '+base+' / branch '+B+' / Issue185 closed-completed. Code identity remains PR187 / '+Code+'; Review PR188 / '+ReviewSource+' has accepted actual main '+base+'. Specific conditional record precedes this metadata in review-state commit '+creator+'. Actual source14/full867CI and actual Completion main7/fullCI/independent acceptance still pending. No migration or new experiment.\nNext: independent exact precommit review, ordinary second commit, actual source14, complete official CI, final source review, fresh expected-head ordinary merge, actual main7/fullCI/final independent review; only then fresh migration may be independently accepted. Original lease/actors/claims, code, frozen5, both POC Tasks and ordinary ledger remain unchanged. Withdrawal or reviewed forward correction only; no history rewrite or local deletion.\n'
for name in ['summary.md','handoff.md','test-results/README.md']:
 with (R/'evidence/OPS-019'/name).open('a',encoding='utf-8',newline='\n') as f:f.write(note)
with (R/'evidence/OPS-019/commands.txt').open('a',encoding='utf-8',newline='\n') as f:f.write(note+'\n'+ '\n'.join(shlex.join(x) for x in commands)+'\n')
with (R/'evidence/OPS-019/changed-files.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## Prospective normal Completion inventory\n'+''.join('- '+x+'\n' for x in sorted(current_paths)))
for name in own['exclusivePaths']+['evidence/OPS-019/delivery-migration-intent.json','specs/coordination/task-completions.yaml','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md']:
 assert (R/name).read_bytes()==git(R,'show',base+':'+name),name
actual=set(dec(R,'diff','--name-only',base).splitlines())|set(dec(R,'ls-files','--others','--exclude-standard').splitlines())
assert actual==set(current_paths) and sha(R/APP)==apreview['approvalRecordSha256']
with (t/'ops019-normal-completion-v1-precommit-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(dict(context,author=str(R),changedPaths=sorted(actual),approvalAlreadyCommitted=True,metadataCommitted=False),indent=2)+'\n')
print(json.dumps(dict(base=base,approvalCreator=creator,changedPaths=len(actual),commands=14,metadataCommitted=False,actualMigrationApproved=False)),flush=True)
