"""Append truthful accepted-prerequisite markers and retain failed C source raw."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shlex,subprocess,zipfile
T=Path(__file__).resolve().parent;R=T/'ops019-normal-completion-v1'
S='a67129c9e591657f921c23613706ca96e2e7ed1d';base='daede2ac652f03d05fcdf22c40504edde07067ac'
git=lambda *args:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*args])
assert git('rev-parse','HEAD').decode().strip()==S and not git('status','--porcelain=v1','--untracked-files=all').strip()
failed=T/'ops019-normal-completion-v1-native-source14';result=json.loads((failed/'results.json').read_bytes())
assert result['source']==S and result['base']==base and result['failedCommandIndex']==6 and len(result['commands'])==7
assert all(row['exitCode']==0 for row in result['commands'][:6]) and result['commands'][6]['exitCode']==1
assert all(row['actualWaitCompleted'] for row in result['commands'])
for row in result['commands']:
 data=(failed/row['raw']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
seven=T/'ops019-normal-review-pr188-daede2a-native-main-seven';m=json.loads((seven/'results.json').read_bytes())
row=next(x for x in m['commands'] if x['label']=='integrity');assert row['exitCode']==0 and row['actualWaitCompleted']
raw=(seven/'integrity.raw').read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
member='ops019-normal-review-pr188-daede2a-native-main-seven/integrity.raw'
with zipfile.ZipFile(R/'evidence/OPS-019/completion-v1/prerequisites.zip') as z:assert z.read(member)==raw
folder=R/'evidence/OPS-019/completion-v1/failed-first-source';folder.mkdir()
for file in [failed/'results.json']+[failed/x['raw'] for x in result['commands']]:
 with (folder/file.name).open('xb') as f:f.write(file.read_bytes())
(folder/'README.md').write_text('# First Completion source check failure\n\nExact source '+S+'; integration base '+base+'. Native source14 executed indices00–06: six exit0, index06 lifecycle guard exit1 for missing structured Evidence markers. Indices07–13 were not executed. These originals remain unchanged, including source binding, actual wait, size and SHA-256. No publication or official CI occurred for that source. The corrective append refers only to already accepted Review main results; new Completion source14/fullCI/actual-main acceptance remain pending.\n',encoding='utf-8',newline='\n')
note='\n\n## Accepted prerequisite Review main execution (scope: prerequisite only)\nTask: OPS-019\nImplementation merge: 02997ddaee951e054a5ce106e0566847f546d8cd (PR187)\nStatus: PASS (accepted prerequisite Review main only)\nResult: PASS (accepted prerequisite Review main only)\nSource Commit: '+base+'\nCommand: '+shlex.join(row['argv'])+'\nExit Code: 0\nRaw artifact: completion-v1/prerequisites.zip :: '+member+'\nRaw SHA-256: '+row['sha256']+'\nThis executed command and PASS concern only the independently accepted Review main, confirmed by its complete CI948 and main7. They do not claim success for Completion source '+S+' or a new repair candidate.\n\nFirst Completion source '+S+' failed source14 index06 with exit1; indices00–05 exited0 and07–13 remain unexecuted. Its eight original result/raw files and scope explanation are retrievable at completion-v1/failed-first-source/. The current repair candidate still requires fresh source14, full official867 CI, final source review, ordinary actual Completion main, its own7/fullCI and independent acceptance before actual capacity release or any migration.\n'
for name in ['summary.md','handoff.md','commands.txt','test-results/README.md']:
 with (R/'evidence/OPS-019'/name).open('a',encoding='utf-8',newline='\n') as f:f.write(note)
paths=sorted(set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
with (R/'evidence/OPS-019/changed-files.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## Structured prerequisite markers forward repair\n'+''.join('- '+x+'\n' for x in sorted(set(paths)|{'evidence/OPS-019/changed-files.md'})))
paths=sorted(set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
assert len(paths)==14 and all(x.startswith('evidence/OPS-019/') for x in paths)
for name in ['specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml','specs/tasks/OPS-019.md','specs/coordination/task-completions.yaml','evidence/OPS-019/implementation-v1/migration-approval.json','.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md']:
 assert (R/name).read_bytes()==git('show',S+':'+name),name
out=dict(kind='OWN_EVIDENCE_STRUCTURED_PREREQUISITE_MARKER_FORWARD_REPAIR',sourceBefore=S,integrationBase=base,author=str(R),changedPaths=paths,failedSourceChecksExecuted=7,failedSourcePassed=6,failedSourceFailed=1,failedSourceRemainingUnexecuted=7,prerequisitePassBoundOnlyTo=base,currentRepairChecksPassed=False,currentRepairCiAccepted=False,actualCapacityReleased=False,actualMigrationApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
with (T/'ops019-normal-completion-v2-structured-evidence-precommit.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(sourceBefore=S,changedOwnPaths=len(paths),originalFailureRetained=True,currentRepairChecksPassed=False)),flush=True)
