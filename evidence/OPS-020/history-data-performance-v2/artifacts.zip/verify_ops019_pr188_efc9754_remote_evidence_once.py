"""Read back the published immutable evidence archive from GitHub's official raw URL."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,zipfile,io
T=Path(__file__).resolve().parent;out=T/'ops019-normal-review-pr188-efc9754-remote-retrieval';out.mkdir()
source='efc97542bd476670c302872d12f45eb7a807b3ce';base='https://raw.githubusercontent.com/ElectricDogCN/Guize/'+source+'/evidence/OPS-019/review-v1/'
expected='570409c5fd6a49678921188cdd1faacc07d514696d8da8ff09259edde2cd9601'
result=dict(source=source,startedAt=datetime.now(timezone.utc).isoformat(),remoteRetrievalAccepted=False,requests=[])
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save()
for name in ['accepted-code-main-evidence.zip','accepted-code-main-evidence-index.json','accepted-code-main-independent-review.json']:
 url=base+name;req=urllib.request.Request(url,headers={'User-Agent':'guize-evidence-retrieval-check'})
 with urllib.request.urlopen(req,timeout=30) as response:
  data=response.read(8*1024*1024+1);assert response.status==200 and len(data)<=8*1024*1024
 with (out/name).open('xb') as f:f.write(data)
 result['requests'].append(dict(url=url,status=200,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()));save()
raw=(out/'accepted-code-main-evidence.zip').read_bytes();index=json.loads((out/'accepted-code-main-evidence-index.json').read_bytes());receipt=json.loads((out/'accepted-code-main-independent-review.json').read_bytes())
assert len(raw)==index['archiveBytes']==336372 and hashlib.sha256(raw).hexdigest()==index['archiveSha256']==expected
assert hashlib.sha256((out/'accepted-code-main-independent-review.json').read_bytes()).hexdigest()=='470399eb24c80ad7b2de24736799b86c00a38a3ca6c9241a8cc569cf9169908a'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(index['entries'])==96
 for row in index['entries']:
  payload=z.read(row['path']);assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
 for pin in receipt['evidencePins']:
  payload=z.read(pin['path']);assert len(payload)==pin['bytes'] and hashlib.sha256(payload).hexdigest()==pin['sha256']
result.update(remoteRetrievalAccepted=True,all96Exact=True,all12DirectPinsExact=True,finishedAt=datetime.now(timezone.utc).isoformat(),currentSourceCiAccepted=False,actualMergeApproved=False)
save();print(json.dumps(result),flush=True)
