"""Exact ordinary blocked-state lease preflight; never merges or changes timestamps."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,importlib.util,json,re,subprocess,yaml

p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True)
p.add_argument('--pr',type=int,required=True);p.add_argument('--run',type=int,required=True);p.add_argument('--job',type=int,required=True)
a=p.parse_args();t=Path(__file__).resolve().parent
read=lambda n:json.loads((t/n).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
c=read('poc003-blocked-lease-v2-current-candidate.json');S,B,TREE=c['source'],c['base'],c['tree']
rp=t/'poc003-blocked-lease-v2-source-final-independent-review.json'
assert sha(rp.read_bytes())==a.review_sha256
r=json.loads(rp.read_bytes());assert (r['source'],r['base'],r['tree'])==(S,B,TREE)
assert r['finalSourceAccepted'] and r['fullCiAccepted'] and r['actualMergeApproved'] and not r['mustFix']
assert r['preflightMethodSha256']==sha(Path(__file__).read_bytes())
assert r['collectorMethodSha256']==sha((t/'capture_poc003_blocked_lease_v2_fresh_guard_direct_once.py').read_bytes())
for pin in r['evidencePins']:
    raw=(t/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
cr=read('ops019-normal-completion-v2-final-actual-main-independent-review.json')
assert cr['actualMain']==B and cr['actualCompletionMainAccepted'] and cr['fullMainCiAccepted'] and cr['ownMainSevenAccepted'] and not cr['mustFix']
ci=read('poc003-blocked-lease-v2-source-ci-final/capture.json')
assert ci['source']==S and ci['base']==B and ci['tree']==TREE and ci['phase']=='source' and ci['pullRequest']==a.pr
assert ci['run']==a.run and ci['job']==a.job and ci['attempt']==1 and ci['conclusion']=='success'
assert ci['uniquePassed']==867 and ci['original842Plus25Exact'] and ci['failedErroredSkippedXfailXpass']==0
assert ci['orderedParents']==[B,S] and ci['totalSteps']==ci['successSteps']==28 and ci['conditionalSkippedSteps']==[] and ci['jobSeconds']<1800 and ci['realLfsFetchAndHydratedProbePassed']
g=read('poc003-blocked-lease-v2-fresh-final-merge-guard-direct.json')
at=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'));fresh=lambda:0<=(datetime.now(timezone.utc)-at).total_seconds()<120
expires=datetime.fromisoformat(c['leaseExpiresAt'].replace('Z','+00:00'))
assert fresh() and datetime.now(timezone.utc)<expires and g['main']['object']['sha']==B
pr=g['pr'];assert pr['number']==a.pr and pr['state']=='open' and not pr['merged'] and not pr['draft'] and pr['mergeable'] is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==S and pr['head']['ref']==c['branch'] and pr['base']['sha']==B and pr['base']['ref']=='main' and pr['changed_files']==10
assert g['issue']['number']==131 and g['issue']['state']=='open'
run=g['run'];assert run['id']==a.run and run['run_attempt']==1 and run['head_sha']==S and run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert g['jobs']['total_count']==len(g['jobs']['jobs'])==1
job=g['jobs']['jobs'][0];assert job['id']==a.job and job['run_id']==a.run and job['run_attempt']==1 and job['status']=='completed' and job['conclusion']=='success'
assert len(job['steps'])==28 and all(x['status']=='completed' and x['conclusion']=='success' for x in job['steps'])
latest=g['latest']['workflow_runs'];assert latest and latest[0]['id']==a.run and latest[0]['run_attempt']==1 and latest[0]['conclusion']=='success'
assert not any(not x['is_resolved'] for x in g['threads'])
reviews={}
for x in g['reviews']:reviews[x['user']['login']]=x
assert not any(x['state']=='CHANGES_REQUESTED' for x in reviews.values())
R=Path(c['author']);git=lambda root,*x:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*x]);dec=lambda root,*x:git(root,*x).decode().strip()
assert c['branch']=='chore/POC-003-blocked-lease-20261105'
for root,head,branch in [(R,S,c['branch']),(t.parent/'Guize',B,'main')]:
    assert dec(root,'rev-parse','HEAD')==head and dec(root,'branch','--show-current')==branch and not dec(root,'status','--porcelain=v1','--untracked-files=all')
assert dec(R,'ls-remote','--heads','origin','refs/heads/main').split()==[B,'refs/heads/main']
assert dec(R,'ls-remote','--heads','origin','refs/heads/'+c['branch']).split()==[S,'refs/heads/'+c['branch']]
assert dec(R,'show','-s','--format=%P',S)==B and dec(R,'rev-parse',S+'^{tree}')==TREE
assert len(c['changedPaths'])==10 and all(n in ('specs/coordination/active-work.yaml','specs/coordination/program-plan.yaml','specs/tasks/POC-003.md','evidence/POC-003/handoff.md') or n.startswith('evidence/POC-003/blocked-lease-v2/') for n in c['changedPaths'])
assert dec(R,'diff','--name-only',B,S).splitlines()==c['changedPaths']
for pin in c['fileSnapshot']:
    raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
assert sha((t/c['bundle']).read_bytes())==c['bundleSha256']
APP='evidence/OPS-019/implementation-v1/migration-approval.json'
assert git(R,'show',B+':'+APP)==git(R,'show',S+':'+APP) and sha(git(R,'show',S+':'+APP))=='758bb3faea013495648de11bbb450642dd327c4b224ebe037557d25904c6d185'
spec=importlib.util.spec_from_file_location('actual_migration_proof',R/'scripts/work-branch-migration.py')
proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
assert proof.validate_range(R,B,S,admitted=B)=={}
AP='specs/coordination/active-work.yaml';PP='specs/coordination/program-plan.yaml';TP='specs/tasks/POC-003.md'
left=yaml.safe_load(git(R,'show',B+':'+AP));right=yaml.safe_load(git(R,'show',S+':'+AP));own=next(x for x in left['tasks'] if x['taskId']=='POC-003')
assert own['status']=='in_progress' and own['agentRole']=='implementer' and own['branch']=='chore/POC-003-ats-range' and own['baseSha']=='760f6c5838597d1d66c0a536ecbf440ef5a7dfec'
old_expiry=own['lease']['expiresAt'];own.update(status='blocked',agentRole='coordinator',lease=c['newLease']);assert left==right
assert datetime.fromisoformat(c['newLease']['acquiredAt'].replace('Z','+00:00'))<expires and (expires-datetime.fromisoformat(c['newLease']['acquiredAt'].replace('Z','+00:00'))).total_seconds()==168*3600
left=yaml.safe_load(git(R,'show',B+':'+PP));right=yaml.safe_load(git(R,'show',S+':'+PP))
next(x for x in left['tasks'] if x['taskId']=='POC-003')['status']='blocked';next(x for x in left['pocs'] if x['pocId']=='POC-03')['status']='blocked';assert left==right
oldtask=git(R,'show',B+':'+TP);newtask=git(R,'show',S+':'+TP);parts=oldtask.split(b'---',2);front=parts[1]
for key,old,new in [('status','in_progress','blocked'),('agentRole','implementer','coordinator'),('leaseExpiresAt',old_expiry,c['newLease']['expiresAt'])]:
 front,count=re.subn(rb'(?m)^'+key.encode()+rb': '+re.escape(old.encode())+rb'(?=\r?$)',lambda _:key.encode()+b': '+new.encode(),front);assert count==1
assert newtask==b'---'+front+b'---'+parts[2] and git(R,'show',B+':specs/coordination/task-completions.yaml')==git(R,'show',S+':specs/coordination/task-completions.yaml')
assert fresh() and datetime.now(timezone.utc)<expires
result=dict(source=S,base=B,tree=TREE,pullRequest=a.pr,expectedHeadSha=S,mergeMethod='merge',freshGuardPassed=True,fullCiAccepted=True,originalLeaseExpiresAt=c['oldLease']['expiresAt'],proposedLeaseExpiresAt=c['leaseExpiresAt'],remainingLeaseSeconds=(expires-datetime.now(timezone.utc)).total_seconds(),exactOrdinaryBlockedLeaseMetadataProofPassed=True,sourceReviewSha256=a.review_sha256,capturedAt=g['capturedAt'],checkedAt=datetime.now(timezone.utc).isoformat(),actualMergePerformed=False,leaseAcceptedOnMain=False,continuityClaimed=False,actualMigrationMainAccepted=False,newExperimentApproved=False)
with (t/'poc003-blocked-lease-v2-final-merge-preflight-result.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
