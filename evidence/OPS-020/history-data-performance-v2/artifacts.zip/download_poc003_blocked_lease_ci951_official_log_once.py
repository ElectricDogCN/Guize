"""Download official job bytes directly; never append to the preserved partial file."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,subprocess,urllib.request,urllib.error,urllib.parse

T=Path(__file__).resolve().parent
O=T/'poc003-blocked-lease-v2-source-ci-final'
endpoint='https://api.github.com/repos/ElectricDogCN/Guize/actions/jobs/127212818466/logs'
expected=None  # No model-pasted fragment or connector-digest claim is used.
run=json.loads((O/'run.json').read_bytes());jobs=json.loads((O/'jobs.json').read_bytes())
assert run['id']==42017864314 and run['head_sha']=='8235eb6d31a1ba002bf9538b20a4f9aff71e3c97' and run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert jobs['total_count']==len(jobs['jobs'])==1 and jobs['jobs'][0]['id']==127212818466 and jobs['jobs'][0]['status']=='completed' and jobs['jobs'][0]['conclusion']=='success'
target=O/'job-log.official-direct-download.utf8.txt'
assert not target.exists()
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
result=dict(endpoint=endpoint,job=127212818466,run=42017864314,
    expectedConnectorSha256=expected,startedAt=datetime.now(timezone.utc).isoformat(),
    noFragmentReconstructionUsed=True,directDownloadAccepted=False)
credential=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never'))
assert credential.returncode==0, 'Existing GitHub Git login unavailable'
fields=dict(line.split(b'=',1) for line in credential.stdout.splitlines() if b'=' in line)
assert fields.get(b'password'), 'Existing GitHub Git login has no credential'
token=fields[b'password'].decode('utf-8')
result['authentication']='Existing Git credential manager; memory only; never printed or persisted'
url=endpoint
for attempt in range(5):
    try:
        headers={'User-Agent':'guize-official-ci-preservation','Accept':'application/vnd.github+json'}
        if url==endpoint:headers['Authorization']='Bearer '+token
        response=opener.open(urllib.request.Request(url,headers=headers),timeout=30)
    except urllib.error.HTTPError as e:
        if e.code not in (301,302,303,307,308):
            result['httpFailure']=e.code
            (O/'official-direct-download-authenticated-result.json').write_text(json.dumps(result,indent=2)+'\n')
            raise RuntimeError('Official log request failed: HTTP '+str(e.code)) from None
        location=urllib.parse.urljoin(url,e.headers['Location'])
        parsed=urllib.parse.urlparse(location)
        assert parsed.scheme=='https' and (parsed.hostname=='api.github.com' or parsed.hostname.endswith('.blob.core.windows.net') or parsed.hostname.endswith('.actions.githubusercontent.com'))
        url=location
        continue
    with response:
        assert response.status==200
        raw=response.read(8*1024*1024+1);assert len(raw)<=8*1024*1024
    actual_sha256=hashlib.sha256(raw).hexdigest()
    raw.decode('utf-8',errors='strict')
    with target.open('xb') as f:f.write(raw)
    result.update(directDownloadAccepted=True,status=200,bytes=len(raw),sha256=actual_sha256,acquisitionMode='DIRECT_UNMODIFIED_OFFICIAL_HTTP',source=run['head_sha'],
        matchesCompleteOfficialConnectorResponse=False,finishedAt=datetime.now(timezone.utc).isoformat())
    (O/'official-direct-download-authenticated-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    break
else:raise RuntimeError('Too many official log redirects')
