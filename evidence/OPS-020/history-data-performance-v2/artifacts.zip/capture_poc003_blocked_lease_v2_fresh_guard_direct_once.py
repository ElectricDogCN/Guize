"""Read official bodies once, then derive one explicitly labelled merge guard."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,urllib.request

t=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--pr',type=int,required=True);p.add_argument('--run',type=int,required=True);a=p.parse_args()
c=json.loads((t/'poc003-blocked-lease-v2-current-candidate.json').read_bytes());S,B=c['source'],c['base']
thread_path=t/'poc003-blocked-lease-v2-final-threads-direct-input.json'
threads=json.loads(thread_path.read_bytes())
assert threads['pullRequest']==a.pr and threads['repo']=='ElectricDogCN/Guize'
started=datetime.now(timezone.utc)
thread_at=datetime.fromisoformat(threads['capturedAt'].replace('Z','+00:00'))
assert 0<=(started-thread_at).total_seconds()<30
O=t/'poc003-blocked-lease-v2-fresh-guard-direct';O.mkdir()
credential=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never'))
assert credential.returncode==0,'Existing GitHub Git login unavailable'
fields=dict(x.split(b'=',1) for x in credential.stdout.splitlines() if b'=' in x)
assert fields.get(b'password'),'Existing GitHub Git login unavailable'
token=fields[b'password'].decode('utf-8')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
endpoints={
 'main':'git/ref/heads/main',
 'pr':'pulls/'+str(a.pr),
 'issue':'issues/131',
 'run':'actions/runs/'+str(a.run),
 'jobs':'actions/runs/'+str(a.run)+'/jobs',
 'latest':'actions/runs?head_sha='+S+'&per_page=10',
 'reviews':'pulls/'+str(a.pr)+'/reviews?per_page=100'}
guard={'capturedAt':threads['capturedAt'],'threads':threads['review_threads']}
manifest={'kind':'DERIVED_GUARD_FROM_SEPARATELY_PRESERVED_OFFICIAL_RESPONSES',
 'startedAt':started.isoformat(),'requests':[],
 'threadsInput':{'path':thread_path.name,'bytes':thread_path.stat().st_size,'sha256':hashlib.sha256(thread_path.read_bytes()).hexdigest()},
 'authentication':'Existing Git GCM login in memory; never printed/persisted or sent outside api.github.com',
 'originalResponsesSavedSeparately':True}
for key,route in endpoints.items():
    url='https://api.github.com/repos/ElectricDogCN/Guize/'+route
    request=urllib.request.Request(url,headers={'User-Agent':'guize-official-merge-guard','Accept':'application/vnd.github+json','Authorization':'Bearer '+token})
    with opener.open(request,timeout=20) as response:
        assert response.status==200
        raw=response.read(2*1024*1024+1);assert len(raw)<=2*1024*1024
    with (O/(key+'.official-body.json')).open('xb') as f:f.write(raw)
    guard[key]=json.loads(raw)
    manifest['requests'].append({'field':key,'url':url,'status':200,'bodyFile':key+'.official-body.json','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'observedAt':datetime.now(timezone.utc).isoformat()})
    (O/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
assert (datetime.now(timezone.utc)-thread_at).total_seconds()<120
assert guard['main']['object']['sha']==B
assert guard['pr']['head']['sha']==S
assert guard['pr']['mergeable'] is True and guard['pr']['mergeable_state']=='clean'
assert not any(not x['is_resolved'] for x in guard['threads'])
guard['provenance']={'kind':manifest['kind'],'manifest':'poc003-blocked-lease-v2-fresh-guard-direct/capture-manifest.json','derivedNotSingleOfficialResponse':True}
raw=(json.dumps(guard,indent=2)+'\n').encode('utf-8')
target=t/'poc003-blocked-lease-v2-fresh-final-merge-guard-direct.json'
with target.open('xb') as f:f.write(raw)
manifest.update(finishedAt=datetime.now(timezone.utc).isoformat(),guardFile=target.name,guardBytes=len(raw),guardSha256=hashlib.sha256(raw).hexdigest(),complete=True)
(O/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'derivedGuard':target.name,'officialBodies':7,'fresh':True,'unresolved':0,'bytes':len(raw),'sha256':manifest['guardSha256']}),flush=True)
