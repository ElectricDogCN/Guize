"""Fresh isolated Git protocol boundaries; no Guize checker implementation edit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,locale,os,re,subprocess,sys,tempfile
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;out=t/'ops020-git-batch-boundary-prototype-v1';out.mkdir()
root=Path('/home/sur/.cache/guize-takeover/ops020-git-batch-boundaries-v1');assert not root.exists();root.mkdir()
result=dict(kind='private_isolated_git_batch_boundaries_not_source_or_ci_acceptance',root=str(root),observations=[],ownedChildren=[],repoCheckerEdited=False)
def git(*args,input=None,repo=root):
 p=subprocess.run(['git','-C',str(repo),*args],input=input,capture_output=True)
 assert p.returncode==0,p.stderr.decode(errors='replace')
 return p.stdout.decode().strip()
def fresh(repo,expression):return subprocess.run(['git','show',expression],cwd=repo,capture_output=True,text=True)
class Reader:
 def __init__(self,repo):
  self.repo=repo;self.p=None;self.stderr=None;self.disabled=False
  common=git('rev-parse','--git-common-dir',repo=repo)
  self.common=(repo/common).resolve() if not Path(common).is_absolute() else Path(common)
 def allowed(self):
  if (self.common/'info/grafts').exists() or (self.common/'reftable').exists():return False
  path=self.common/'refs/replace'
  if path.is_dir() and any(path.iterdir()):return False
  packed=self.common/'packed-refs'
  return not packed.exists() or b' refs/replace/' not in packed.read_bytes()
 def show(self,expression):
  if self.disabled or not re.fullmatch(r'[0-9a-f]{40}:[A-Za-z0-9_./-]+',expression) or not self.allowed():
   if not self.allowed():self.close();self.disabled=True
   return fresh(self.repo,expression)
  try:
   if self.p is None:
    self.stderr=tempfile.TemporaryFile()
    self.p=subprocess.Popen(['git','cat-file','--batch'],cwd=self.repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
    result['ownedChildren'].append(dict(pid=self.p.pid,closed=False,exitCode=None))
   self.p.stdin.write(expression.encode('ascii')+b'\n');self.p.stdin.flush()
   parts=self.p.stdout.readline().rstrip(b'\n').split()
   if len(parts)!=3 or not re.fullmatch(rb'[0-9a-f]{40}',parts[0]) or not parts[2].isdigit():raise ValueError('Unsupported batch header')
   data=self.p.stdout.read(int(parts[2]));assert len(data)==int(parts[2]) and self.p.stdout.read(1)==b'\n'
   if parts[1]!=b'blob' or os.fstat(self.stderr.fileno()).st_size or not self.allowed():raise ValueError('Use original Git behavior')
   text=data.decode(locale.getpreferredencoding(False)).replace('\r\n','\n').replace('\r','\n')
   return subprocess.CompletedProcess(['git','show',expression],0,text,'')
  except (OSError,ValueError,AssertionError):
   self.close();self.disabled=True
   return fresh(self.repo,expression)
 def close(self):
  if self.p is not None:
   try:self.p.stdin.close()
   except (OSError,ValueError):pass
   self.p.stdout.close();code=self.p.wait()
   row=next(row for row in result['ownedChildren'] if row['pid']==self.p.pid);row.update(closed=True,exitCode=code)
   self.stderr.close();self.p=None;self.stderr=None
def compare(reader,expression,label):
 expected=fresh(reader.repo,expression);actual=reader.show(expression)
 assert (actual.returncode,actual.stdout,actual.stderr)==(expected.returncode,expected.stdout,expected.stderr),label
 result['observations'].append(dict(case=label,returnCode=actual.returncode,stdoutSha256=hashlib.sha256(actual.stdout.encode()).hexdigest(),equalAllProcessFields=True))
 return actual
git('init','--quiet','-b','main');git('config','user.name','Batch boundary fixture');git('config','user.email','batch@example.invalid');git('config','commit.gpgsign','false');git('config','core.autocrlf','false')
(root/'dir').mkdir()
payloads={'unicode.yaml':'title: 归泽\nvalue: original\n'.encode(),'crlf.yaml':b'a: one\r\nb: two\r\n','cr.yaml':b'a: one\rb: two\r','empty.yaml':b'','dir/child.yaml':b'item: nested\n'}
for name,data in payloads.items():(root/name).write_bytes(data)
git('add','.');git('commit','--quiet','-m','Isolated protocol fixture');commit=git('rev-parse','HEAD')
reader=Reader(root)
for name in payloads:compare(reader,commit+':'+name,'content-'+name)
compare(reader,commit+':missing.yaml','missing-fallback');reader.close()
reader=Reader(root);compare(reader,commit+':dir','tree-fallback');reader.close()
reader=Reader(root);compare(reader,commit+':unicode.yaml','before-dynamic-replace')
old=git('rev-parse',commit+':unicode.yaml');replacement=git('hash-object','-w','--stdin',input=b'value: replaced\n')
git('replace',old,replacement)
compare(reader,commit+':unicode.yaml','loose-replace-after-reader-start')
git('pack-refs','--all');compare(reader,commit+':unicode.yaml','packed-replacement')
third=git('hash-object','-w','--stdin',input=b'value: replacement-changed\n');git('update-ref','refs/replace/'+old,third)
compare(reader,commit+':unicode.yaml','replacement-target-changed')
git('replace','-d',old);compare(reader,commit+':unicode.yaml','replacement-removed');reader.close()
reader=Reader(root);compare(reader,commit+':unicode.yaml','reader-before-owned-eof')
reader.p.stdin.close();reader.p.wait();compare(reader,commit+':unicode.yaml','owned-child-eof-fallback');reader.close()
linked=root.parent/'ops020-git-batch-boundaries-linked-v1';assert not linked.exists()
git('worktree','add','--quiet','--detach',str(linked),commit)
reader=Reader(linked);compare(reader,commit+':unicode.yaml','linked-worktree-blob')
git('replace',old,replacement);compare(reader,commit+':unicode.yaml','linked-shared-replacement');git('replace','-d',old);reader.close()
reader=Reader(root);compare(reader,commit+':unicode.yaml','before-graft-warning')
(root/'.git/info/grafts').write_text(commit+'\n',encoding='utf-8')
compare(reader,commit+':unicode.yaml','graft-original-stderr-preserved');reader.close()
assert all(row['closed'] and row['exitCode']==0 for row in result['ownedChildren'])
result.update(boundariesPassed=True,finishedAt=datetime.now(timezone.utc).isoformat(),testFixtureRetained=True,fullCiAccepted=False)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(boundaries=len(result['observations']),allEqual=True,children=len(result['ownedChildren']),allOwnedChildrenClosedZero=True,checkerEdited=False)),flush=True)
