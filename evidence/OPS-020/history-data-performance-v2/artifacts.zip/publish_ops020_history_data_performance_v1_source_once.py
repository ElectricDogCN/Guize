"""Publish only the new exact forward source after independent review/source15."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,xml.etree.ElementTree as ET
import yaml
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;sha=lambda raw:hashlib.sha256(raw).hexdigest()
c=json.loads((t/'ops020-history-data-performance-v1-current-candidate.json').read_bytes())
r=Path(c['author']);s,b,branch=c['source'],c['base'],c['branch'];ref='refs/heads/'+branch
receipt=t/'ops020-history-data-performance-v1-source-publication-independent-review.json'
assert sha(receipt.read_bytes())==a.review_sha256
v=json.loads(receipt.read_bytes())
assert v['source']==s and v['base']==b and v['tree']==c['tree'] and v['codeAndEvidenceReviewAccepted'] and v['publicationApproved'] and not v['mustFix']
assert v['publisherMethodSha256']==sha(Path(__file__).read_bytes())
d=t/'ops020-history-data-performance-v1-native-source15';g=json.loads((d/'results.json').read_bytes())
assert g['source']==s and g['base']==b and g['declared15Passed'] and g['before']==g['after'] and len(g['commands'])==15
for row in g['commands']:
 raw=(d/row['raw']).read_bytes();assert row['actualWaitCompleted'] and row['exitCode']==0 and len(raw)==row['bytes'] and sha(raw)==row['sha256']
cases=list(ET.fromstring((d/'junit.xml').read_bytes()).iter('testcase'))
assert len(cases)==60 and not any(case.find(tag) is not None for case in cases for tag in ('failure','error','skipped'))
inventory=json.loads((t/'ops020-history-data-performance-v1-expected902-ci-cases.json').read_bytes())
assert inventory['source']==s and inventory['original898Preserved'] and len(inventory['expectedCases'])==902
own=next(row for row in yaml.safe_load((r/'specs/coordination/active-work.yaml').read_bytes())['tasks'] if row['taskId']=='OPS-020')
assert own['status']=='in_progress' and own['agentRole']=='implementer' and own['baseSha']==b and own['branch']==branch and own['exclusivePaths']==c['claims']
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
env['GIT_CONFIG_PARAMETERS']=(env.get('GIT_CONFIG_PARAMETERS','').strip()+" 'http.proxy=' 'http.version=HTTP/1.1'").strip()
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*args],env=env).decode().strip()
assert git('rev-parse','HEAD')==s and git('rev-parse','HEAD^{tree}')==c['tree'] and git('show','-s','--format=%P',s)==c['parent']
assert git('show','-s','--format=%P',c['parent'])==b and git('branch','--show-current')==branch and not git('status','--porcelain=v1','--untracked-files=all')
assert git('diff','--name-only',b,s).splitlines()==c['changedPaths'] and len(c['changedPaths'])==16
for pin in c['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
assert git('remote','get-url','origin')=='https://github.com/ElectricDogCN/Guize.git'
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[b,'refs/heads/main'] and not git('ls-remote','--heads','origin',ref)
out=t/'ops020-history-data-performance-v1-publication';out.mkdir();hooks=out/'hooks';hooks.mkdir()
(hooks/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n test "$local_ref" = "'+ref+'"\n test "$local_sha" = "'+s+'"\n test "$remote_ref" = "'+ref+'"\n test "$remote_sha" = "'+'0'*40+'"\n count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf-8',newline='\n')
argv=['git','-c','core.longpaths=true','-c','credential.interactive=never','-c','core.hooksPath='+hooks.as_posix(),'-C',str(r),'push','--porcelain','origin',ref+':'+ref]
result=dict(source=s,base=b,branch=branch,argv=argv,publicationReviewSha256=a.review_sha256,forceUsed=False,
 actualWaitCompleted=False,fullCiAccepted=False,actualMainAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
 child=subprocess.Popen(argv,env=env,stdout=stdout,stderr=stderr);result['pid']=child.pid;save();code=child.wait()
 result.update(exitCode=code,actualWaitCompleted=True,finishedAt=datetime.now(timezone.utc).isoformat());save()
assert code==0
remote=git('ls-remote','--heads','origin',ref).split();result['actualRemoteAfter']=remote;save()
assert remote==[s,ref] and git('ls-remote','--heads','origin','refs/heads/main').split()==[b,'refs/heads/main'] and not git('status','--porcelain=v1','--untracked-files=all')
result['postValidationPassed']=True;save()
print(json.dumps(dict(source=s,branch=branch,actualExitCode=code,postValidationPassed=True)),flush=True)
