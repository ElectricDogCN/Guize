"""Publish exactly the accepted normal Completion source to one new remote ref."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,yaml
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent
rp=t/'ops019-normal-completion-v2-publication-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(rp.read_bytes());assert v['publicationApproved'] and not v['mustFix']
assert v['publisherMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
c=json.loads((t/'ops019-normal-completion-v2-current-candidate.json').read_bytes());S,M,B=c['source'],c['base'],c['branch'];R=Path(c['author']);REF='refs/heads/'+B
assert v['source']==S and v['base']==M
out14=t/'ops019-normal-completion-v2-native-source14';g=json.loads((out14/'results.json').read_bytes())
assert g['source']==S and g['base']==M and g['declared14Passed'] and g['before']==g['after'] and len(g['commands'])==14
for row in g['commands']:
 raw=(out14/row['raw']).read_bytes();assert row['actualWaitCompleted'] and row['exitCode']==0 and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*args],env=env,timeout=120).decode().strip()
assert git('rev-parse','HEAD')==S and git('rev-parse','HEAD^{tree}')==c['tree'] and git('show','-s','--format=%P',S)==c['completionMetadataCommit']
assert git('branch','--show-current')==B and not git('status','--porcelain=v1','--untracked-files=all')
assert sorted(git('diff','--name-only',M,S).splitlines())==sorted(c['changedPaths']) and len(c['changedPaths'])==23
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main'] and not git('ls-remote','--heads','origin',REF)
assert B=='chore/OPS-019-controlled-lfs-completion' and git('show','-s','--format=%P',c['approvalCreator'])==M
assert c['approvalCreator']=='ebe0c0ae417fd15d575c8c55da3a8cd955256936' and c['completionMetadataCommit']=='a67129c9e591657f921c23613706ca96e2e7ed1d'
assert git('show','-s','--format=%P',c['completionMetadataCommit'])==c['approvalCreator']
assert git('rev-list','--reverse',M+'..'+S).splitlines()==[c['approvalCreator'],c['completionMetadataCommit'],S]
assert sorted(git('diff','--name-only',c['completionMetadataCommit'],S).splitlines())==sorted(c['evidenceRepairPaths'])
assert all(name.startswith('evidence/OPS-019/') and name!='evidence/OPS-019/implementation-v1/migration-approval.json' for name in c['evidenceRepairPaths'])
active=yaml.safe_load((R/'specs/coordination/active-work.yaml').read_bytes())
registered=yaml.safe_load(git('show',M+':specs/coordination/active-work.yaml'))
own=next(x for x in registered['tasks'] if x['taskId']=='OPS-019')
assert own['status']=='review' and own['agentRole']=='reviewer' and own['reviewer']=='/root/independent_review' and own['implementer']=='/root'
assert len(active['tasks'])==2 and not any(x['taskId']=='OPS-019' or x['riskLevel'] in ('high','critical') for x in active['tasks'])
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
foundation=next(x for x in yaml.safe_load((R/'specs/coordination/program-plan.yaml').read_bytes())['foundationTasks'] if x['taskId']=='OPS-019')
assert foundation==dict(taskId='OPS-019',title=foundation['title'],status='completed',completionRef='PR-187',mergeCommit='02997ddaee951e054a5ce106e0566847f546d8cd')
front=yaml.safe_load((R/'specs/tasks/OPS-019.md').read_text(encoding='utf-8').split('---',2)[1])
assert front['status']=='completed' and front['agentRole']=='integrator' and front['baseSha']==M and front['workBranch']==B
APP='evidence/OPS-019/implementation-v1/migration-approval.json'
assert hashlib.sha256((R/APP).read_bytes()).hexdigest()==c['conditionalApprovalRecordSha256']
precommit=json.loads((t/'ops019-normal-completion-v2-structured-evidence-precommit-independent-review.json').read_bytes())
assert hashlib.sha256((t/'ops019-normal-completion-v2-structured-evidence-precommit-independent-review.json').read_bytes()).hexdigest()==c['evidenceRepairPrecommitReviewSha256']
for pin in c['fileSnapshot']:
 raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
for name in ['specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
 assert (R/name).read_bytes()==subprocess.check_output(['git','-C',str(R),'show',M+':'+name])
for name in ['specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml','specs/tasks/OPS-019.md',APP,'.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
 assert subprocess.check_output(['git','-C',str(R),'show',S+':'+name])==subprocess.check_output(['git','-C',str(R),'show',c['completionMetadataCommit']+':'+name])
O=t/'ops019-normal-completion-v2-publication';O.mkdir();H=O/'hooks';H.mkdir()
(H/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n  test "$local_ref" = "'+REF+'"\n  test "$local_sha" = "'+S+'"\n  test "$remote_ref" = "'+REF+'"\n  test "$remote_sha" = "'+'0'*40+'"\n  count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf8',newline='\n')
argv=['git','-c','core.longpaths=true','-c','credential.interactive=never','-c','core.hooksPath='+H.as_posix(),'-C',str(R),'push','--porcelain','origin',REF+':'+REF]
result=dict(source=S,base=M,tree=c['tree'],branch=B,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),publicationReviewSha256=a.review_sha256,fullCiAccepted=False,actualMergeApproved=False,forceOptionUsed=False,actualWaitCompleted=False)
save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n')
save()
with (O/'stdout.raw').open('xb') as so,(O/'stderr.raw').open('xb') as se:
 child=subprocess.Popen(argv,env=env,stdout=so,stderr=se);result['pid']=child.pid;save();code=child.wait();result.update(actualWaitCompleted=True,exitCode=code,finishedAt=datetime.now(timezone.utc).isoformat());save()
assert code==0
remote=git('ls-remote','--heads','origin',REF).split();result['actualRemoteAfter']=remote;save()
assert remote==[S,REF] and not git('status','--porcelain=v1','--untracked-files=all')
result['postValidationPassed']=True;save();print(json.dumps(result),flush=True)
