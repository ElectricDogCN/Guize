"""Offline exact867 official CI snapshot validation; no network or execution claim."""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('--folder',required=True);p.add_argument('--candidate',required=True);p.add_argument('--phase',choices=['source','main'],required=True);p.add_argument('--pull-request',type=int,required=True);p.add_argument('--expected-run',type=int,required=True);p.add_argument('--expected-job',type=int,required=True);p.add_argument('--dry-run',action='store_true');p.add_argument('--log-file',choices=['job-log.connector-decoded.utf8.txt','job-log.official-direct-download.utf8.txt'],default='job-log.connector-decoded.utf8.txt');a=p.parse_args()
t=Path(__file__).resolve().parent;d=t/a.folder
read=lambda x:json.loads(Path(x).read_bytes())
c=read(t/a.candidate);S,M,T=c['source'],c['base'],c['tree']
run,jobs,checkout=[read(d/name) for name in ['run.json','jobs.json','checkout.json']]
assert run['id']==a.expected_run and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success'
assert jobs['total_count']==len(jobs['jobs'])==1
j=jobs['jobs'][0];assert j['id']==a.expected_job and j['run_id']==run['id'] and j['run_attempt']==1 and j['status']=='completed' and j['conclusion']=='success'
assert j['name']=='Governance Checks' and run['name']=='Governance Gate' and 'ubuntu-latest' in j['labels']
steps=j['steps'];reference=read(t/'ops019-implementation-pr187-source-ci944-final/jobs.json')['jobs'][0]['steps']
assert len(steps)==28 and [x['name'] for x in steps]==[x['name'] for x in reference]
main_skips={'Task file validation','Evidence check','Evidence integrity check','Task-branch linkage check','Scope check'}
expected_skips=set() if a.phase=='source' else main_skips
assert all(x['status']=='completed' and x['conclusion']==('skipped' if x['name'] in expected_skips else 'success') for x in steps)
assert {x['name'] for x in steps if x['conclusion']=='skipped'}==expected_skips
if a.phase=='source':assert run['event']=='pull_request' and run['head_sha']==S
else:assert run['event']=='push' and run['head_sha']==c['actualMain'] and checkout['sha']==c['actualMain']
assert [x['sha'] for x in checkout['parents']]==[M,S] and checkout['tree']['sha']==T
raw=(d/a.log_file).read_bytes();text=raw.decode('utf-8')
if a.log_file=='job-log.official-direct-download.utf8.txt':
 downloaded=read(d/'official-direct-download-authenticated-result.json')
 assert downloaded['directDownloadAccepted'] and downloaded['status']==200 and downloaded['job']==j['id'] and downloaded['run']==run['id']
 assert downloaded['acquisitionMode']=='DIRECT_UNMODIFIED_OFFICIAL_HTTP' and downloaded['endpoint']=='https://api.github.com/repos/ElectricDogCN/Guize/actions/jobs/'+str(j['id'])+'/logs'
 assert downloaded['source']==run['head_sha'] and not downloaded['matchesCompleteOfficialConnectorResponse'] and downloaded['expectedConnectorSha256'] is None
 assert len(raw)==downloaded['bytes'] and hashlib.sha256(raw).hexdigest()==downloaded['sha256']
lines=[re.sub(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?','',x).rstrip('\r') for x in text.splitlines()]
indices=[i for i,line in enumerate(lines) if re.fullmatch(r'\[command\].*git log -1 --format=%H',line)]
assert len(indices)==1 and lines[indices[0]+1]==checkout['sha']
case_ids=re.findall(r'^(tests/.+?)[ \t]+PASSED(?:[ \t]+\[[ \t]*\d+%\])?[ \t]*$', '\n'.join(lines),re.M)
expectfile=t/'ops019-implementation-final3459-expected867-ci-cases.json'
assert hashlib.sha256(expectfile.read_bytes()).hexdigest()=='0d15283b4b0ba2a80e9725274d8e5124641c3bf6c017db48d08c1dfe01df1050'
expected=read(expectfile)['expectedCases']
assert len(case_ids)==len(set(case_ids))==len(expected)==867 and set(case_ids)==set(expected)
bad=re.findall(r'^tests/.+?[ \t]+(?:FAILED|ERROR|SKIPPED|XFAIL|XPASS)(?=[ \t]|$)', '\n'.join(lines),re.M)
assert not bad and not any(line.startswith(('##[error]','::error')) for line in lines)
summaries=re.findall(r'=+\s+867 passed in ([\d.]+)s',text);assert len(summaries)==1
assert sum(line=='OK: No skipped tests' for line in lines)==1
assert any('git lfs fetch origin' in line for line in lines)
probe='tests/governance/test_work_branch_migration.py::test_real_lfs_probe_materialized_and_pointer_tracked';assert probe in case_ids
seconds=(datetime.fromisoformat(j['completed_at'].replace('Z','+00:00'))-datetime.fromisoformat(j['started_at'].replace('Z','+00:00'))).total_seconds();assert 0<seconds<1800
result=dict(source=S,base=M,tree=T,phase=a.phase,pullRequest=a.pull_request,run=run['id'],runNumber=run['run_number'],job=j['id'],attempt=1,conclusion='success',uniquePassed=867,original842Plus25Exact=True,failedErroredSkippedXfailXpass=0,actualCheckout=checkout['sha'],orderedParents=[M,S],successSteps=len(steps)-len(expected_skips),conditionalSkippedSteps=sorted(expected_skips),totalSteps=28,pytestSeconds=float(summaries[0]),jobSeconds=seconds,realLfsFetchAndHydratedProbePassed=True,skipAuditSucceeded=True,logBytes=len(raw),logSha256=hashlib.sha256(raw).hexdigest(),logFile=a.log_file,directOfficialHttpLogDownloaded=a.log_file=='job-log.official-direct-download.utf8.txt',decodedConnectorUtf8=False,authoritativeLogAcquisition='direct unmodified official HTTP job log',originalHttpArchiveDownloaded=False,separateCloudJunitDownloaded=False)
if not a.dry_run:
 with (d/'capture.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
