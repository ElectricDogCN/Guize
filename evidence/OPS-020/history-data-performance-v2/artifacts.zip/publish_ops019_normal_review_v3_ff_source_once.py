"""Publish exactly the accepted normal Review source to one new remote ref."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,yaml
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent
rp=t/'ops019-normal-review-v3-publication-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(rp.read_bytes());assert v['publicationApproved'] and not v['mustFix']
assert v['publisherMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
c=json.loads((t/'ops019-normal-review-v3-current-candidate.json').read_bytes());S,M,B=c['source'],c['base'],c['branch'];R=Path(c['author']);REF='refs/heads/'+B
assert v['source']==S and v['base']==M
out14=t/'ops019-normal-review-v3-native-source14';g=json.loads((out14/'results.json').read_bytes())
assert g['source']==S and g['base']==M and g['declared14Passed'] and g['before']==g['after'] and len(g['commands'])==14
for row in g['commands']:
 raw=(out14/row['raw']).read_bytes();assert row['actualWaitCompleted'] and row['exitCode']==0 and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*args],env=env,timeout=120).decode().strip()
assert git('rev-parse','HEAD')==S and git('rev-parse','HEAD^{tree}')==c['tree'] and git('show','-s','--format=%P',S)==c['parents'][0]
assert git('branch','--show-current')==B and not git('status','--porcelain=v1','--untracked-files=all')
assert sorted(git('diff','--name-only',M,S).splitlines())==sorted(c['changedPaths']) and len(c['changedPaths'])==14
OLD=c['parents'][0];assert OLD=='a8ae2472033c41c674e9761a79b695540575c189'
assert git('rev-list','--reverse',M+'..'+S).splitlines()==[OLD,S]
assert git('ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main'] and git('ls-remote','--heads','origin',REF).split()==[OLD,REF]
for pin in c['fileSnapshot']:
 raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
active=yaml.safe_load((R/'specs/coordination/active-work.yaml').read_bytes());own=next(x for x in active['tasks'] if x['taskId']=='OPS-019')
assert own['status']=='review' and own['agentRole']=='reviewer' and own['baseSha']==M and own['branch']==B and own['reviewer']=='/root/independent_review' and own['implementer']=='/root'
assert len(active['tasks'])==3 and sum(x['riskLevel'] in ('high','critical') for x in active['tasks'])==1
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
assert not (R/'evidence/OPS-019/implementation-v1/migration-approval.json').exists()
O=t/'ops019-normal-review-v3-publication';O.mkdir();H=O/'hooks';H.mkdir()
(H/'pre-push').write_text('#!/bin/sh\nset -eu\ncount=0\nwhile read -r local_ref local_sha remote_ref remote_sha; do\n  test "$local_ref" = "'+REF+'"\n  test "$local_sha" = "'+S+'"\n  test "$remote_ref" = "'+REF+'"\n  test "$remote_sha" = "'+OLD+'"\n  count=$((count+1))\ndone\ntest "$count" = 1\n',encoding='utf8',newline='\n')
argv=['git','-c','core.longpaths=true','-c','credential.interactive=never','-c','core.hooksPath='+H.as_posix(),'-C',str(R),'push','--porcelain','origin',REF+':'+REF]
result=dict(source=S,base=M,oldRemote=OLD,tree=c['tree'],branch=B,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),publicationReviewSha256=a.review_sha256,fullCiAccepted=False,actualMergeApproved=False,forceOptionUsed=False,actualWaitCompleted=False)
save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n')
save()
with (O/'stdout.raw').open('xb') as so,(O/'stderr.raw').open('xb') as se:
 child=subprocess.Popen(argv,env=env,stdout=so,stderr=se);result['pid']=child.pid;save();code=child.wait();result.update(actualWaitCompleted=True,exitCode=code,finishedAt=datetime.now(timezone.utc).isoformat());save()
assert code==0
remote=git('ls-remote','--heads','origin',REF).split();result['actualRemoteAfter']=remote;save()
assert remote==[S,REF] and not git('status','--porcelain=v1','--untracked-files=all')
result['postValidationPassed']=True;save();print(json.dumps(result),flush=True)
