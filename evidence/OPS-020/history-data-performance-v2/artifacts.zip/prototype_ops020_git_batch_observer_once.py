"""Observe real Git reads and compare batch bytes; always return original results.

Private diagnostic only: no repository/checker bytes or validation decisions are
replaced. The original case and complete actual H checks execute normally.
"""
from pathlib import Path
from datetime import datetime,timezone
from contextvars import ContextVar
import contextlib,fcntl,hashlib,importlib.util,json,locale,os,re,subprocess,sys,time
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
c=json.loads((t/'ops020-history-data-performance-v1-current-candidate.json').read_bytes())
g=json.loads((t/'ops020-history-data-performance-v1-native-source15/results.json').read_bytes())
assert g['source']==c['source'] and g['declared15Passed']
r=Path(g['nativeRepo']);out=t/'ops020-git-batch-readonly-observer-v1';out.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
os.environ.pop('GIT_LFS_SKIP_SMUDGE',None)
def git(*args):return subprocess.check_output(['git','-C',str(r),*args]).decode().strip()
state=lambda:dict(head=git('rev-parse','HEAD'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before['head']==c['source'] and not before['status']
result=dict(kind='observational_git_batch_comparison_returning_original_results_only',source=c['source'],startedAt=datetime.now(timezone.utc).isoformat(),
 originalGitCalls=0,originalGitSeconds=0.0,eligibleOriginalShowSeconds=0.0,batchSeconds=0.0,comparisons=0,unsupported=0,mismatches=[],sessions=[],
 repoEdited=False,checkerEdited=False,originalResultsAlwaysReturned=True,formalSourceOrCiAcceptance=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
active=ContextVar('guize_observational_batch_session',default=None)
unsupported=object()
class Reader:
 def __init__(self,root):
  self.root=os.path.abspath(str(root));self.process=None
  self.row=dict(root=self.root,queries=0,pid=None,exitCode=None,closed=False)
  result['sessions'].append(self.row)
 def read(self,expression):
  if self.process is None:
   self.process=subprocess.Popen(['git','cat-file','--batch'],cwd=self.root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   self.row['pid']=self.process.pid
  p=self.process;self.row['queries']+=1
  p.stdin.write(expression.encode('ascii')+b'\n');p.stdin.flush()
  header=p.stdout.readline();parts=header.rstrip(b'\n').split()
  if len(parts)==2 and parts[-1] in {b'missing',b'ambiguous'}:return unsupported
  assert len(parts)==3 and re.fullmatch(rb'[0-9a-f]{40}',parts[0]) and parts[2].isdigit(),header
  size=int(parts[2]);data=p.stdout.read(size);assert len(data)==size and p.stdout.read(1)==b'\n'
  if parts[1]!=b'blob':return unsupported
  return data.decode(locale.getpreferredencoding(False)).replace('\r\n','\n').replace('\r','\n')
 def close(self):
  if self.process is not None:
   self.process.stdin.close();self.process.stdout.close();self.row['exitCode']=self.process.wait()
  self.row['closed']=True
original_spec=importlib.util.spec_from_file_location
target=(r/'scripts/check-program-plan-history.py').resolve()
class Loader:
 def __init__(self,inner):self.inner=inner
 def create_module(self,spec):return self.inner.create_module(spec)
 def exec_module(self,module):
  self.inner.exec_module(module)
  original_git=module.git;original_validate=module.validate_foundations
  def observed_git(root,*args):
   tick=time.perf_counter();value=original_git(root,*args);elapsed=time.perf_counter()-tick
   result['originalGitCalls']+=1;result['originalGitSeconds']+=elapsed
   reader=active.get()
   if reader is not None and os.path.abspath(str(root))==reader.root and len(args)==2 and args[0]=='show' and re.fullmatch(r'[0-9a-f]{40}:[A-Za-z0-9_./-]+',args[1]):
    result['eligibleOriginalShowSeconds']+=elapsed
    tick=time.perf_counter();compared=reader.read(args[1]);result['batchSeconds']+=time.perf_counter()-tick
    if compared is unsupported:result['unsupported']+=1
    else:
     result['comparisons']+=1
     if value.returncode!=0 or compared!=value.stdout:
      result['mismatches'].append(dict(root=reader.root,expression=args[1],originalReturnCode=value.returncode))
      raise AssertionError('Batch prototype bytes differ from original Git output')
   return value
  def observed_validate(root,*args,**kwargs):
   reader=Reader(root);token=active.set(reader)
   try:return original_validate(root,*args,**kwargs)
   finally:active.reset(token);reader.close();save()
  module.git=observed_git;module.validate_foundations=observed_validate
def observed_spec(name,location,*args,**kwargs):
 spec=original_spec(name,location,*args,**kwargs)
 if Path(location).resolve()==target:spec.loader=Loader(spec.loader)
 return spec
importlib.util.spec_from_file_location=observed_spec
case='tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration'
save();tick=time.perf_counter();os.chdir(r)
with (out/'pytest.raw').open('x',encoding='utf-8',buffering=1) as raw,contextlib.redirect_stdout(raw),contextlib.redirect_stderr(raw):
 import pytest
 code=pytest.main(['-q',case,'--durations=3','--junitxml='+str(out/'junit.xml')])
importlib.util.spec_from_file_location=original_spec
raw=(out/'pytest.raw').read_bytes()
result.update(exitCode=int(code),elapsedSeconds=time.perf_counter()-tick,rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),
 before=before,after=state(),finishedAt=datetime.now(timezone.utc).isoformat(),
 caveat='Observer runs both paths sequentially and warms object data. This is equality/feasibility evidence, not full CI timing or permission acceptance.')
save()
print(json.dumps({key:result[key] for key in ['exitCode','elapsedSeconds','originalGitCalls','originalGitSeconds','eligibleOriginalShowSeconds','batchSeconds','comparisons','unsupported','mismatches']}),flush=True)
assert code==0 and result['after']==before and not result['mismatches'] and result['comparisons']>100
assert all(row['closed'] and row['exitCode'] in (None,0) for row in result['sessions'])
