"""Commit only the exact independently reviewed OPS020 reservation metadata."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,shlex
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args();T=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
rp=T/'ops020-reservation-v2-precommit-independent-review.json';assert sha(rp.read_bytes())==a.review_sha256
r=json.loads(rp.read_bytes());assert r['candidateCommitAllowed'] and r['fixedSource14ChecksAllowed'] and not r['mustFix'] and r['commitMethodSha256']==sha(Path(__file__).read_bytes())
c=json.loads((T/'ops020-reservation-v2-precommit-candidate.json').read_bytes());R=Path(c['author']);B,BRANCH=c['base'],c['branch']
assert r['base']==B=='251fac61809ed4b209c4fc7a71dee41ba4061db6' and r['branch']==BRANCH=='chore/OPS-020-blocked-recovery-reservation' and r['fileSnapshot']==c['fileSnapshot']
assert datetime.now(timezone.utc)<datetime.fromisoformat(c['lease']['expiresAt'].replace('Z','+00:00'))
git=lambda *args:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*args])
dec=lambda *args:git(*args).decode().strip()
assert dec('rev-parse','HEAD')==B and dec('branch','--show-current')==BRANCH and not dec('diff','--cached','--name-only')
paths=sorted(set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines()));assert paths==c['changedPaths'] and len(paths)==21
for pin in c['fileSnapshot']:
    raw=(R/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
git('add','--',*paths);assert dec('diff','--cached','--name-only').splitlines()==paths
for pin in c['fileSnapshot']:
    raw=git('show',':'+pin['path']);assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
git('diff','--cached','--check')
git('commit','-m','chore(OPS-020): reserve bounded blocked work branch recovery','-m','Refs #191. Evidence: evidence/OPS-020/. Metadata only; parent push CI and own full source CI remain integration prerequisites. No implementation or migration.')
S=dec('rev-parse','HEAD');assert dec('show','-s','--format=%P',S)==B and not dec('status','--porcelain=v1','--untracked-files=all') and dec('diff','--name-only',B,S).splitlines()==paths
bundle=T/('ops020-reservation-v2-'+S[:7]+'-increment.bundle');assert not bundle.exists();git('bundle','create',str(bundle),BRANCH,'^'+B)
protected=['.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py',*c['claims'],'specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/coordination/task-completions.yaml','specs/tasks/POC-003.md','specs/tasks/POC-005.md','evidence/OPS-019/delivery-migration-intent.json','evidence/OPS-019/implementation-v1/migration-approval.json']
pins={}
for name in protected:
    raw=(R/name).read_bytes();assert raw==git('show',B+':'+name);pins[name]=dict(bytes=len(raw),sha256=sha(raw))
out=dict(c,source=S,parents=[B],tree=dec('rev-parse','HEAD^{tree}'),bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=sha(bundle.read_bytes()),contentReview=rp.name,contentReviewSha256=a.review_sha256,codePins=pins,originalRecipe=[shlex.join(command) for command in c['commands']],leaseExpiresAt=c['lease']['expiresAt'],expectedCommands=14,expectedHostedGovernanceTests=867,declared14Passed=False,fullCiAccepted=False,committed=True,implementationTouched=False,branchMigrationExecuted=False,recordedAt=datetime.now(timezone.utc).isoformat())
with (T/'ops020-reservation-v2-current-candidate.json').open('xb') as stream:stream.write((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps(dict(source=S,base=B,tree=out['tree'],paths=21,bundle=bundle.name,implementationTouched=False)),flush=True)
