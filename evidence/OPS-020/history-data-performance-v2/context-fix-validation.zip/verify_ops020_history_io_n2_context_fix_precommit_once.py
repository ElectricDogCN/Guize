"""Target new transport regressions on exact uncommitted bytes, not full CI."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,os,subprocess,sys
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;r=t/'ops020-history-data-performance-v1'
m=json.loads((t/'ops020-history-io-v2-purpose-m2-commit.json').read_bytes());assert m['normalPurposeM2Committed']
out=t/'ops020-history-io-v2-n2-targeted-context-fix';out.mkdir()
names=['scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py']
def head():return subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip()
def state():return dict(head=head(),indexSha256=hashlib.sha256((r/'.git/index').read_bytes()).hexdigest(),
 files={name:dict(bytes=(r/name).stat().st_size,sha256=hashlib.sha256((r/name).read_bytes()).hexdigest()) for name in names})
before=state();assert before['head']==m['source']
for name in names:ast.parse((r/name).read_text(encoding='utf-8'))
argv=[sys.executable,'-B','-m','pytest','-q','tests/governance/test_work_branch_migration.py','-k','history_git_blob_','--junitxml='+str(out/'junit.xml')]
with (out/'pytest.raw').open('xb') as stream:
 child=subprocess.Popen(argv,cwd=r,stdout=stream,stderr=subprocess.STDOUT);code=child.wait()
raw=(out/'pytest.raw').read_bytes()
result=dict(kind='new_transport_targeted_precommit_tests_not_full_ci',parent=m['source'],before=before,after=state(),
 python=sys.version,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code,rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),
 snapshotScope='HEAD/index/two code files, not full-worktree proof',fullSource15Passed=False,fullCiAccepted=False,finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(raw.decode('utf-8'),flush=True)
assert code==0 and result['before']==result['after']
