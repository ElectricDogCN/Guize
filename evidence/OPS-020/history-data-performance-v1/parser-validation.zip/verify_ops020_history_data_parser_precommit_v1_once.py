"""Run only four new parser regressions on exact precommit bytes in Python3.11."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;r=t/'ops020-history-data-performance-v1'
c=json.loads((t/'ops020-history-data-performance-v1-n-precommit.json').read_bytes())
out=t/'ops020-history-data-performance-v1-precommit-parser-tests';out.mkdir()
def git(*args):return subprocess.check_output(['git','-C',str(r),*args]).decode().strip()
snapshot=lambda:dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=snapshot();assert before['head']==c['parent']
for pin in c['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
argv=[sys.executable,'-B','-m','pytest','-q','tests/governance/test_work_branch_migration.py','-k','history_yaml_data_cache','--junitxml='+str(out/'junit.xml')]
with (out/'pytest.raw').open('xb') as raw:
 child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT);code=child.wait()
raw=(out/'pytest.raw').read_bytes()
result=dict(kind='targeted_precommit_parser_tests_not_full_ci',parent=c['parent'],hSha256=c['hSha256'],testSha256=c['testSha256'],
 python=sys.version,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code,before=before,after=snapshot(),
 rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),fullSourceChecksAccepted=False,fullCiAccepted=False,finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(raw.decode('utf-8'),flush=True)
assert code==0 and result['after']==before
for pin in c['fileSnapshot']:assert hashlib.sha256((r/pin['path']).read_bytes()).hexdigest()==pin['sha256']
