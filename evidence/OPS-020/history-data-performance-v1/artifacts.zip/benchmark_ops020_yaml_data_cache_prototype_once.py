"""Bounded data-only parser microbenchmark; no checker or repository edits."""
from pathlib import Path
from datetime import datetime,timezone
from functools import lru_cache
import copy,hashlib,json,os,sys,time
import yaml
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
root=Path('/home/sur/.cache/guize-takeover/ops020-implementation-pr195-v2-main-seven-f71f850')
paths=['specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml','specs/coordination/task-completions.yaml']
texts=[(root/name).read_text(encoding='utf-8') for name in paths]
loader=getattr(yaml,'CSafeLoader',yaml.SafeLoader)
@lru_cache(maxsize=64)
def parsed(text):return yaml.load(text,Loader=loader)
def prototype(text):return copy.deepcopy(parsed(text))
assert all(prototype(text)==yaml.load(text,Loader=loader) for text in texts)
# Preserve caller mutation isolation. This is parsed data reuse, not validation.
first=prototype(texts[0]);second=prototype(texts[0]);assert first==second and first is not second
first['foundationTasks'][0]['status']='prototype-isolated-mutation'
assert prototype(texts[0])==second
start=parsed.cache_info().misses
for _ in range(2):
 try:parsed('[')
 except yaml.YAMLError:pass
 else:raise AssertionError('Malformed YAML unexpectedly parsed')
assert parsed.cache_info().misses==start+2
rows=[]
for label,parse in [('existing-CSafeLoader',lambda text:yaml.load(text,Loader=loader)),('bounded-data-cache-and-deepcopy',prototype)]:
 tick=time.perf_counter()
 for _ in range(300):
  for text in texts:parse(text)
 rows.append(dict(method=label,calls=900,elapsedSeconds=time.perf_counter()-tick))
result=dict(kind='bounded_data_only_yaml_cache_microbenchmark_not_authority_or_ci_acceptance',
 source='f71f85027e8ad64b8e6d0a3d08a39ca9596d0323',recordedAt=datetime.now(timezone.utc).isoformat(),
 inputs=[dict(path=name,bytes=(root/name).stat().st_size,sha256=hashlib.sha256((root/name).read_bytes()).hexdigest()) for name in paths],
 measurements=rows,parsedValueEquality=True,callerMutationIsolated=True,malformedYamlNotCached=True,
 cacheCapacity=64,repoEdited=False,checkerChanged=False,authorityValidationSkipped=False,
 caveat='Warm repeated-data microbenchmark only. Actual history-path speed and complete unchanged CI must be measured after any separately scoped/reviewed implementation.')
with (t/'ops020-yaml-data-cache-prototype-microbenchmark.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
