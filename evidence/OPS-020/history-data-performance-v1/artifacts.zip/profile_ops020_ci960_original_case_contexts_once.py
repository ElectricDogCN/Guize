"""Bounded same-host original-case profiles; no product or POC changes."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,subprocess,sys,time
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
out=t/'ops020-ci960-original-case-native-context-profile-v1';out.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
os.environ.pop('GIT_LFS_SKIP_SMUDGE',None)
case='tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration'
roots=[('registration-R','08ee4bc4dc3030cc86f420cc0956a0ab5146c379',Path('/home/sur/.cache/guize-takeover/ops020-reservation-v2-main-seven-08ee4bc')),
 ('actual-main-A','f71f85027e8ad64b8e6d0a3d08a39ca9596d0323',Path('/home/sur/.cache/guize-takeover/ops020-implementation-pr195-v2-main-seven-f71f850'))]
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
def state(root):return dict(head=git(root,'rev-parse','HEAD'),refs=git(root,'for-each-ref','--format=%(refname) %(objectname)'),status=git(root,'status','--porcelain=v1','--untracked-files=all'))
result=dict(kind='native_original_case_context_profiles_not_official_ci_or_unique_cause_proof',case=case,startedAt=datetime.now(timezone.utc).isoformat(),commands=[],codeChanged=False,pocExperimentStarted=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
testbytes=[]
for label,head,root in roots:
 assert root.is_dir()
 before=state(root);assert before['head']==head and not before['status']
 testbytes.append((root/'tests/governance/test_poc_contract_repair_admission.py').read_bytes())
 assert testbytes[-1]==testbytes[0]
 path=out/(label+'.pstats')
 argv=[sys.executable,'-B','-m','cProfile','-o',str(path),'-m','pytest','-q',case,'--durations=3']
 row=dict(label=label,root=str(root),source=head,before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat());result['commands'].append(row);save()
 tick=time.monotonic()
 with (out/(label+'.raw')).open('xb') as stream:
  child=subprocess.Popen(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait()
 raw=(out/(label+'.raw')).read_bytes()
 row.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),after=state(root));save()
 assert code==0 and row['after']==before
 stats=pstats.Stats(str(path))
 ranking=sorted(stats.stats.items(),key=lambda entry:entry[1][3],reverse=True)
 row['profileFunctions']=[dict(file=k[0],line=k[1],function=k[2],primitiveCalls=v[0],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in ranking[:30]]
 row.update(profileBytes=path.stat().st_size,profileSha256=hashlib.sha256(path.read_bytes()).hexdigest());save()
 print(json.dumps(dict(context=label,exitCode=code,elapsedSeconds=row['elapsedSeconds'],topFunctions=row['profileFunctions'][:6])),flush=True)
result['finishedAt']=datetime.now(timezone.utc).isoformat();save()
