"""Fresh ordinary PR198 code-merge preflight. Does not merge or migrate."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
import yaml
t=Path(__file__).resolve().parent
S='8cb551dac2f6931e2501d8c7dbeb575ff0c37a9f'
M='99714cabedd9196d0eeeb31653faaaf17211f74c'
TREE='ad1cd460a32ccfd8b9914aefaf649f5d59fce7d5'
BRANCH='chore/OPS-020-integration-history-scope'
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);args=p.parse_args()
read=lambda file:json.loads(Path(file).read_bytes())
sha=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
review_file=t/'ops020-integration-pr198-source-final-independent-review.json'
assert sha(review_file)==args.review_sha256
r=read(review_file)
assert (r['source'],r['base'],r['tree'])==(S,M,TREE)
assert r['finalSourceAccepted'] and r['fullCiAccepted'] and r['actualMergeApproved'] and not r['mustFix']
assert not r.get('bootstrapExceptionAccepted',False)
ci=r['ci']
assert ci['run']==42142843127 and ci['job']==127647129686 and ci['attempt']==1 and ci['uniquePassed']==933
assert ci['original927Plus6Exact'] and ci['original902Plus25Exact'] and ci['failedErroredSkippedXfailXpass']==0
for pin in r['evidencePins']:
    file=t/pin['path']
    assert file.stat().st_size==pin['bytes'] and sha(file)==pin['sha256']
g=read(t/'ops020-integration-pr198-fresh-final-merge-guard.json')
captured=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'))
fresh=lambda:0<=(datetime.now(timezone.utc)-captured).total_seconds()<120
assert fresh() and g['main']['object']['sha']==M
pr=g['pr']
assert pr['number']==198 and pr['state']=='open' and not pr['merged'] and not pr['draft']
assert pr['mergeable'] is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==S and pr['head']['ref']==BRANCH
assert pr['base']['sha']==M and pr['base']['ref']=='main' and pr['changed_files']==19
assert g['issue']['number']==191 and g['issue']['state']=='open'
run=g['run']
assert run['id']==42142843127 and run['run_attempt']==1 and run['head_sha']==S
assert run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert g['jobs']['total_count']==len(g['jobs']['jobs'])==1
job=g['jobs']['jobs'][0]
assert job['id']==127647129686 and job['run_id']==run['id'] and job['run_attempt']==1
assert job['status']=='completed' and job['conclusion']=='success' and len(job['steps'])==28
assert all(step['status']=='completed' and step['conclusion']=='success' for step in job['steps'])
latest=g['latest']['workflow_runs']
assert latest and latest[0]['id']==run['id'] and latest[0]['run_attempt']==1 and latest[0]['conclusion']=='success'
assert not any(not thread['is_resolved'] for thread in g['threads'])
reviews={}
for review in g['reviews']:
    reviews[review['user']['login']]=review
assert not any(review['state']=='CHANGES_REQUESTED' for review in reviews.values())
# No bot-summary capability is currently exposed. Never invent its state.
assert g['botReviewStatusAvailable'] is False and g['botSummary'] is None
checks=g['checkRuns'];assert checks['total_count']==len(checks['check_runs'])
for check in checks['check_runs']:
    assert check['status']=='completed' and check['conclusion'] in {'success','neutral','skipped'}
statuses=g['commitStatus'];assert statuses['total_count']==len(statuses['statuses'])
assert all(status['state']=='success' for status in statuses['statuses'])
candidate=read(t/'ops020-integration-scope-repair-v1-current-candidate.json')
assert candidate['source']==S and candidate['base']==M and candidate['tree']==TREE
author=Path(candidate['author']);canonical=t.parent/'Guize'
def git(root,*argv):
    return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*argv])
def dec(root,*argv):
    return git(root,*argv).decode().strip()
for root,head,branch in [(author,S,BRANCH),(canonical,M,'main')]:
    assert dec(root,'rev-parse','HEAD')==head and dec(root,'branch','--show-current')==branch
    assert not dec(root,'status','--porcelain=v1','--untracked-files=all')
assert dec(author,'merge-base',M,S)==M and dec(author,'rev-parse','HEAD^{tree}')==TREE
assert dec(author,'diff','--name-only',M,S).splitlines()==candidate['changedPaths']
assert not candidate['metadataOnly'] and len(candidate['changedPaths'])==19
assert not (author/'evidence/OPS-020/implementation-v1/recovery-approval.json').exists()
precommit_file=t/'ops020-integration-scope-repair-v1-code-precommit-independent-review.json'
assert sha(precommit_file)==candidate['precommitReviewSha256']
for pin in read(precommit_file)['fileSnapshot']:
    assert (author/pin['path']).stat().st_size==pin['bytes'] and sha(author/pin['path'])==pin['sha256']
assert dec(author,'ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main']
assert dec(author,'ls-remote','--heads','origin','refs/heads/'+BRANCH).split()==[S,'refs/heads/'+BRANCH]
for path in ['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py',
             'specs/poc/test_program.py','docs/18-testing-and-acceptance.md']:
    assert (author/path).read_bytes()==git(author,'show',M+':'+path)
before=yaml.safe_load(git(author,'show',M+':specs/coordination/active-work.yaml'))
active=yaml.safe_load((author/'specs/coordination/active-work.yaml').read_bytes())
rows=lambda d:{row['taskId']:row for row in d['tasks']}
own,registered=rows(active)['OPS-020'],rows(before)['OPS-020']
assert len(active['tasks'])==3 and sum(row['riskLevel'] in {'high','critical'} for row in active['tasks'])==1
assert own['status']=='integration' and own['agentRole']=='integrator' and own['baseSha']==M and own['branch']==BRANCH
assert registered['status']=='review' and registered['agentRole']=='reviewer'
assert registered['exclusivePaths']==['scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','scripts/check-program-plan-history.py']
assert own['exclusivePaths']==registered['exclusivePaths'] and own['sharedPaths']==[]
assert dec(author,'show','-s','--format=%P',S)==candidate['purposeSource']
assert dec(author,'show','-s','--format=%P',candidate['purposeSource'])==M
assert dec(author,'rev-list','--reverse',M+'..'+S).splitlines()==[candidate['purposeSource'],S]
code_paths={path for path in candidate['changedPaths'] if path not in {'specs/coordination/active-work.yaml','specs/coordination/program-plan.yaml','specs/tasks/OPS-020.md'} and not path.startswith('evidence/OPS-020/')}
assert code_paths=={'scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py'}
assert {key:value for key,value in own.items() if key not in {'branch','baseSha','exclusivePaths','status','agentRole'}}=={key:value for key,value in registered.items() if key not in {'branch','baseSha','exclusivePaths','status','agentRole'}}
assert (author/'scripts/work-branch-migration.py').read_bytes()==git(author,'show',M+':scripts/work-branch-migration.py')
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
assert own['lease']==registered['lease'] and datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
for task in ('POC-003','POC-005'):
    assert rows(active)[task]==rows(before)[task]
checkout=read(t/'ops020-integration-pr198-source-ci966-final/checkout.json')
assert [parent['sha'] for parent in checkout['parents']]==[M,S] and checkout['tree']['sha']==TREE
assert fresh()
result=dict(source=S,base=M,tree=TREE,pullRequest=198,expectedHeadSha=S,mergeMethod='merge',
    freshGuardPassed=True,fullCiAccepted=True,botSummaryFetched=False,independentSourceReviewAccepted=True,bootstrapExceptionAccepted=False,
    sourceReviewSha256=args.review_sha256,capturedAt=g['capturedAt'],
    checkedAt=datetime.now(timezone.utc).isoformat(),actualMergePerformed=False,
    actualPocMigrationApproved=False,authorityNormalCompletionAccepted=False)
with (t/'ops020-integration-pr198-final-merge-preflight-result.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
