"""Ordinary code child after exact independent review of all net paths."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;rp=t/'ops020-integration-scope-repair-v1-code-precommit-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(rp.read_bytes());assert v['codeCandidateAccepted'] and v['localCodeCommitAllowed'] and v['fixedSource15ChecksAllowed'] and not v['mustFix']
assert v['commitMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
c=json.loads((t/'ops020-integration-scope-repair-v1-code-precommit-candidate.json').read_bytes());r=Path(c['author']);base=c['base'];purpose=c['purposeSource']
git=lambda *argv:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*argv])
assert git('rev-parse','HEAD').decode().strip()==purpose and git('show','-s','--format=%P',purpose).decode().strip()==base and git('branch','--show-current').decode().strip()==c['branch']
assert not git('diff','--cached','--name-only').strip()
assert {x['path'] for x in v['fileSnapshot']}==set(c['changedPaths'])
for pin in v['fileSnapshot']:
 data=(r/pin['path']).read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
working=set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
prior=set(git('diff','--name-only',base,purpose).decode().splitlines());assert working|prior==set(c['changedPaths'])
assert {'scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py'}<=working
for name in ['.github/workflows/governance-gate.yml','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
 assert (r/name).read_bytes()==git('show',base+':'+name)
assert not (r/'evidence/OPS-020/implementation-v1/recovery-approval.json').exists()
git('add','--',*sorted(working));assert set(git('diff','--cached','--name-only').decode().splitlines())==working
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check');git('commit','-m','fix(governance): audit registered source imports at implementation merges','-m','Refs #191. Keep per-source prior registration checks and allow only already-audited clean automatic mode/blob imports at the final actual merge. Six real-Git regressions preserve all original assertions; exact-source and full official CI acceptance remain required.')
source=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',source).decode().strip()==purpose and not git('status','--porcelain=v1','--untracked-files=all').strip()
assert git('rev-list','--reverse',base+'..'+source).decode().splitlines()==[purpose,source]
bundle=t/('ops020-integration-scope-repair-v1-'+source[:7]+'-full.bundle');assert not bundle.exists();git('bundle','create',str(bundle),'--all')
result=dict(source=source,base=base,branch=c['branch'],parents=[purpose],purposeSource=purpose,tree=git('rev-parse','HEAD^{tree}').decode().strip(),author=str(r),changedPaths=c['changedPaths'],metadataOnly=False,commands=c['commands'],bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),precommitReviewSha256=a.review_sha256,expectedFullGovernanceCases=933,expectedModuleCases=91,currentSourceChecksPassed=False,fullCiAccepted=False,actualCapacityReleased=False,actualRecoveryApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-integration-scope-repair-v1-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=source,base=base,purposeSource=purpose,paths=len(c['changedPaths']),bundleBytes=result['bundleBytes'])),flush=True)
