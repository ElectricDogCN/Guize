"""Collect exact new inventory after source15; preserve every original898 ID."""
from pathlib import Path
import ast,fcntl,hashlib,json,os,subprocess,sys
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
c=json.loads((t/'ops020-integration-scope-repair-v1-current-candidate.json').read_bytes())
g=json.loads((t/'ops020-integration-scope-repair-v1-native-source15/results.json').read_bytes())
assert g['source']==c['source'] and g['declared15Passed'] and g['before']==g['after']
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=Path(g['nativeRepo']);out=t/'ops020-integration-scope-repair-v1-collect933';out.mkdir()
argv=[sys.executable,'-B','-m','pytest','--collect-only','-q','tests/governance']
with (out/'collect.raw').open('xb') as raw:
 child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT);code=child.wait()
raw=(out/'collect.raw').read_bytes();assert code==0
cases=[line.strip() for line in raw.decode('utf-8').splitlines() if line.startswith('tests/governance/') and '::' in line]
old=t/'ops020-normal-review-v2-expected927-ci-cases.json'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='940247b3f9102fc5ea600ca656f8ec73efa5fedc60f4deddff7f30a0920f6424'
original=json.loads(old.read_bytes())['expectedCases'];assert len(original)==927
new=sorted(set(cases)-set(original))
assert len(cases)==len(set(cases))==933 and set(original)<=set(cases) and len(new)==6
assert set(new)=={'tests/governance/test_work_branch_migration.py::test_history_implementation_merge_keeps_source_scope_and_exact_automatic_import['+x+']' for x in ['separate-prior-registration','same-commit-claim','unclaimed-source','new-merge-bytes','new-merge-mode','reverted-unclaimed-source']}

result=dict(source=c['source'],base=c['base'],tree=c['tree'],expectedCases=cases,newCases=new,
 original927Sha256=hashlib.sha256(old.read_bytes()).hexdigest(),original927Preserved=True,original927Plus6Exact=True,original902Preserved=True,original902Plus25Exact=True,
 actualWaitCompleted=True,exitCode=code,pid=child.pid,argv=argv,collectRawSha256=hashlib.sha256(raw).hexdigest(),testsExecuted=False)
file=t/'ops020-integration-scope-repair-v1-expected933-ci-cases.json'
with file.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=c['source'],cases=933,newCases=6,inventoryBytes=file.stat().st_size,inventorySha256=hashlib.sha256(file.read_bytes()).hexdigest())),flush=True)
