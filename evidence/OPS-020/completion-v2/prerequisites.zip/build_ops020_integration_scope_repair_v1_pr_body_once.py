"""Describe the final bounded integration repair after exact source admission."""
from pathlib import Path
import hashlib,json
t=Path(__file__).resolve().parent
c=json.loads((t/'ops020-integration-scope-repair-v1-current-candidate.json').read_bytes());g=json.loads((t/'ops020-integration-scope-repair-v1-native-source15/results.json').read_bytes());v=json.loads((t/'ops020-integration-scope-repair-v1-publication-independent-review.json').read_bytes())
assert g['source']==c['source'] and g['declared15Passed'] and g['before']==g['after'] and len(g['commands'])==15 and all(x['actualWaitCompleted'] and x['exitCode']==0 for x in g['commands'])
assert v['publicationApproved'] and v['source']==c['source'] and not v['mustFix']
idx=json.loads((Path(c['author'])/'evidence/OPS-020/integration-scope-repair-v1/index.json').read_bytes())
body=f'''实际实现合并中的侧支已经提前登记新路径，结项历史检查却按第一父的旧范围再次拒绝该路径。此修复保留逐源提交的前置登记检查，仅在最终实际实现合并中，允许已审计侧父的精确自动合并结果导入。

## 关联

Refs #191；Task ID：OPS-020；Work Package：WP-M0-01；FOUNDATION / integrationOrder 15。
Program：`specs/coordination/program-plan.yaml#OPS-020`；Task：`specs/tasks/OPS-020.md`；Evidence：`evidence/OPS-020/integration-scope-repair-v1/`；Handoff：`evidence/OPS-020/handoff.md`。

## Agent 角色与风险

Coordinator / Implementer / Integrator：/root；独立 Reviewer：/root/independent_review。风险 high，非 critical；精确代码、证据与真实源检查已获独立审查。当前为正常 integration / integrator，最终同源官方 CI 与合并前审查仍待。

## 基线与依赖

- Base Branch：main；Task baseSha / 已接受 Review 基线：`{c['base']}`。
- Source：`{c['source']}`；Tree：`{c['tree']}`；Branch：`{c['branch']}`。
- 先提交用途 `{c['purposeSource']}`，独立审查后才在子提交写代码。既有 Code196 / Review197 的验收保持原身份。
- 本地未发布的 Completion d364 / APP bcf9 在源04真实失败，未创建PR/官方CI，全部原件保留；本 PR 不沿用其批准或声明结项。

## Program Plan 对齐与活动任务登记

- [x] 同任务合法 review→integration；requirement/module/wave/order/contracts/exitGate 保持。
- [x] Registry 原3 active / 1 high、原三claims、lease至2026-11-12T13:07:45Z、actors保持，两个POC元数据保持。
- [x] registry；组 bounded-work-branch-recovery；integrationStrategy：merge。
- [x] 不创建新任务、引导或例外；普通完成账本和原intent保持。

## 路径范围与修改摘要

独占claims沿用 `scripts/work-branch-migration.py`、`tests/governance/test_work_branch_migration.py`、`scripts/check-program-plan-history.py`。实际代码仅后两条；其余为Own元数据/Evidence。共享路径：无；范围外修改：无。

H原逐节点登记、租约、身份和生命周期校验仍完整执行，既存错误不清除。只在最终实现合并且所有源检查无误时，用原自动合并重建校验 stage0 与实际 mode/blob，侧父必须已经审计。历史claims并集不授工作权限；同次补登记、未登记及曾撤回的源改动、新merge字节或模式仍拒绝；冲突解决沿用原严格判定。

实际19路径：
'''+''.join('- `'+name+'`\n' for name in c['changedPaths'])+f'''
证据ZIP {idx['archiveBytes']}B、{len(idx['entries'])}个精确索引成员，交付诊断、全部递归小pins、已接受前提与未发布失败的原始字节，以及隔离红绿raw/JUnit/方法。用随仓verify-archive.py验证各成员，不执行归档内容；大Git恢复包及媒体原件保留本地，不冒称下载额外云JUnit。

## Requirement / Module / Contract

REQ-V1-0010 / MOD-GOV；消费 CONTRACT-PROGRAM-PLAN、CONTRACT-TASK-SPEC、CONTRACT-ACTIVE-WORK；无新增契约。
- [x] 已核批准规格和owner；不访问其他模块Repository/Schema。
- [x] 公共checked_range / checked_edge与产品接口保持。

## API / Event、数据库 / Migration、配置 / 部署影响

无产品接口、数据库、Migration或运行配置变化。该修复仅纠正治理历史验证；不执行POC分支恢复或任何媒体、百万文件实验。

## 安全影响

冻结五、其余P/H校验、workflow/pins/原runner/30分钟、两个POC tuple、旧批准和原始intent保持。当前无实际新recovery-approval.json。原85项文件完整字节前缀和全部原927断言保持，新增6个真实Git用例。

## 测试命令与真实结果

| 检查 | 退出码 | 结果 |
| --- | ---: | --- |
| 隔离未提交红绿probe | 旧版1 / 修复0 | 旧合法正例复现scope拒绝；修复6 passed/85 deselected/16.43s，仅定向证据 |
| Task既定14项源检查 | 0 | 当前精确提交逐条真实退出0，完整raw保留 |
| `python -B -m pytest -q tests/governance/test_work_branch_migration.py` | 0 | 当前精确提交全91项，零失败/错误/跳过 |
| 当前完整官方CI | 待执行 | 原927+新6=933完整通过，原28步骤/runner/30分钟保持 |

## 失败、限制与未解决项

本PR完整源CI、最终独立审查、普通合并后的实际七项与完整push933及实际主线接受仍待。之后才以最新实际Code身份另建新条件批准和正常Completion；当前容量未释放、两个POC未完成。旧失败/取消、旧结论各保留自己的源与尝试身份，无拼接、无第三次旧CI重试。无需新增人工决策。

## 回滚与恢复

所有本地引用、工作树与原件保持；已合入变更通过独立普通Revert PR与完整检查前向处理。不直接推main、不force、不删本地历史。

## 文档与治理同步

- [x] Own Program / Registry / Task / Handoff / Evidence同步；无需ADR或产品文档变更。
- [x] 前提和失败材料可取回并按原身份索引。
- [ ] 当前精确HEAD完整Required Check、最终独立审查及所有Review Thread收口。
- [ ] 普通合并后实际main7、完整push933及独立接受。
- [ ] 新条件批准与正常Completion后才释放登记，随后继续两个POC完整验证。
'''
with (t/'ops020-integration-scope-repair-v1-pr-body.md').open('x',encoding='utf-8',newline='\n') as f:f.write(body)
print('Prepared source-bound integration PR body')
