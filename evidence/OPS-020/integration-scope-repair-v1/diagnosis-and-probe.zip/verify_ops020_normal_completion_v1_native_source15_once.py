"""Run all fourteen preserved source checks plus the new real Git regressions."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,re,shlex,subprocess,sys,time
from live_github_transport import start_bridge
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
c=json.loads((t/'ops020-normal-completion-v1-current-candidate.json').read_bytes())
source,base,branch=c['source'],c['base'],c['branch']
accepted=json.loads((t/'ops020-normal-review-pr197-final-actual-main-independent-review.json').read_bytes())
assert accepted['actualMain']==base and accepted['actualReviewMainAccepted'] and accepted['fullMainCiAccepted'] and accepted['actualMainSevenAccepted'] and not accepted['mustFix']
out=t/'ops020-normal-completion-v1-native-source15';out.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
repo=Path('/home/sur/.cache/guize-takeover/ops020-normal-completion-v1-source15-'+source[:8]);assert not repo.exists()
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],GIT_LFS_SKIP_SMUDGE='1',PYTHONDONTWRITEBYTECODE='1')
subprocess.run(['git','clone','--quiet','--branch',branch,str(bundle),str(repo)],check=True)
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
assert git('rev-parse','HEAD')==source and not (repo/'.git/objects/info/alternates').exists()
git('branch','main','refs/remotes/origin/main')
assert git('rev-parse','main')==git('rev-parse','origin/main')==base
git('remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git')
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
probe='evidence/OPS-019/implementation-v1/lfs-probe.bin'
raw=(t/'ops020-blocked-recovery-implementation-v1'/probe).read_bytes()
assert len(raw)==4096 and hashlib.sha256(raw).hexdigest()==oid
cache=repo/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True);(cache/oid).write_bytes(raw)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:git('config','--local',key,value)
subprocess.run(['git','-C',str(repo),'lfs','checkout',probe],check=True,capture_output=True)
assert (repo/probe).read_bytes()==raw
os.environ.pop('GIT_LFS_SKIP_SMUDGE')
os.environ.update(GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF=branch,GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
start_bridge(out)
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),branch=git('branch','--show-current'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert not before['status']
commands=c['commands']
assert len(commands)==15 and commands[-1]==['python','-B','-m','pytest','-q','tests/governance/test_work_branch_migration.py']
assert c['metadataOnly'] and c['base']=='99714cabedd9196d0eeeb31653faaaf17211f74c'

result=dict(source=source,base=base,branch=branch,nativeRepo=str(repo),before=before,commands=[],startedAt=datetime.now(timezone.utc).isoformat(),declared15Passed=False,officialCiAccepted=False,actualRecoveryApproved=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for index,argv in enumerate(commands):
    if index==14:argv=argv+['--durations=15','--junitxml='+str(out/'junit.xml')]
    row=dict(argv=argv,raw=f'{index:02d}.raw',startedAt=datetime.now(timezone.utc).isoformat());result['commands'].append(row);save();tick=time.monotonic()
    with (out/row['raw']).open('x') as log:
        log.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n');log.flush()
        child=subprocess.Popen(argv,cwd=repo,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save()
        code=child.wait();log.write('\nExit Code: '+str(code)+'\n')
    data=(out/row['raw']).read_bytes();row.update(exitCode=code,actualWaitCompleted=True,elapsedSeconds=time.monotonic()-tick,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());save()
    print(f'{index:02d}: exit {code}',flush=True)
    if code:raise SystemExit(code)
assert state()==before
result.update(after=state(),finishedAt=datetime.now(timezone.utc).isoformat(),declared15Passed=True,sourceContextUnchanged=True);save()
print(json.dumps(dict(source=source,declared15Passed=True,officialCiAccepted=False)),flush=True)
