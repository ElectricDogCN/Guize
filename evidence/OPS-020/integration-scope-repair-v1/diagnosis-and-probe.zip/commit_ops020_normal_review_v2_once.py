"""Ordinary metadata-only Review commit after independent precommit acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,re,shlex
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;r=t/'ops020-normal-review-v2'
review=t/'ops020-normal-review-v2-precommit-independent-review.json'
assert hashlib.sha256(review.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(review.read_bytes());assert v['metadataCandidateAccepted'] and v['localMetadataCommitAllowed'] and v['fixedSource15ChecksAllowed'] and not v['mustFix']
c=json.loads((t/'ops020-normal-review-v2-precommit.json').read_bytes());base=c['base'];branch=c['branch']
def git(*argv):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*argv])
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()==branch
assert not git('diff','--cached','--name-only').strip()
paths=c['changedPaths'];assert len(paths)==14 and set(paths)==set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
assert {x['path'] for x in v['fileSnapshot']}==set(paths)
for pin in v['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
assert (r/'specs/tasks/POC-003.md').read_bytes()==git('show',base+':'+'specs/tasks/POC-003.md')
assert (r/'specs/tasks/POC-005.md').read_bytes()==git('show',base+':'+'specs/tasks/POC-005.md')
assert (r/'specs/coordination/task-completions.yaml').read_bytes()==git('show',base+':'+'specs/coordination/task-completions.yaml')
assert (r/'.github/workflows/governance-gate.yml').read_bytes()==git('show',base+':'+'.github/workflows/governance-gate.yml')
assert (r/'scripts/check-program-plan-history.py').read_bytes()==git('show',base+':'+'scripts/check-program-plan-history.py')
assert not (r/'evidence/OPS-020/implementation-v1/recovery-approval.json').exists()
for name in c['claims']+['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md']:
 assert (r/name).read_bytes()==git('show',base+':'+name)
git('add','--',*paths);assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check')
git('commit','-m','review(OPS-020): record normal independent Review','-m','Refs #191. Metadata only after accepted implementation main '+base+'. Evidence: evidence/OPS-020/review-v2/')
source=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',source).decode().strip()==base
assert not git('status','--porcelain=v1','--untracked-files=all').strip()
bundle=t/('ops020-normal-review-v2-'+source[:7]+'-full.bundle');assert not bundle.exists()
git('bundle','create',str(bundle),'--all')
fence=chr(96)*3;sections=re.findall(fence+r'bash\n(.*?)\n'+fence,(r/'specs/tasks/OPS-020.md').read_text(encoding='utf-8'),re.S)
assert len(sections)==1
commands=[shlex.split(x) for x in sections[0].splitlines() if x.strip()];assert len(commands)==15
result=dict(source=source,base=base,branch=branch,tree=git('rev-parse','HEAD^{tree}').decode().strip(),author=str(r),changedPaths=paths,metadataOnly=True,fileSnapshot=[dict(path=x,bytes=(r/x).stat().st_size,sha256=hashlib.sha256((r/x).read_bytes()).hexdigest()) for x in paths],conditionalApprovalCreated=False,commands=commands,bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),precommitReviewSha256=a.review_sha256,currentSourceChecksPassed=False,fullCiAccepted=False,expectedFullGovernanceCases=927,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-normal-review-v2-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
