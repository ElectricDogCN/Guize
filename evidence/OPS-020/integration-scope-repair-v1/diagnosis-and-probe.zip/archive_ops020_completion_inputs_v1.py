"""Collect exact small prerequisite records without executing archive payloads."""
from pathlib import Path,PurePosixPath
import hashlib,json

def collect(t,names):
 files={};pending=[]
 def add(name,pin=None):
  name=name.removeprefix('.takeover-tools/');rel=PurePosixPath(name);file=t/name
  assert not rel.is_absolute() and not Path(name).is_absolute() and '..' not in rel.parts
  assert file.is_file() and not file.is_symlink() and file.resolve().is_relative_to(t.resolve()),name
  assert file.suffix in {'.json','.raw','.txt','.xml','.py','.md','.yaml','.yml','.zip','.pstats','.bin'},name
  data=file.read_bytes();assert len(data)<8*1024*1024,name
  if pin:assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],name
  if name in files:assert files[name]==data;return
  files[name]=data
  if file.suffix=='.json':pending.append(json.loads(data))
 def walk(doc):
  if isinstance(doc,dict):
   for key,value in doc.items():
    if key=='evidencePins':
     for pin in value:add(pin.get('path',pin.get('ref')),pin)
    else:walk(value)
  elif isinstance(doc,list):
   for value in doc:walk(value)
 for name in names:add(name)
 while pending:walk(pending.pop())
 assert len(files)<500 and sum(map(len,files.values()))<23*1024*1024
 return files
