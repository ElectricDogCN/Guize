"""Render Review PR description only after exact local checks/publication approval."""
from pathlib import Path
import hashlib,json
t=Path(__file__).resolve().parent
c=json.loads((t/'ops020-normal-review-v2-current-candidate.json').read_bytes())
g=json.loads((t/'ops020-normal-review-v2-native-source15/results.json').read_bytes())
v=json.loads((t/'ops020-normal-review-v2-publication-independent-review.json').read_bytes())
a=json.loads((t/'ops020-history-io-pr196-final-actual-main-independent-review.json').read_bytes())
assert a['actualMain']==c['base'] and a['actualImplementationMainAccepted'] and a['fullMainCiAccepted'] and a['actualMainSevenAccepted'] and not a['mustFix']
assert g['source']==c['source'] and g['base']==c['base'] and g['declared15Passed'] and g['before']==g['after']
assert len(g['commands'])==15 and all(r['actualWaitCompleted'] and r['exitCode']==0 for r in g['commands'])
assert v['source']==c['source'] and v['publicationApproved'] and not v['mustFix']
assert c['metadataOnly'] and len(c['changedPaths'])==14 and not c['conditionalApprovalCreated']
r=Path(c['author']);idx=json.loads((r/'evidence/OPS-020/review-v2/accepted-code-main-evidence-index.json').read_bytes())
archive=r/'evidence/OPS-020/review-v2'/idx['archive']
assert archive.stat().st_size==idx['archiveBytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==idx['archiveSha256']
body=f'''OPS-020 的受限恢复工具代码已在实际主线 `{c['base']}` 完成源/主线完整官方 CI 和独立验收。本 PR 将本任务推进正常独立 Review，并交付可取回的验收材料。

## 关联

- Refs #191；Task ID：OPS-020；Work Package：WP-M0-01。
- Program：`specs/coordination/program-plan.yaml#OPS-020`；FOUNDATION / integrationOrder 15。
- Task：`specs/tasks/OPS-020.md`；Evidence：`evidence/OPS-020/review-v2/`；Handoff：`evidence/OPS-020/handoff.md`。

## Agent 角色与风险

Coordinator / Implementer / Integrator：/root；独立 Reviewer：/root/independent_review。风险 high，非 critical。精确候选和真实源检查已获独立审查，mustFix=[]；最终同源官方 CI 与合并前审查仍待。

## 基线与依赖

- Base Branch：main；Task baseSha / 当前基线：`{c['base']}`。
- Source：`{c['source']}`；Tree：`{c['tree']}`；Branch：`{c['branch']}`。
- 已从接受的实际代码主线创建。OPS-019 正常完成；OPS-020 Code PR196 的源962/实际main963、原生源15/实际main7均已独立接受，历史取消尝试保留各自身份。
- 无新增外部环境或生产契约依赖。

## Program Plan 对齐与活动任务登记

- [x] Task / requirement / module / wave / order / scope / contracts / exitGate 沿用原登记。
- [x] 本任务独立 review / reviewer 状态同步至 Program、Registry 与 Task；原租约至2026-11-12T13:07:45Z、actors、三条代码 claims 和3 active / 1 high 容量保持。
- registry；组 bounded-work-branch-recovery；integrationStrategy：merge；本 PR 为正常 Review。
- [x] 未创建第二份未来任务计划，原完成账本保持。

## 路径范围与修改摘要

独占 claims 沿用 `scripts/work-branch-migration.py`、`tests/governance/test_work_branch_migration.py`、`scripts/check-program-plan-history.py`；本阶段只修改 Own 正常生命周期元数据与 Evidence。共享路径：无。范围外修改：无。

实际14路径：
'''+''.join('- `'+name+'`\n' for name in c['changedPaths'])+f'''
验收档案包含 {len(idx['entries'])} 份完整小记录，ZIP {idx['archiveBytes']}B，逐项索引与无需解包执行的验证脚本随仓交付。原生 raw/JUnit、完整官方HTTP日志/元数据及递归证据 pins 均绑定原始字节。大恢复包和媒体原件保留本地；未声称下载单独的云端 JUnit。

## Requirement / Module / Contract

REQ-V1-0010 / MOD-GOV；消费 CONTRACT-PROGRAM-PLAN、CONTRACT-TASK-SPEC、CONTRACT-ACTIVE-WORK；无新增契约。
- [x] 已核对批准规格及现有 owner；未访问其他模块 Repository/Schema。
- [x] 公共 checked_range / checked_edge 及当前代码保持；未将工具验收写作 POC 验收。

## API / Event、数据库 / Migration、配置 / 部署影响

无产品接口、数据库或运行配置变更。仅 Own Review 元数据与可取回的验收 Evidence。

## 安全影响

冻结五、P/H、workflow/pins/runner/30分钟、两 POC tuple、旧批准和原始 intent 保持。本 PR 没有创建实际 recovery-approval.json，未恢复 POC 分支或启动实验。

## 测试命令与真实结果

| 检查 | 退出码 | 结果 |
| --- | ---: | --- |
| Task Spec 原14项检查 | 0 | 精确提交逐条真实退出0，原始输出保留 |
| `python -B -m pytest -q tests/governance/test_work_branch_migration.py` | 0 | 同一精确提交完整85项，零失败/错误/跳过 |
| 本 PR 完整官方 CI | 待执行 | 须精确927=原902+25、28步骤及原30分钟完整通过 |

## 失败、限制与未解决项

当前 Review 的完整源/实际主线 CI 与最终接受仍待；正常 Completion、新前置独立批准及容量释放后，才可另行恢复 POC-003。两个 POC 的新源码完整验证均未完成。旧 CI958、旧A的CI960两轮、旧N的CI961取消及历史失败永久保留原来源，未改标。无需新增人工决策。

## 回滚与恢复

未合入时保留候选、全部本地引用和原件；合入后通过独立普通 Revert PR 与完整检查前向处理。不得直接推 main、force 或删除本地历史。

## 文档与治理同步

- [x] Own Program / Task / Registry / Handoff / Evidence 同步；无需 ADR 或产品文档变更。
- [x] 可取回的验收档案与逐项索引交付，外部设置仅按实际状态记录。
- [ ] 当前精确 HEAD 的完整 Required Check、独立最终审查及所有 Review Thread 收口。
- [ ] 普通合并后实际 main7、完整 push CI 及最终独立接受。
- [ ] 后续正常 Completion 才释放本任务活动登记。
'''
file=t/'ops020-normal-review-v2-pr-body.md'
with file.open('x',encoding='utf-8',newline='\n') as stream:stream.write(body)
print(json.dumps(dict(file=file.name,source=c['source'],base=c['base'],bytes=file.stat().st_size)),flush=True)
