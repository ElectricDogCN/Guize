"""Fresh ordinary PR196 code-merge preflight. Does not merge or migrate."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
import yaml
t=Path(__file__).resolve().parent
S='a2e933ced1abb7fff7694569049881c9e7ca3661'
M='f71f85027e8ad64b8e6d0a3d08a39ca9596d0323'
TREE='5cf15c271e233b8cab3455285479f8104ead71bc'
BRANCH='chore/OPS-020-history-data-performance'
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);args=p.parse_args()
read=lambda file:json.loads(Path(file).read_bytes())
sha=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
review_file=t/'ops020-history-io-pr196-source-final-independent-review.json'
assert sha(review_file)==args.review_sha256
r=read(review_file)
assert (r['source'],r['base'],r['tree'])==(S,M,TREE)
assert r['finalSourceAccepted'] and r['fullCiAccepted'] and r['actualMergeApproved'] and not r['mustFix']
assert not r.get('bootstrapExceptionAccepted',False)
ci=r['ci']
assert ci['run']==42108206484 and ci['job']==127528556925 and ci['uniquePassed']==927
assert ci['original902Plus25Exact'] and ci['failedErroredSkippedXfailXpass']==0
for pin in r['evidencePins']:
    file=t/pin['path']
    assert file.stat().st_size==pin['bytes'] and sha(file)==pin['sha256']
g=read(t/'ops020-history-io-pr196-fresh-final-merge-guard.json')
captured=datetime.fromisoformat(g['capturedAt'].replace('Z','+00:00'))
fresh=lambda:0<=(datetime.now(timezone.utc)-captured).total_seconds()<120
assert fresh() and g['main']['object']['sha']==M
pr=g['pr']
assert pr['number']==196 and pr['state']=='open' and not pr['merged'] and not pr['draft']
assert pr['mergeable'] is True and pr['mergeable_state']=='clean'
assert pr['head']['sha']==S and pr['head']['ref']==BRANCH
assert pr['base']['sha']==M and pr['base']['ref']=='main' and pr['changed_files']==26
assert g['issue']['number']==191 and g['issue']['state']=='open'
run=g['run']
assert run['id']==42108206484 and run['run_attempt']==1 and run['head_sha']==S
assert run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
assert g['jobs']['total_count']==len(g['jobs']['jobs'])==1
job=g['jobs']['jobs'][0]
assert job['id']==127528556925 and job['run_id']==run['id'] and job['run_attempt']==1
assert job['status']=='completed' and job['conclusion']=='success' and len(job['steps'])==28
assert all(step['status']=='completed' and step['conclusion']=='success' for step in job['steps'])
latest=g['latest']['workflow_runs']
assert latest and latest[0]['id']==run['id'] and latest[0]['run_attempt']==1 and latest[0]['conclusion']=='success'
assert not any(not thread['is_resolved'] for thread in g['threads'])
reviews={}
for review in g['reviews']:
    reviews[review['user']['login']]=review
assert not any(review['state']=='CHANGES_REQUESTED' for review in reviews.values())
bot=g['botSummary']['code_review']
assert bot['commit_sha']==S and bot['status']=='completed'
assert bot['has_any_findings'] is False and bot['has_unresolved_findings'] is False
candidate=read(t/'ops020-history-io-v2-current-candidate.json')
assert candidate['source']==S and candidate['base']==M and candidate['tree']==TREE
author=Path(candidate['author']);canonical=t.parent/'Guize'
def git(root,*argv):
    return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*argv])
def dec(root,*argv):
    return git(root,*argv).decode().strip()
for root,head,branch in [(author,S,BRANCH),(canonical,M,'main')]:
    assert dec(root,'rev-parse','HEAD')==head and dec(root,'branch','--show-current')==branch
    assert not dec(root,'status','--porcelain=v1','--untracked-files=all')
assert dec(author,'merge-base',M,S)==M and dec(author,'rev-parse','HEAD^{tree}')==TREE
assert dec(author,'diff','--name-only',M,S).splitlines()==candidate['changedPaths']
assert set(['scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py'])<=set(candidate['changedPaths'])
for pin in candidate['fileSnapshot']:
    assert (author/pin['path']).stat().st_size==pin['bytes'] and sha(author/pin['path'])==pin['sha256']
assert dec(author,'ls-remote','--heads','origin','refs/heads/main').split()==[M,'refs/heads/main']
assert dec(author,'ls-remote','--heads','origin','refs/heads/'+BRANCH).split()==[S,'refs/heads/'+BRANCH]
for path in ['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py',
             'specs/poc/test_program.py','docs/18-testing-and-acceptance.md']:
    assert (author/path).read_bytes()==git(author,'show',M+':'+path)
before=yaml.safe_load(git(author,'show',M+':specs/coordination/active-work.yaml'))
active=yaml.safe_load((author/'specs/coordination/active-work.yaml').read_bytes())
rows=lambda d:{row['taskId']:row for row in d['tasks']}
own,registered=rows(active)['OPS-020'],rows(before)['OPS-020']
assert len(active['tasks'])==3 and sum(row['riskLevel'] in {'high','critical'} for row in active['tasks'])==1
assert own['status']=='in_progress' and own['agentRole']=='implementer' and own['baseSha']==M and own['branch']==BRANCH
assert registered['exclusivePaths']==['scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py']
assert own['exclusivePaths']==registered['exclusivePaths']+['scripts/check-program-plan-history.py'] and own['sharedPaths']==[]
scope=candidate['scopeCommit']
purpose=candidate['purposeCommit']
assert dec(author,'rev-list','--reverse',M+'..'+S).splitlines()==[scope,'f1cfbef4e63bb4a85548a74e57510d156f262721',purpose,S]
assert purpose=='a9685b4f39f8e50701e38fb13b06d51b5c390e0a'
assert dec(author,'show','-s','--format=%P',scope)==M
assert git(author,'show',purpose+':scripts/check-program-plan-history.py')==git(author,'show','f1cfbef4e63bb4a85548a74e57510d156f262721:scripts/check-program-plan-history.py')
assert all(path=='specs/tasks/OPS-020.md' or path.startswith('evidence/OPS-020/') for path in dec(author,'diff','--name-only','f1cfbef4e63bb4a85548a74e57510d156f262721',purpose).splitlines())
scope_active=yaml.safe_load(git(author,'show',scope+':specs/coordination/active-work.yaml'))
assert rows(scope_active)['OPS-020']==own
assert git(author,'show',scope+':scripts/check-program-plan-history.py')==git(author,'show',M+':scripts/check-program-plan-history.py')
assert all(path in {'specs/coordination/active-work.yaml','specs/tasks/OPS-020.md'} or path.startswith('evidence/OPS-020/') for path in dec(author,'diff','--name-only',M,scope).splitlines())
assert {key:value for key,value in own.items() if key not in {'branch','baseSha','exclusivePaths'}}=={key:value for key,value in registered.items() if key not in {'branch','baseSha','exclusivePaths'}}
assert (author/'scripts/work-branch-migration.py').read_bytes()==git(author,'show',M+':scripts/work-branch-migration.py')
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
assert own['lease']==registered['lease'] and datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
for task in ('POC-003','POC-005'):
    assert rows(active)[task]==rows(before)[task]
checkout=read(t/'ops020-history-io-pr196-source-ci962-final/checkout.json')
assert [parent['sha'] for parent in checkout['parents']]==[M,S] and checkout['tree']['sha']==TREE
assert fresh()
result=dict(source=S,base=M,tree=TREE,pullRequest=196,expectedHeadSha=S,mergeMethod='merge',
    freshGuardPassed=True,fullCiAccepted=True,bootstrapExceptionAccepted=False,
    sourceReviewSha256=args.review_sha256,capturedAt=g['capturedAt'],
    checkedAt=datetime.now(timezone.utc).isoformat(),actualMergePerformed=False,
    actualPocMigrationApproved=False,authorityNormalCompletionAccepted=False)
with (t/'ops020-history-io-pr196-final-merge-preflight-result.json').open('x',encoding='utf-8') as f:
    f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
