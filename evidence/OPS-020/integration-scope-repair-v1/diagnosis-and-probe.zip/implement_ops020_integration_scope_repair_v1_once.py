"""Apply the prospectively registered H/test repair after purpose acceptance."""
from pathlib import Path
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--purpose-review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;rp=t/'ops020-integration-scope-repair-v1-purpose-precommit-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.purpose_review_sha256
review=json.loads(rp.read_bytes());assert review['registeredCodeWorkAllowed'] and review['purposeCommitAllowed'] and not review['mustFix']
c=json.loads((t/'ops020-integration-scope-repair-v1-purpose-commit.json').read_bytes());r=Path(c['author'])
git=lambda *argv:subprocess.check_output(['git','-C',str(r),*argv])
assert c['purposeReviewSha256']==a.purpose_review_sha256 and git('rev-parse','HEAD').decode().strip()==c['purposeSource'] and not git('status','--porcelain=v1','--untracked-files=all').strip()
h=r/'scripts/check-program-plan-history.py';test=r/'tests/governance/test_work_branch_migration.py'
before=h.read_text(encoding='utf-8');old_test=test.read_bytes()
assert old_test==git('show',c['base']+':tests/governance/test_work_branch_migration.py')
start=before.index('def foundation_implementation(');end=before.index('\ndef foundation_review_targets(',start);body=before[start:end]
old='    for node in [*early_nodes, *nodes.stdout.split()]:\n'
assert body.count(old)==1
body=body.replace(old,'    audited_nodes: set[str] = set()\n'+old+'        node_error_start = len(errors)\n')
old='        if not working:\n            continue\n'
assert body.count(old)==1
body=body.replace(old,'        if not working:\n            if len(errors) == node_error_start:\n                audited_nodes.add(node)\n            continue\n')
old='''            elif any(not any(RECOVERY.matches_path(path, str(claim)) for claim in node_claims) for path in node_implementation):
                errors.append(f"Foundation {task_id} working node changed paths outside its prior registered scope")
'''
new='''            else:
                unexpected = {path for path in node_implementation if not any(RECOVERY.matches_path(path, str(claim)) for claim in node_claims)}
                if unexpected and node == commit and not errors:
                    # Source nodes still prove each contemporaneous prior
                    # registration above. Only the final implementation merge
                    # may import their already-audited automatic stage-0 result.
                    # Historical claim unions never authorize source work;
                    # conflicts and new merge bytes/modes remain task work.
                    audited_incoming = [side for side in parents[1:] if side in audited_nodes]
                    unexpected -= clean_synchronization_paths(root, node, unexpected, audited_incoming)
                if unexpected:
                    errors.append(f"Foundation {task_id} working node changed paths outside its prior registered scope")
'''
assert body.count(old)==1;body=body.replace(old,new)
old='''        if node_entry.get("agentRole") not in {"implementer", "integrator"}:
            errors.append(f"Foundation {task_id} working node requires implementer or integrator role")
'''
assert body.count(old)==1;body=body.replace(old,old+'        if len(errors) == node_error_start:\n            audited_nodes.add(node)\n')
h.write_text(before[:start]+body+before[end:],encoding='utf-8',newline='\n')
extra='''


@pytest.mark.parametrize('scenario', [
    'separate-prior-registration', 'same-commit-claim', 'unclaimed-source',
    'new-merge-bytes', 'new-merge-mode', 'reverted-unclaimed-source',
])
def test_history_implementation_merge_keeps_source_scope_and_exact_automatic_import(tmp_path, scenario):
    # Reuse the real canonical Foundation fixture, without collecting or
    # replacing its original assertions. All ref changes are in this fixture.
    spec = importlib.util.spec_from_file_location('bounded_merge_history_fixture',
        ROOT/'tests/governance/test_program_plan_history.py')
    fixture_module = importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture_module)
    fixture = fixture_module.TestProgramPlanHistory()
    repo = tmp_path/'history';repo.mkdir()
    original = fixture.commit;points = {}
    def git(*argv, check=True):
        result = subprocess.run(['git', '-C', str(repo), *argv], capture_output=True, text=True)
        if check:
            assert result.returncode == 0, result.stdout+result.stderr
        return result
    def commit(root, message, timestamp=None):
        if message == 'GZ-014 repair (#22)' and scenario == 'reverted-unclaimed-source':
            fixture.write_text(root, 'backend/unclaimed.py', '# transient unclaimed work\\n')
            original(root, 'GZ-014 unclaimed source before restoring tip (#22)', timestamp)
            (repo/'backend/unclaimed.py').unlink()
        source = original(root, message, timestamp)
        if message == 'GZ-014 activation (#21)':
            points['activation'] = source
        if message == 'GZ-014 repair (#22)':
            points['source'] = source
            git('checkout', '--detach', points['activation'])
            git('merge', '--no-ff', '--no-commit', source)
            if scenario == 'new-merge-bytes':
                fixture.write_text(root, 'scripts/new-repair.py', '# merge introduced different bytes\\n')
            if scenario == 'new-merge-mode':
                git('config', 'core.filemode', 'false')
                git('update-index', '--chmod=+x', 'scripts/new-repair.py')
            merged = original(root, 'GZ-014 actual implementation merge (#22)', timestamp)
            git('checkout', '-B', 'main', merged)
            points['merge'] = merged
            return merged
        return source
    fixture.commit = commit
    mode = {'same-commit-claim': 'same_commit_scope_expansion',
            'unclaimed-source': 'implementation_unclaimed_path'}.get(scenario, 'separate_scope_amendment')
    sources = fixture.create_foundation_completion(str(repo), mode)
    assert sources['implementation'] == points['merge']
    assert git('show', '-s', '--format=%P', points['merge']).stdout.split() == [points['activation'], points['source']]
    before = (git('for-each-ref', '--format=%(refname) %(objectname)').stdout, git('status', '--porcelain=v1').stdout)
    actual = fixture._run_checker(str(repo), 'GZ-014', 'chore/GZ-014-completion')
    assert before == (git('for-each-ref', '--format=%(refname) %(objectname)').stdout, git('status', '--porcelain=v1').stdout)
    if scenario == 'separate-prior-registration':
        assert actual.returncode == 0, actual.stdout+actual.stderr
        assert json.loads(actual.stdout)['status'] == 'PASS'
    else:
        assert actual.returncode == 1, actual.stdout+actual.stderr
        assert 'working node changed paths outside its prior registered scope' in actual.stdout
'''
with test.open('ab') as f:f.write(extra.encode('utf-8'))
assert test.read_bytes().startswith(old_test)
assert set(git('diff','--name-only').decode().splitlines())=={'scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py'}
git('diff','--check')
result=dict(purposeSource=c['purposeSource'],base=c['base'],author=str(r),branch=c['branch'],codeCommitted=False,productionChecksPassed=False,original85PrefixBytes=len(old_test),original85PrefixSha256=hashlib.sha256(old_test).hexdigest(),newCases=6,expectedFullGovernanceCases=933,paths=[dict(path=name,bytes=(r/name).stat().st_size,sha256=hashlib.sha256((r/name).read_bytes()).hexdigest()) for name in ['scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py']])
with (t/'ops020-integration-scope-repair-v1-implementation-uncommitted.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(purposeSource=c['purposeSource'],uncommittedCodePaths=2,newCases=6,fullChecksPending=True)),flush=True)
