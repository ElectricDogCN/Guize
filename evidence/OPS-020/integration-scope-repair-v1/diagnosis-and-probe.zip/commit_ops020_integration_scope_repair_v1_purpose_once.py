"""Ordinary metadata purpose commit before any new H/test implementation."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;rp=t/'ops020-integration-scope-repair-v1-purpose-precommit-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(rp.read_bytes());assert v['metadataPurposeAccepted'] and v['purposeCommitAllowed'] and v['registeredCodeWorkAllowed'] and not v['mustFix']
assert v['commitMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
c=json.loads((t/'ops020-integration-scope-repair-v1-purpose-precommit-candidate.json').read_bytes());r=Path(c['author']);base=c['base']
git=lambda *argv:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*argv])
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()==c['branch'] and not git('diff','--cached','--name-only').strip()
assert {p['path'] for p in v['fileSnapshot']}==set(c['changedPaths'])
for pin in v['fileSnapshot']:
 data=(r/pin['path']).read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
working=set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines());assert working==set(c['changedPaths'])
for path in ['scripts/check-program-plan-history.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
 assert (r/path).read_bytes()==git('show',base+':'+path)
assert not (r/'evidence/OPS-020/implementation-v1/recovery-approval.json').exists()
git('add','--',*sorted(working));assert set(git('diff','--cached','--name-only').decode().splitlines())==working
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check');git('commit','-m','chore(OPS-020): register bounded integration history repair purpose','-m','Refs #191. Normal review-to-integration metadata only. Code and tests remain unchanged; independent purpose review precedes implementation in the existing three claims. Failed local Completion d364/APP bcf9 remain unpublished historical evidence.')
source=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',source).decode().strip()==base and not git('status','--porcelain=v1','--untracked-files=all').strip()
result=dict(purposeSource=source,base=base,branch=c['branch'],author=str(r),tree=git('rev-parse','HEAD^{tree}').decode().strip(),metadataOnly=True,codeWritten=False,purposeCommitted=True,purposeReviewSha256=a.review_sha256,changedPaths=sorted(working),actualCapacityReleased=False,actualRecoveryApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-integration-scope-repair-v1-purpose-commit.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=source,base=base,metadataPaths=len(working),codeWritten=False)),flush=True)
