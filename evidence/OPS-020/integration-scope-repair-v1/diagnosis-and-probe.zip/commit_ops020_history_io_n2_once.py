"""Normal child implementation N, after independent exact code review."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,shlex,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent
receipt=t/'ops020-history-io-v2-n2-precommit-independent-review.json'
assert hashlib.sha256(receipt.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(receipt.read_bytes())
assert v['implementationCandidateAccepted'] and v['normalCodeCommitN2Allowed'] and v['source15ChecksAllowed'] and not v['mustFix']
c=json.loads((t/'ops020-history-io-v2-n2-precommit.json').read_bytes());r=Path(c['author'])
m=json.loads((t/'ops020-history-io-v2-purpose-m2-commit.json').read_bytes())
assert m['source']==c['parent'] and m['parent']=='f1cfbef4e63bb4a85548a74e57510d156f262721' and m['normalPurposeM2Committed']
def git(*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*args])
dec=lambda *args:git(*args).decode().strip()
assert dec('rev-parse','HEAD')==c['parent'] and dec('show','-s','--format=%P',c['parent'])==m['parent']
assert dec('branch','--show-current')==c['branch'] and not dec('diff','--cached','--name-only')
paths=c['changedPaths'];assert len(paths)==11 and set(paths)==set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines())
assert {pin['path'] for pin in v['fileSnapshot']}==set(paths)
for pin in v['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
for name in ['scripts/work-branch-migration.py','scripts/check-program-plan-transitions.py','specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml','specs/tasks/OPS-020.md','specs/coordination/task-completions.yaml','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','.github/workflows/governance-gate.yml','evidence/OPS-020/recovery-intent.json']:
 assert (r/name).read_bytes()==git('show',c['parent']+':'+name),name
old=git('show',c['parent']+':tests/governance/test_work_branch_migration.py')
assert (r/'tests/governance/test_work_branch_migration.py').read_bytes().startswith(old)
git('add','--',*paths)
assert set(dec('diff','--cached','--name-only').splitlines())==set(paths)
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check')
git('commit','-m','perf(OPS-020): reuse scoped fresh Git blob transport','-m','Refs #191. Preceding normal M2 records purpose before this write. Preserve fresh Git values and validation body, replacement semantics, original fallback and owned child cleanup. Fourteen targeted Python3.11 tests passed; full source15/916 and actual main CI remain required.')
source=dec('rev-parse','HEAD');assert dec('show','-s','--format=%P',source)==c['parent']
assert dec('rev-list','--reverse',c['base']+'..'+source).splitlines()==['b14aa06c53f39c3e2a188a526ec2b63b3d1000df',m['parent'],c['parent'],source]
assert not dec('status','--porcelain=v1','--untracked-files=all')
net=dec('diff','--name-only',c['base'],source).splitlines();assert len(net)==23
fence=chr(96)*3;blocks=re.findall(fence+r'bash\n(.*?)\n'+fence,(r/'specs/tasks/OPS-020.md').read_text(encoding='utf-8'),re.S)
assert len(blocks)==1
commands=[shlex.split(line) for line in blocks[0].splitlines() if line.strip()];assert len(commands)==15
bundle=t/('ops020-history-io-v2-'+source[:7]+'-full.bundle');assert not bundle.exists()
git('bundle','create',str(bundle),'--all')
result=dict(taskId='OPS-020',issue=191,source=source,parent=c['parent'],scopeCommit='b14aa06c53f39c3e2a188a526ec2b63b3d1000df',purposeCommit=c['parent'],base=c['base'],branch=c['branch'],
 tree=dec('rev-parse','HEAD^{tree}'),author=str(r),changedPaths=net,implementationPaths=paths,claims=m['claims'],commands=commands,
 fileSnapshot=[dict(path=name,bytes=(r/name).stat().st_size,sha256=hashlib.sha256((r/name).read_bytes()).hexdigest()) for name in net],
 bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),
 expectedFullGovernanceCases=916,expectedModuleCases=74,precommitReviewSha256=a.review_sha256,
 targetedTransportFourteenPassedOnly=True,fullSource15Passed=False,fullCiAccepted=False,published=False,actualMainAccepted=False,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-history-io-v2-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=source,parent=c['parent'],base=c['base'],tree=result['tree'],netPaths=len(net),bundleBytes=result['bundleBytes'],fullCiAccepted=False)),flush=True)
