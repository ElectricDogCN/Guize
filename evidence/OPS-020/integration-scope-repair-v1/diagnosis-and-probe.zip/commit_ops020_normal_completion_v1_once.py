"""Ordinary second Completion commit; preserves the approved preceding creator."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--review-sha256',required=True);a=p.parse_args()
t=Path(__file__).resolve().parent;r=t/'ops020-normal-completion-v1'
rp=t/'ops020-normal-completion-v1-precommit-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==a.review_sha256
v=json.loads(rp.read_bytes());assert v['metadataCandidateAccepted'] and v['localMetadataCommitAllowed'] and v['fixedSource15ChecksAllowed'] and not v['mustFix']
c=json.loads((t/'ops020-normal-completion-v1-precommit-candidate.json').read_bytes());base,branch,creator=c['base'],c['branch'],c['approvalCreator']
APP='evidence/OPS-020/implementation-v1/recovery-approval.json'
git=lambda *argv:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*argv])
assert git('rev-parse','HEAD').decode().strip()==creator and git('branch','--show-current').decode().strip()==branch
assert git('show','-s','--format=%P',creator).decode().strip()==base and not git('diff','--cached','--name-only').strip()
paths=set(c['changedPaths']);assert len(paths)==14 and APP in paths and {x['path'] for x in v['fileSnapshot']}==paths
for pin in v['fileSnapshot']:
 raw=(r/pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
assert git('show',creator+':'+APP)==(r/APP).read_bytes() and hashlib.sha256((r/APP).read_bytes()).hexdigest()==c['approvalRecordSha256']
working=set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
assert working==paths-{APP}
for name in ['.github/workflows/governance-gate.yml','scripts/check-program-plan-history.py','scripts/check-program-plan-transitions.py','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md','specs/coordination/task-completions.yaml']:
 assert (r/name).read_bytes()==git('show',base+':'+name)
git('add','--',*sorted(working));assert set(git('diff','--cached','--name-only').decode().splitlines())==working
for pin in v['fileSnapshot']:assert git('show',':'+pin['path'])==(r/pin['path']).read_bytes()
git('diff','--cached','--check');git('commit','-m','chore(OPS-020): complete bounded blocked recovery governance','-m','Refs #191. Code identity PR196/main '+c['codeMain']+'. Normal Completion metadata follows the independent conditional-approval creator; actual main/full official CI acceptance is still required before migration.')
source=git('rev-parse','HEAD').decode().strip();assert git('show','-s','--format=%P',source).decode().strip()==creator
assert git('rev-list','--reverse',base+'..'+source).decode().splitlines()==[creator,source]
assert not git('status','--porcelain=v1','--untracked-files=all').strip()
bundle=t/('ops020-normal-completion-v1-'+source[:7]+'-full.bundle');assert not bundle.exists()
git('bundle','create',str(bundle),'--all')
result=dict(source=source,base=base,branch=branch,parents=[creator],approvalCreator=creator,tree=git('rev-parse','HEAD^{tree}').decode().strip(),author=str(r),changedPaths=sorted(paths),metadataOnly=True,conditionalApprovalRecordSha256=c['approvalRecordSha256'],commands=c['actualCompletionCommands'],bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),precommitReviewSha256=a.review_sha256,currentSourceChecksPassed=False,fullCiAccepted=False,actualCapacityReleased=False,actualMigrationApproved=False,expectedFullGovernanceCases=927,createdAt=datetime.now(timezone.utc).isoformat())
with (t/'ops020-normal-completion-v1-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=source,base=base,parent=creator,tree=result['tree'],metadataPaths=len(paths),bundleBytes=result['bundleBytes'],fullCiAccepted=False)),flush=True)
