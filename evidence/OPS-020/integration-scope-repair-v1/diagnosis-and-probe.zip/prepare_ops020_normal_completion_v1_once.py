"""Gated future APP-only creator then Own Completion candidate; no publication."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,json,os,re,shlex,subprocess,zipfile
import yaml
from archive_ops020_completion_inputs_v1 import collect
p=argparse.ArgumentParser()
for key in ('review-main-receipt-sha256','issue-closure-sha256','approval-review-sha256'):p.add_argument('--'+key,required=True)
a=p.parse_args();t=Path(__file__).resolve().parent;canonical=t.parent/'Guize';r=t/'ops020-normal-completion-v1'
Code='da4d4a4e4fa14edd1603961880b24b12eede776d';Review='99714cabedd9196d0eeeb31653faaaf17211f74c';ReviewSource='a8a348203300bfa12b72328877b9a0e563e09d28'
B='chore/OPS-020-normal-completion';APP='evidence/OPS-020/implementation-v1/recovery-approval.json'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();read=lambda path:json.loads(Path(path).read_bytes())
receipt=t/'ops020-normal-review-pr197-final-actual-main-independent-review.json';assert sha(receipt)==a.review_main_receipt_sha256
accepted=read(receipt)
assert accepted['actualMain']==Review and accepted['source']==ReviewSource and accepted['base']==Code
assert accepted['actualReviewMainAccepted'] and accepted['fullMainCiAccepted'] and accepted['actualMainSevenAccepted'] and accepted['normalCompletionMayStart'] and not accepted['mustFix']
codefile=t/'ops020-history-io-pr196-final-actual-main-independent-review.json';assert sha(codefile)=='ca66c0e67abb3979f87b5b9e26489c32cdca4c784c1001b0b3e860fe0e85dd54'
assert read(codefile)['actualMain']==Code and read(codefile)['actualImplementationMainAccepted']
closure=t/'ops020-normal-completion-v1-issue191-closed-completed-official.json';assert sha(closure)==a.issue_closure_sha256
issue=read(closure);assert issue['number']==191 and issue['state']=='closed' and issue['state_reason']=='completed'
apreviewfile=t/'ops020-normal-completion-v1-prospective-approval-independent-review.json';assert sha(apreviewfile)==a.approval_review_sha256
apreview=read(apreviewfile)
assert apreview['conditionalApprovalAccepted'] and apreview['normalCompletionPreparationAllowed'] and not apreview['mustFix']
assert apreview['reviewMain']==Review and apreview['codeMain']==Code and apreview['preparationMethodSha256']==sha(__file__)
apfile=t/'ops020-normal-completion-v1-recovery-approval.json';assert sha(apfile)==apreview['approvalRecordSha256']
def unique(pairs):
 result={}
 for key,value in pairs:assert key not in result;result[key]=value
 return result
record=json.loads(apfile.read_bytes(),object_pairs_hook=unique)
# Resolve and verify every retrievable prerequisite before creating any commit.
initial=[receipt.name,codefile.name,closure.name,apreviewfile.name,apfile.name,'ops020-normal-review-pr197-source-final-independent-review.json','ops020-normal-review-v2-current-candidate.json','ops020-normal-review-v2-publication-independent-review.json','ops020-normal-review-pr197-actual-main-candidate.json','ops020-normal-review-pr197-merge-api-result.json']
for folder in ('ops020-history-io-pr196-source-ci962-final','ops020-history-io-pr196-main-ci963-final','ops020-normal-review-pr197-source-ci964-final','ops020-normal-review-pr197-main-ci965-final','ops020-normal-review-v2-native-source15','ops020-normal-review-pr197-99714ca-native-main-seven'):
 d=t/folder;assert d.is_dir();initial += [f.relative_to(t).as_posix() for f in sorted(d.iterdir()) if f.is_file() and f.suffix in {'.json','.raw','.txt','.xml'}]
files=collect(t,initial)
c=read(t/'ops020-normal-review-pr197-actual-main-candidate.json');assert c['actualMain']==Review and c['source']==ReviewSource and c['base']==Code
bundle=t/c['bundle'];assert bundle.stat().st_size==c['bundleBytes'] and sha(bundle)==c['bundleSha256']
def git(root,*args):return subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(root),*args])
dec=lambda root,*args:git(root,*args).decode().strip()
assert dec(canonical,'rev-parse','HEAD')==Review and dec(canonical,'branch','--show-current')=='main' and not dec(canonical,'status','--porcelain=v1','--untracked-files=all')
assert dec(canonical,'ls-remote','--heads','origin','refs/heads/main').split()==[Review,'refs/heads/main']
assert not r.exists() and not dec(canonical,'ls-remote','--heads','origin','refs/heads/'+B)
subprocess.run(['git','-c','core.longpaths=true','-c','core.autocrlf=false','clone','--quiet','--branch','main','--config','core.longpaths=true','--config','core.autocrlf=false',str(bundle),str(r)],check=True,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'))
assert dec(r,'rev-parse','HEAD')==Review and dec(r,'rev-parse','HEAD^{tree}')==c['tree'] and not (r/'.git/objects/info/alternates').exists()
git(r,'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git');git(r,'switch','--no-track','-c',B,Review)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b';data=(t/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes();assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
cache=r/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True)
if (cache/oid).exists():assert (cache/oid).read_bytes()==data
else:
 with (cache/oid).open('xb') as stream:stream.write(data)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:git(r,'config','--local',key,value)
git(r,'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin');assert (r/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data
assert not dec(r,'status','--porcelain=v1','--untracked-files=all') and not (r/APP).exists()
paths=dict(plan='specs/coordination/program-plan.yaml',active='specs/coordination/active-work.yaml',task='specs/tasks/OPS-020.md');before={key:(r/name).read_bytes() for key,name in paths.items()}
plan=yaml.safe_load(before['plan']);active=yaml.safe_load(before['active']);rows=lambda doc:{row['taskId']:row for row in doc['tasks']}
own=rows(active)['OPS-020'];target=rows(active)['POC-003']
assert own['status']=='review' and own['agentRole']=='reviewer' and own['baseSha']==Code and own['branch']=='chore/OPS-020-normal-review'
assert own['implementer']=='/root' and own['reviewer']=='/root/independent_review' and own['exclusivePaths']==['scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py','scripts/check-program-plan-history.py'] and own['sharedPaths']==[]
assert own['lease']=={'acquiredAt':'2026-11-05T13:07:45Z','expiresAt':'2026-11-12T13:07:45Z'} and len(active['tasks'])==3
registrysha=hashlib.sha256(json.dumps(target,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest();tasksha=sha(r/'specs/tasks/POC-003.md')
assert registrysha=='52274bee2fb35226dbbaa309b70d201b8bbb8f0fdbaf047989861fc0969e0374' and tasksha=='e34be7d42899abe0cc18000401499a38cb00b49e3fbc8aa8428ba47441451528'
expected=dict(schemaVersion=1,kind='conditional_prospective_blocked_work_branch_recovery',authorityTaskId='OPS-020',taskId='POC-003',reservation='08ee4bc4dc3030cc86f420cc0956a0ab5146c379',implementationCommit=Code,intentSha256='3442ac687f2fda7071b467082ffccdff2e677847c9323198cf64a7fbdc41b51d',oldBranch='chore/POC-003-ats-range',newBranch='chore/POC-003-qualified-lfs-evidence-v2',originalCreationBase='760f6c5838597d1d66c0a536ecbf440ef5a7dfec',oldUnmergedCandidate='3564346d2bdfbd80f2f705ae3dd4f7ba79103cb6',beforeRegistrySha256=registrysha,beforeTaskSha256=tasksha,reviewer='/root/independent_review',approvedAt=record['approvedAt'],decision='approved',condition='normal_authority_completion_full_ci_capacity_release_and_fresh_main')
assert record==expected and len(record)==17 and type(record['schemaVersion']) is int
instant=lambda value:datetime.fromisoformat(value.replace('Z','+00:00'));now=datetime.now(timezone.utc)
assert instant(target['lease']['acquiredAt'])<=instant(record['approvedAt'])<=now<instant(target['lease']['expiresAt']) and now<instant(own['lease']['expiresAt'])
# Validate all metadata substitutions in memory before the immutable creator.
expectedplan=copy.deepcopy(plan);node=next(row for row in expectedplan['foundationTasks'] if row['taskId']=='OPS-020');assert node['status']=='review' and node['completionRef']=='ISSUE-191' and node['mergeCommit'] is None;node.update(status='completed',completionRef='PR-196',mergeCommit=Code)
raw=before['plan'].decode('utf-8');match=re.search(r'(?ms)^  - taskId: OPS-020\n.*?(?=^  - taskId:|^[A-Za-z$]|\Z)',raw);assert match
block=match[0]
for key,value in [('status','completed'),('completionRef','PR-196'),('mergeCommit',Code)]:block,count=re.subn(r'(?m)^    '+key+r':[^\n]*$','    '+key+': '+value,block);assert count==1
updatedplan=raw[:match.start()]+block+raw[match.end():];assert yaml.safe_load(updatedplan)==expectedplan
raw=before['active'].decode('utf-8');match=re.search(r'(?ms)^- taskId: OPS-020\n.*?(?=^- taskId:|\Z)',raw);assert match
updatedactive=raw[:match.start()]+raw[match.end():];expectedactive=copy.deepcopy(active);expectedactive['tasks']=[row for row in expectedactive['tasks'] if row['taskId']!='OPS-020'];assert yaml.safe_load(updatedactive)==expectedactive and len(expectedactive['tasks'])==2 and not any(row['riskLevel'] in ('high','critical') for row in expectedactive['tasks'])
parts=before['task'].decode('utf-8').split('---',2);front,body=parts[1:]
for key,old,new in [('status','review','completed'),('agentRole','reviewer','integrator'),('workBranch','chore/OPS-020-normal-review',B),('baseSha',Code,Review)]:front,count=re.subn(r'(?m)^'+key+': '+re.escape(old)+'$',key+': '+new,front);assert count==1
updatedtask='---'+front+'---'+body;assert updatedtask.encode('utf-8').split(b'---',2)[2]==before['task'].split(b'---',2)[2]
fence=chr(96)*3;sections=re.findall(fence+r'bash\n(.*?)\n'+fence,body,re.S);assert len(sections)==1
historical=[shlex.split(line) for line in sections[0].splitlines() if line.strip()];assert len(historical)==15
commands=[[value.replace(Code,Review).replace('chore/OPS-020-normal-review',B) for value in argv] for argv in historical];assert len(commands)==15 and commands[-1]==['python','-B','-m','pytest','-q','tests/governance/test_work_branch_migration.py']
native=read(t/'ops020-normal-review-pr197-99714ca-native-main-seven/results.json');integrity=next(row for row in native['commands'] if row['label']=='integrity');member='ops020-normal-review-pr197-99714ca-native-main-seven/integrity.raw'
assert native['actualMain']==Review and native['actualMainSevenAllExitZero'] and integrity['exitCode']==0 and integrity['actualWaitCompleted'] and hashlib.sha256(files[member]).hexdigest()==integrity['sha256']
protected=own['exclusivePaths']+['.github/workflows/governance-gate.yml','scripts/check-program-plan-transitions.py','evidence/OPS-020/recovery-intent.json','specs/coordination/task-completions.yaml','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md','specs/tasks/POC-003.md','specs/tasks/POC-005.md']
for name in protected:assert (r/name).read_bytes()==git(r,'show',Review+':'+name)
assert sha(r/'evidence/OPS-020/recovery-intent.json')==expected['intentSha256'] and dec(canonical,'ls-remote','--heads','origin','refs/heads/main').split()==[Review,'refs/heads/main']
(r/APP).write_bytes(apfile.read_bytes());git(r,'add','--',APP);assert dec(r,'diff','--cached','--name-only')==APP;git(r,'diff','--cached','--check')
git(r,'commit','-m','review(OPS-020): bind exact conditional blocked recovery approval','-m','Refs #191. APP-only creator preserves admitted normal Review metadata; actual normal Completion/fullCI/capacity release and fresh main remain required before any POC recovery.')
creator=dec(r,'rev-parse','HEAD');assert dec(r,'show','-s','--format=%P',creator)==Review and dec(r,'diff','--name-only',Review,creator)==APP
for key,name in paths.items():assert (r/name).read_bytes()==before[key]
creatorfile=t/'ops020-normal-completion-v1-approval-creator-commit.json'
creatorrecord=dict(source=creator,parent=Review,approvalRecordSha256=sha(apfile),approvalReviewSha256=a.approval_review_sha256,actualGitCommitCompleted=True,taskRemainsReview=True,actualCapacityReleased=False,actualMigrationApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
with creatorfile.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(creatorrecord,indent=2)+'\n')
files[creatorfile.name]=creatorfile.read_bytes()
for name,value in [(paths['plan'],updatedplan),(paths['active'],updatedactive),(paths['task'],updatedtask)]: (r/name).write_text(value,encoding='utf-8',newline='\n')
phase=r/'evidence/OPS-020/completion-v1';phase.mkdir();archive=phase/'prerequisites.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
index=dict(kind='retrievable_lossless_accepted_prerequisites',archive=archive.name,archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),entries=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())]);assert archive.stat().st_size<8*1024*1024
(phase/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
(phase/'commands.txt').write_text('\n'.join(shlex.join(argv) for argv in commands)+'\n',encoding='utf-8',newline='\n')
context=dict(taskId='OPS-020',phase='normalCompletion',base=Review,branch=B,codeMain=Code,codePr=196,reviewSource=ReviewSource,reviewPr=197,approvalCreator=creator,reviewMainReceiptSha256=a.review_main_receipt_sha256,issueClosureSha256=a.issue_closure_sha256,approvalReviewSha256=a.approval_review_sha256,approvalRecordSha256=sha(apfile),originalTaskBodyPreserved=True,historicalTaskCommands=historical,actualCompletionCommands=commands,currentCompletionChecksExecuted=False,currentCompletionFullCiAccepted=False,actualCapacityReleased=False,actualMigrationApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
(phase/'context.json').write_text(json.dumps(context,indent=2)+'\n',encoding='utf-8',newline='\n')
(phase/'README.md').write_text('# OPS-020 normal Completion proposal\n\nAccepted Code PR196/da4 and actual normal Review PR197/997; Issue191 closed-completed. APP-only creator '+creator+' preserves normal Review. The subsequent Own metadata candidate and capacity release still require source15/all85/full927 sourceCI, normal merge, actualmain7/full927 and final independent acceptance. No POC recovery or new experiment. All archive inputs are retrievable via index.json; ZIP payloads are not executed.\n',encoding='utf-8',newline='\n')
note='\n\n## Accepted prerequisite Review main execution (prerequisite scope only)\nTask: OPS-020\nImplementation merge: '+Code+' (PR196)\nStatus: PASS (accepted prerequisite Review main only)\nResult: PASS (accepted prerequisite Review main only)\nSource Commit: '+Review+'\nCommand: '+shlex.join(integrity['argv'])+'\nExit Code: 0\nRaw artifact: completion-v1/prerequisites.zip :: '+member+'\nRaw SHA-256: '+integrity['sha256']+'\nThese executed markers belong only to accepted Review main997/CI965/native7. They do not claim current Completion source checks or CI. Body/claims/lease/actors/code/frozen/foreign remain; current source15/all85/full927 plus actualCompletionmain7/full927/finalindep remain pending. New APP-only creator '+creator+' is conditional; actual migration and actual capacity release are not approved by this proposal.\n'
for name in ['summary.md','handoff.md','commands.txt','test-results/README.md']:
 with (r/'evidence/OPS-020'/name).open('a',encoding='utf-8',newline='\n') as stream:stream.write(note)
current=list(paths.values())+[APP]+['evidence/OPS-020/'+name for name in ['summary.md','handoff.md','commands.txt','changed-files.md','test-results/README.md']]+[file.relative_to(r).as_posix() for file in phase.iterdir()];assert len(current)==len(set(current))==14
with (r/'evidence/OPS-020/changed-files.md').open('a',encoding='utf-8',newline='\n') as stream:stream.write('\n\n## Normal Completion inventory\n'+''.join('- '+name+'\n' for name in sorted(current)))
for name in protected:assert (r/name).read_bytes()==git(r,'show',Review+':'+name)
actual=set(dec(r,'diff','--name-only',Review).splitlines())|set(dec(r,'ls-files','--others','--exclude-standard').splitlines());assert actual==set(current) and sha(r/APP)==apreview['approvalRecordSha256']
with (t/'ops020-normal-completion-v1-precommit-candidate.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(dict(context,author=str(r),changedPaths=sorted(actual),approvalAlreadyCommitted=True,metadataCommitted=False),indent=2)+'\n')
print(json.dumps(dict(base=Review,approvalCreator=creator,metadataPaths=14,commands=15,metadataCommitted=False,actualMigrationApproved=False)),flush=True)
