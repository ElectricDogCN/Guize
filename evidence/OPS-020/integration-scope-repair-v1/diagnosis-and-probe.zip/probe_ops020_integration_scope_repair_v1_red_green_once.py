"""Real native Git red/green regressions in an owned uncommitted fixture clone."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,subprocess,sys,time
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;c=json.loads((t/'ops020-integration-scope-repair-v1-purpose-commit.json').read_bytes());author=t/'ops020-integration-scope-repair-v1'
out=t/'ops020-integration-scope-repair-v1-red-green';out.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
r=Path('/home/sur/.cache/guize-takeover/ops020-integration-scope-repair-v1-red-green');assert not r.exists()
env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1',PYTHONDONTWRITEBYTECODE='1')
subprocess.run(['git','clone','--quiet','--branch',c['branch'],str(author),str(r)],check=True,env=env)
git=lambda *a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
assert git('rev-parse','HEAD')==c['purposeSource'] and not (r/'.git/objects/info/alternates').exists()
names=['scripts/check-program-plan-history.py','tests/governance/test_work_branch_migration.py'];fixed={name:(author/name).read_bytes() for name in names}
for name,data in fixed.items():(r/name).write_bytes(data)
baseline=subprocess.check_output(['git','-C',str(r),'show',c['purposeSource']+':'+names[0]])
result=dict(purposeSource=c['purposeSource'],nativeRepo=str(r),sourceQualificationAccepted=False,officialCiAccepted=False,productionAuthorUnchanged=True,commands=[],testedFiles=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in fixed.items()],startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for phase in ['baseline-red','fixed-green']:
 (r/names[0]).write_bytes(baseline if phase=='baseline-red' else fixed[names[0]])
 argv=[sys.executable,'-B','-m','pytest','-q',names[1],'-k','test_history_implementation_merge_keeps_source_scope_and_exact_automatic_import'+(' and separate-prior-registration' if phase=='baseline-red' else ''),'--junitxml='+str(out/(phase+'.xml'))]
 row=dict(phase=phase,argv=argv,raw=phase+'.raw',actualWaitCompleted=False);result['commands'].append(row);save();tick=time.monotonic()
 with (out/row['raw']).open('xb') as raw:
  child=subprocess.Popen(argv,cwd=r,env=env,stdout=raw,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait()
 data=(out/row['raw']).read_bytes();row.update(exitCode=code,actualWaitCompleted=True,seconds=time.monotonic()-tick,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());save()
 print(phase+': '+str(code),flush=True)
 assert code==(1 if phase=='baseline-red' else 0)
for name,data in fixed.items():assert (r/name).read_bytes()==data and (author/name).read_bytes()==data
result.update(finishedAt=datetime.now(timezone.utc).isoformat(),redGreenPassed=True,sourceQualificationAccepted=False);save()
print(json.dumps(dict(redGreenPassed=True,newCases=6,sourceQualificationAccepted=False)),flush=True)
