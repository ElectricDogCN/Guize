"""Run only new real-Git regressions on an exact uncommitted snapshot."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,fcntl,hashlib,json,os,shlex,subprocess,sys,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--snapshot-sha256',required=True);a=p.parse_args();assert a.version in {'v1','v2','v3'}
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
T=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();sp=T/('ops022-implementation-v1-working-candidate-'+a.version+'.json')
assert sha(sp.read_bytes())==a.snapshot_sha256;c=json.loads(sp.read_bytes());B=c['base']
R=Path('/home/sur/.cache/guize-takeover/ops022-implementation-v1-working-'+a.version);O=T/('ops022-implementation-v1-native-working-tests-'+a.version)
assert not R.exists() and not O.exists();O.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],GIT_LFS_SKIP_SMUDGE='1',PYTHONDONTWRITEBYTECODE='1')
parent=json.loads((T/'ops022-reservation-v1-actual-main-candidate.json').read_bytes());bundle=T/parent['bundle']
assert parent['actualMain']==B and parent['bundleSha256']=='d4d89ba9924aa0f3a336f0c49e8996937f62fe423f95f32670775c7af7488aea' and bundle.stat().st_size==140620326
with bundle.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==parent['bundleSha256']
subprocess.run(['git','clone','--quiet','--branch','main',str(bundle),str(R)],check=True,timeout=300)
def git(*x):return subprocess.check_output(['git','-C',str(R),*x]).decode().strip()
assert git('rev-parse','HEAD')==B and not (R/'.git/objects/info/alternates').exists() and git('rev-parse','--is-shallow-repository')=='false'
subprocess.run(['git','-C',str(R),'switch','--no-track','-c',c['branch'],B],check=True,capture_output=True)
subprocess.run(['git','-C',str(R),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b';raw=(T/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes();assert len(raw)==4096 and sha(raw)==oid
cache=R/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True)
with (cache/oid).open('xb') as f:f.write(raw)
for k,v in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:subprocess.run(['git','-C',str(R),'config','--local',k,v],check=True)
os.environ.pop('GIT_LFS_SKIP_SMUDGE');subprocess.run(['git','-C',str(R),'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin'],check=True,capture_output=True)
assert (R/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==raw
author=c['author'];assert author[1:3] in {':\\',':/'};author=Path('/mnt/'+author[0].lower()+'/'+author[3:].replace('\\','/'))
for pin in c['fileSnapshot']:
    data=(author/pin['path']).read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'];target=R/pin['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
for key in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','GITHUB_REF_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):os.environ.pop(key,None)
def state():return dict(head=git('rev-parse','HEAD'),branch=git('branch','--show-current'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'),pins=[dict(path=p['path'],sha256=sha((R/p['path']).read_bytes())) for p in c['fileSnapshot']])
before=state();assert before['head']==B and before['branch']==c['branch']
argv=[sys.executable,'-B','-m','pytest','-q','tests/governance/test_historical_read_cost.py','--junitxml='+str(O/'new-tests.xml')]
result=dict(kind='UNCOMMITTED_WORKING_CANDIDATE_TESTS_ONLY',base=B,snapshotFile=sp.name,snapshotSha256=a.snapshot_sha256,nativeRepo=str(R),before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),sourceCommitted=False,newTestsAccepted=False,fullCiAccepted=False,actualWaitCompleted=False)
save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n');save();tick=time.monotonic()
with (O/'new-tests.raw').open('x',encoding='utf-8',buffering=1) as out:
    out.write('Source Code Commit: '+B+'\nWorking Tree Snapshot SHA256: '+a.snapshot_sha256+'\nCommand: '+shlex.join(argv)+'\n')
    child=subprocess.Popen(argv,cwd=R,stdout=out,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait();out.write('\nExit Code: '+str(code)+'\n')
data=(O/'new-tests.raw').read_bytes();result.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=len(data),rawSha256=sha(data),after=state());save()
assert result['before']==result['after']
tree=ET.parse(O/'new-tests.xml');cases=tree.findall('.//testcase');bad=tree.findall('.//failure')+tree.findall('.//error')+tree.findall('.//skipped')
result.update(testCases=len(cases),failedErroredSkipped=len(bad));save()
assert code==0 and len(cases)==39 and not bad
result.update(newTestsAccepted=True,finishedAt=datetime.now(timezone.utc).isoformat());save();print(json.dumps(dict(actualWaitCompleted=True,exitCode=code,testCases=len(cases),failedErroredSkipped=0,elapsedSeconds=result['elapsedSeconds'],sourceCommitted=False)),flush=True)
