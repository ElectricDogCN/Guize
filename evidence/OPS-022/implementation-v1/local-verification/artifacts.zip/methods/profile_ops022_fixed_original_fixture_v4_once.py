"""Profile the registered working checker against the preserved exact original fixture."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,shlex,subprocess,sys,time
from live_github_transport import start_bridge
T=Path(__file__).resolve().parent;N=Path('/home/sur/.cache/guize-takeover')
O=T/'ops022-implementation-v1-fixed-fixture-profile-v4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
git=lambda r,*a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
def state(r):return dict(head=git(r,'rev-parse','HEAD'),refs=git(r,'for-each-ref','--format=%(refname) %(objectname)'),status=git(r,'status','--porcelain=v1','--untracked-files=all'))
def main():
 assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
 s=T/'ops022-implementation-v1-working-candidate-v3.json';assert sha(s)=='e66a2d91edce0d808426d84ee9f33bb2bfe1d07c1e5ffb9e424838a1276b7c22';snap=read(s)
 tested=read(T/'ops022-implementation-v1-native-working-tests-v3/results.json');assert tested['newTestsAccepted'] and tested['actualWaitCompleted'] and tested['exitCode']==0
 checker=Path(tested['nativeRepo']);old=T/'poc003-ci979-actual-fixture-history-child-profile-v1/results.json';subject=read(old);root=Path(subject['fixtureRepo'])
 assert git(root,'rev-parse','HEAD')=='bb573f2b681be889a7a769b16370d6e3ed52b978' and git(root,'rev-parse','--is-shallow-repository')=='false'
 for pin in snap['fileSnapshot']:assert sha(checker/pin['path'])==pin['sha256']
 assert git(checker,'rev-parse','HEAD')==snap['base']
 for key in ('GITHUB_TOKEN','GIT_LFS_SKIP_SMUDGE','GIT_TEMPLATE_DIR','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):os.environ.pop(key,None)
 os.environ.update(PATH=str(N/'git-lfs-3.8.1-private-v1')+':'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GITHUB_ACTIONS='true',CI='true',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_EVENT_NAME='pull_request',GITHUB_HEAD_REF='chore/POC-003-qualified-lfs-evidence-v2',GITHUB_BASE_REF='main',GITHUB_REF='refs/pull/200/merge',GITHUB_REF_NAME='200/merge',GITHUB_SHA=subject['checkerSource'],GITHUB_WORKSPACE=str(checker))
 before,cb=state(root),state(checker);assert not before['status']
 lock=(N/'guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not O.exists();O.mkdir();(O/'method.actual.py').write_bytes(Path(__file__).read_bytes());start_bridge(O)
 profile=O/'history-child.pstats';raw=O/'history-child.raw'
 argv=['timeout','--signal=TERM','--kill-after=15s','600',sys.executable,'-B','-m','cProfile','-o',str(profile),str(checker/'scripts/check-program-plan-history.py'),'--repo-root',str(root),'--base-ref',subject['fixtureBase'],'--head-ref',subject['fixtureActualMain'],'--task','POC-003','--branch-name','chore/POC-003-qualified-lfs-evidence-v2']
 result=dict(kind='REGISTERED_UNCOMMITTED_CHECKER_EXACT_FIXED_FIXTURE_PROFILE',checkerBase=snap['base'],snapshotSha256=sha(s),oldProfileResultSha256=sha(old),fixtureRepo=str(root),fixtureActualMain=before['head'],oldPublicCiContext=subject['checkerSource'],argv=argv,before=before,checkerBefore=cb,officialCiAccepted=False,untracedWholeCiSpeedupClaimed=False,startedAt=datetime.now(timezone.utc).isoformat())
 save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n');save();tick=time.monotonic()
 with raw.open('x',encoding='utf8',buffering=1) as stream:
  stream.write('Checker Base: '+snap['base']+'\nWorking Snapshot SHA256: '+sha(s)+'\nChecked Fixture HEAD: '+before['head']+'\nCommand: '+shlex.join(argv)+'\n');child=subprocess.Popen(argv,cwd=checker,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait();stream.write('\nExit Code: '+str(code)+'\n')
 result.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=raw.stat().st_size,rawSha256=sha(raw),after=state(root),checkerAfter=state(checker));save()
 assert code==0 and result['after']==before and result['checkerAfter']==cb
 stats=pstats.Stats(str(profile));rows=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)]
 result.update(profileBytes=profile.stat().st_size,profileSha256=sha(profile),topFunctions=rows[:40],governanceFunctions=[x for x in rows if '/scripts/' in x['file']],finishedAt=datetime.now(timezone.utc).isoformat());save();print(json.dumps(dict(exitCode=code,actualWaitCompleted=True,instrumentedSeconds=result['elapsedSeconds'],governanceFunctions=result['governanceFunctions'][:14])),flush=True)
if __name__=='__main__':main()
