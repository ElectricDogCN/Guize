"""Pass-through timing of one already-verified original H argv. No fake result."""
from pathlib import Path
from datetime import datetime, timezone
import collections, fcntl, hashlib, json, os, runpy, subprocess, sys, time
from live_github_transport import start_bridge

T = Path(__file__).resolve().parent
N = Path('/home/sur/.cache/guize-takeover')
OUT = T / 'poc003-ci979-history-git-cost-v1'
read = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda root, *a: subprocess.check_output(['git', '-C', str(root), *a]).decode().strip()
state = lambda root: dict(head=git(root, 'rev-parse', 'HEAD'),
                           refs=git(root, 'for-each-ref', '--format=%(refname) %(objectname)'),
                           status=git(root, 'status', '--porcelain=v1', '--untracked-files=all'))


def main():
    assert os.getuid() == 1000 and sys.version_info[:3] == (3, 11, 17)
    subject_path = T / 'poc003-ci979-actual-fixture-history-child-profile-v1/results.json'
    subject = read(subject_path)
    assert subject['actualWaitCompleted'] and subject['exitCode'] == 0
    assert subject['before'] == subject['after'] and subject['checkerBefore'] == subject['checkerAfter']
    checker = N / 'poc003-ci979-first-unfinished-original-pair-v1-exact-ci979-virtual'
    root = Path(subject['fixtureRepo'])
    script = checker / 'scripts/check-program-plan-history.py'
    assert sha(script) == subject['checkerHistorySha256']
    for k in ('GITHUB_TOKEN', 'GIT_LFS_SKIP_SMUDGE', 'GIT_TEMPLATE_DIR', 'EVENT_NAME', 'PUSH_BEFORE',
              'BASE_SHA', 'HEAD_SHA', 'TASK_ID', 'BRANCH_NAME', 'GUIZE_GITHUB_API_URL', 'PYTHONHOME'):
        os.environ.pop(k, None)
    os.environ.update(PATH=str(N / 'git-lfs-3.8.1-private-v1') + ':' + str(Path(sys.executable).parent) + ':' + os.environ['PATH'],
                      PYTHONDONTWRITEBYTECODE='1', GITHUB_ACTIONS='true', CI='true', GITHUB_REPOSITORY='ElectricDogCN/Guize',
                      GITHUB_EVENT_NAME='pull_request', GITHUB_HEAD_REF='chore/POC-003-qualified-lfs-evidence-v2',
                      GITHUB_BASE_REF='main', GITHUB_REF='refs/pull/200/merge', GITHUB_REF_NAME='200/merge',
                      GITHUB_SHA=subject['checkerSource'], GITHUB_WORKSPACE=str(checker))
    before, checker_before = state(root), state(checker)
    assert before['head'] == subject['fixtureActualMain'] and not before['status'] and not checker_before['status']
    lock = (N / 'guize-performance-domain.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not OUT.exists()
    OUT.mkdir()
    (OUT / 'method.actual.py').write_bytes(Path(__file__).read_bytes())
    start_bridge(OUT)
    argv = [str(script), '--repo-root', str(root), '--base-ref', subject['fixtureBase'],
            '--head-ref', subject['fixtureActualMain'], '--task', 'POC-003',
            '--branch-name', 'chore/POC-003-qualified-lfs-evidence-v2']
    result = dict(kind='ONE_REAL_HISTORY_ARGV_PASS_THROUGH_TIMING', argv=argv,
                  originalProfileResultSha256=sha(subject_path), checkerSource=subject['checkerSource'],
                  before=before, checkerBefore=checker_before, environmentValuesStored=False,
                  originalSubprocessResultsReturnedUnchanged=True, fakeResponseProvided=False,
                  productionOrTestsChanged=False, officialCiRerunRequested=False, commands=[])
    (OUT / 'before.json').write_text(json.dumps(result, indent=2) + '\n')
    original_run = subprocess.run
    def timed_run(*args, **kwargs):
        frame = sys._getframe(1)
        caller = dict(file=frame.f_code.co_filename, line=frame.f_lineno, function=frame.f_code.co_name)
        command = args[0] if args else kwargs.get('args')
        tick = time.monotonic()
        row = dict(caller=caller, argv=list(command) if isinstance(command, (list, tuple)) else str(command),
                   cwd=str(kwargs.get('cwd', os.getcwd())))
        try:
            response = original_run(*args, **kwargs)
            row['exitCode'] = response.returncode
            return response
        finally:
            row['elapsedSeconds'] = time.monotonic() - tick
            result['commands'].append(row)
    subprocess.run = timed_run
    old_argv = sys.argv
    sys.argv = argv
    tick = time.monotonic()
    code = 0
    try:
        runpy.run_path(str(script), run_name='__main__')
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
    finally:
        subprocess.run = original_run
        sys.argv = old_argv
    result.update(exitCode=code, elapsedSeconds=time.monotonic() - tick, after=state(root),
                  checkerAfter=state(checker), finishedAt=datetime.now(timezone.utc).isoformat())
    groups = collections.defaultdict(lambda: dict(calls=0, elapsedSeconds=0.0))
    for row in result['commands']:
        command = row['argv']
        op = next((x for x in command if x in {'sparse-checkout', 'checkout', 'clone', 'show',
                  'rev-parse', 'merge-base', 'cat-file', 'config', 'ls-tree', 'log', 'diff',
                  'for-each-ref', 'check-attr', 'rev-list'}), 'other') if isinstance(command, list) else 'shell'
        key = row['caller']['function'] + ':' + op
        groups[key]['calls'] += 1
        groups[key]['elapsedSeconds'] += row['elapsedSeconds']
    result['commandGroups'] = sorted([dict(group=k, **v) for k, v in groups.items()], key=lambda x: x['elapsedSeconds'], reverse=True)
    (OUT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    assert code == 0 and result['after'] == before and result['checkerAfter'] == checker_before
    print(json.dumps(dict(exitCode=code, instrumentedSeconds=result['elapsedSeconds'],
                         commandGroups=result['commandGroups'][:18])), flush=True)


if __name__ == '__main__':
    main()
