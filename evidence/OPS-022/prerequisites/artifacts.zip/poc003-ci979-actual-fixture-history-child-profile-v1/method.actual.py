"""Profile one real H argv from the completed unchanged case, not a synthetic test."""
from pathlib import Path
from datetime import datetime, timezone
import fcntl, hashlib, json, os, pstats, shlex, subprocess, sys, time
from live_github_transport import start_bridge

T = Path(__file__).resolve().parent
N = Path('/home/sur/.cache/guize-takeover')
OUT = T / 'poc003-ci979-actual-fixture-history-child-profile-v1'
read = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda root, *a: subprocess.check_output(['git', '-C', str(root), *a]).decode().strip()


def state(root):
    return dict(head=git(root, 'rev-parse', 'HEAD'), tree=git(root, 'rev-parse', 'HEAD^{tree}'),
                refs=git(root, 'for-each-ref', '--format=%(refname) %(objectname)'),
                status=git(root, 'status', '--porcelain=v1', '--untracked-files=all'))


def main():
    assert os.getuid() == 1000 and sys.version_info[:3] == (3, 11, 17)
    pair_path = T / 'poc003-ci979-first-unfinished-original-pair-v1/results.json'
    paired = read(pair_path)
    assert paired['allTwoOriginalCasesPassed'] and paired['sourceAndReferencesUnchanged']
    subject = next(x for x in paired['commands'] if x['label'] == 'exact-ci979-virtual')
    checker = Path(subject['root'])
    assert state(checker) == subject['after'] and subject['source'] == '4ee69360d9520fae54429680276d0b95caef8591'
    for key in ('GITHUB_TOKEN', 'GIT_LFS_SKIP_SMUDGE', 'GIT_TEMPLATE_DIR', 'GITHUB_HEAD_REF', 'GITHUB_BASE_REF',
                'GITHUB_EVENT_NAME', 'EVENT_NAME', 'PUSH_BEFORE', 'BASE_SHA', 'HEAD_SHA', 'TASK_ID',
                'BRANCH_NAME', 'GUIZE_GITHUB_API_URL', 'PYTHONHOME'):
        os.environ.pop(key, None)
    os.environ.update(PATH=str(N / 'git-lfs-3.8.1-private-v1') + ':' + str(Path(sys.executable).parent) + ':' + os.environ['PATH'],
                      PYTHONDONTWRITEBYTECODE='1')
    matches = []
    for root in sorted({p.resolve() for p in Path('/tmp/pytest-of-sur').glob('pytest-*/test_blocked_recovery_source*/repo')}):
        chain, current = [], root
        for _ in range(4):
            alt = current / '.git/objects/info/alternates'
            if not alt.is_file():
                break
            lines = alt.read_text().splitlines()
            assert len(lines) == 1
            current = Path(lines[0]).resolve().parent.parent
            chain.append(str(current))
        if str(checker) in chain:
            matches.append((root, chain))
    assert len(matches) == 1, 'Require the actual retained fixture linked to this exact completed case'
    root, chain = matches[0]
    before, checker_before = state(root), state(checker)
    assert not before['status'] and git(root, 'branch', '--show-current') == 'main'
    actual = before['head']
    base, source = git(root, 'show', '-s', '--format=%P', actual).split()
    branch = 'chore/POC-003-qualified-lfs-evidence-v2'
    assert git(root, 'rev-parse', branch) == source
    assert '#9104' in git(root, 'show', '-s', '--format=%B', actual)
    lock = (N / 'guize-performance-domain.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not OUT.exists()
    OUT.mkdir()
    (OUT / 'method.actual.py').write_bytes(Path(__file__).read_bytes())
    start_bridge(OUT)
    os.environ.update(GITHUB_ACTIONS='true', CI='true', GITHUB_REPOSITORY='ElectricDogCN/Guize',
                      GITHUB_EVENT_NAME='pull_request', GITHUB_HEAD_REF=branch, GITHUB_BASE_REF='main',
                      GITHUB_REF='refs/pull/200/merge', GITHUB_REF_NAME='200/merge',
                      GITHUB_SHA=subject['source'], GITHUB_WORKSPACE=str(checker))
    checker_file = checker / 'scripts/check-program-plan-history.py'
    profile, raw = OUT / 'history-child.pstats', OUT / 'history-child.raw'
    argv = ['timeout', '--signal=TERM', '--kill-after=15s', '600', sys.executable, '-B', '-m', 'cProfile',
            '-o', str(profile), str(checker_file), '--repo-root', str(root), '--base-ref', base,
            '--head-ref', actual, '--task', 'POC-003', '--branch-name', branch]
    result = dict(kind='INSTRUMENTED_UNCHANGED_REAL_CASE_HISTORY_CHILD', pairResultSha256=sha(pair_path),
                  checkerSource=subject['source'], checkerHistorySha256=sha(checker_file), fixtureRepo=str(root),
                  originalCase=paired['case'], fixtureBase=base, fixtureSource=source, fixtureActualMain=actual,
                  alternatesChain=chain, before=before, checkerBefore=checker_before, argv=argv,
                  startedAt=datetime.now(timezone.utc).isoformat(), productionOrTestsChanged=False,
                  officialCiRerunRequested=False, thirdSameSourceRetryAllowed=False,
                  untracedTimingClaimed=False, commandsActuallyProfiled=1)
    save = lambda: (OUT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    save()
    tick = time.monotonic()
    with raw.open('x', encoding='utf8', buffering=1) as stream:
        stream.write('Checker Commit: ' + subject['source'] + '\nChecked Fixture HEAD: ' + actual + '\nCommand: ' + shlex.join(argv) + '\n')
        child = subprocess.Popen(argv, cwd=checker, stdout=stream, stderr=subprocess.STDOUT)
        result['pid'] = child.pid
        save()
        code = child.wait()
        stream.write('\nExit Code: ' + str(code) + '\n')
    result.update(actualWaitCompleted=True, exitCode=code, elapsedSeconds=time.monotonic() - tick,
                  rawBytes=raw.stat().st_size, rawSha256=sha(raw), after=state(root), checkerAfter=state(checker))
    save()
    assert code == 0 and result['after'] == before and result['checkerAfter'] == checker_before
    stats = pstats.Stats(str(profile))
    rows = [dict(file=k[0], line=k[1], function=k[2], calls=v[1], selfSeconds=v[2], cumulativeSeconds=v[3])
            for k, v in sorted(stats.stats.items(), key=lambda x: x[1][3], reverse=True)]
    result.update(profileBytes=profile.stat().st_size, profileSha256=sha(profile), topFunctions=rows[:45],
                  governanceFunctions=[x for x in rows if '/scripts/' in x['file']],
                  finishedAt=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(actualWaitCompleted=True, exitCode=code, instrumentedSeconds=result['elapsedSeconds'],
                         topFunctions=rows[:18], governanceFunctions=result['governanceFunctions'][:20])), flush=True)


if __name__ == '__main__':
    main()
