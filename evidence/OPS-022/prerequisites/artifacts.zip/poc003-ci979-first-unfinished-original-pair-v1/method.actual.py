"""Two bounded original-case profiles; exact official virtual object, no code edits."""
from pathlib import Path
from datetime import datetime, timezone
import fcntl, hashlib, json, os, pstats, shlex, subprocess, sys, time
import xml.etree.ElementTree as ET
from live_github_transport import start_bridge

T = Path(__file__).resolve().parent
N = Path('/home/sur/.cache/guize-takeover')
OUT = T / 'poc003-ci979-first-unfinished-original-pair-v1'
read = lambda p: json.loads(Path(p).read_bytes())


def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def main():
    assert os.name == 'posix' and os.getuid() == 1000 and sys.version_info[:3] == (3, 11, 17)
    c = read(T / 'poc003-recovery-forward-sync-v1-current-candidate.json')
    base = read(T / 'ops021-normal-completion-v1-actual-main-candidate.json')
    v = read(T / 'poc003-recovery-forward-sync-v1-source-ci979-attempt2-cancelled/checkout.json')
    assert v['sha'] == '4ee69360d9520fae54429680276d0b95caef8591'
    assert [x['sha'] for x in v['parents']] == [c['base'], c['source']]
    assert v['tree']['sha'] == c['tree'] and v['verification']['verified']
    payload = v['verification']['payload'].encode()
    signature = v['verification']['signature'].encode()
    headers, message = payload.split(b'\n\n', 1)
    commit = headers + b'\ngpgsig ' + signature.replace(b'\n', b'\n ') + b'\n\n' + message
    oid = hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest()
    assert oid == v['sha']  # Exact original GitHub object before any local object write.
    full, inc = T / base['bundle'], T / c['bundle']
    assert base['actualMain'] == c['base'] == '9a8b9acc58442ee2f47b678d16905dfd5be5c674'
    for path, size, digest in [(full, base['bundleBytes'], base['bundleSha256']),
                               (inc, c['bundleBytes'], c['bundleSha256'])]:
        assert path.stat().st_size == size and sha(path) == digest
    lock = (N / 'guize-performance-domain.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not OUT.exists()
    OUT.mkdir()
    (OUT / 'method.actual.py').write_bytes(Path(__file__).read_bytes())
    for key in ('GITHUB_TOKEN', 'GIT_LFS_SKIP_SMUDGE', 'GIT_TEMPLATE_DIR', 'GITHUB_HEAD_REF',
                'GITHUB_BASE_REF', 'GITHUB_EVENT_NAME', 'EVENT_NAME', 'PUSH_BEFORE', 'BASE_SHA',
                'HEAD_SHA', 'TASK_ID', 'BRANCH_NAME', 'GUIZE_GITHUB_API_URL', 'PYTHONHOME'):
        os.environ.pop(key, None)
    os.environ.update(PATH=str(N / 'git-lfs-3.8.1-private-v1') + ':' + str(Path(sys.executable).parent) + ':' + os.environ['PATH'],
                      PYTHONDONTWRITEBYTECODE='1', GIT_TERMINAL_PROMPT='0')
    case = 'tests/governance/test_work_branch_migration.py::test_blocked_recovery_source_virtual_and_actual_merge_are_one_event'
    result = dict(kind='BOUNDED_UNCHANGED_ORIGINAL_CASE_DIAGNOSTIC', case=case,
                  base=c['base'], source=c['source'], exactCiVirtual=oid,
                  gitDataCommitRawBytes=len(commit), gitDataCommitRawSha256=hashlib.sha256(commit).hexdigest(),
                  exactOfficialOidMatchedBeforeWrite=True, localGpgVerificationClaimed=False,
                  officialCiRerunRequested=False, sourceOrTestsChanged=False,
                  fullCiAccepted=False, completeCloudRefInventoryReproduced=False,
                  recreatedRefs='origin/main and PR200 virtual; local main absent as in official checkout',
                  commands=[], preparationCommands=[])
    save = lambda: (OUT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    save()
    def prep(label, argv, **kwargs):
        with (OUT / (label + '.stdout.raw')).open('xb') as stdout, (OUT / (label + '.stderr.raw')).open('xb') as stderr:
            child = subprocess.Popen(argv, stdout=stdout, stderr=stderr, **kwargs)
            code = child.wait()
        result['preparationCommands'].append(dict(label=label, argv=argv, pid=child.pid,
                                                  actualWaitCompleted=True, exitCode=code))
        save()
        assert code == 0, label
    roots = []
    for label, head in [('accepted-parent', c['base']), ('exact-ci979-virtual', oid)]:
        root = N / ('poc003-ci979-first-unfinished-original-pair-v1-' + label)
        assert not root.exists()
        prep(label + '-init', ['git', 'init', '--quiet', str(root)])
        git = lambda *a: subprocess.check_output(['git', '-C', str(root), *a]).decode().strip()
        prep(label + '-base', ['git', '-C', str(root), 'fetch', '--no-tags', str(full),
                              'refs/heads/main:refs/remotes/origin/main'])
        if head == oid:
            prep(label + '-source', ['git', '-C', str(root), 'fetch', '--no-tags', str(inc), c['branch']])
            written = subprocess.check_output(['git', '-C', str(root), 'hash-object', '-t', 'commit', '-w', '--stdin'], input=commit).decode().strip()
            assert written == oid and subprocess.check_output(['git', '-C', str(root), 'cat-file', 'commit', oid]) == commit
            prep(label + '-virtual-ref', ['git', '-C', str(root), 'update-ref', 'refs/remotes/pull/200/merge', oid, '0' * 40])
        env = dict(os.environ, GIT_LFS_SKIP_SMUDGE='1')
        prep(label + '-checkout', ['git', '-C', str(root), 'checkout', '--detach', head], env=env)
        prep(label + '-remote', ['git', '-C', str(root), 'remote', 'add', 'origin', 'https://github.com/ElectricDogCN/Guize.git'])
        assert not (root / '.git/objects/info/alternates').exists()
        assert git('rev-parse', '--is-shallow-repository') == 'false'
        assert not git('branch', '--list', 'main')
        probe = (T / 'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
        probe_oid = hashlib.sha256(probe).hexdigest()
        assert len(probe) == 4096 and probe_oid == 'f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
        cache = root / '.git/lfs/objects' / probe_oid[:2] / probe_oid[2:4]
        cache.mkdir(parents=True, exist_ok=True)
        with (cache / probe_oid).open('xb') as f:
            f.write(probe)
        for k, val in [('filter.lfs.process', 'git-lfs filter-process'), ('filter.lfs.clean', 'git-lfs clean -- %f'),
                       ('filter.lfs.smudge', 'git-lfs smudge -- %f'), ('filter.lfs.required', 'true')]:
            prep(label + '-' + k.replace('.', '-'), ['git', '-C', str(root), 'config', '--local', k, val])
        prep(label + '-hydrate', ['git', '-C', str(root), 'lfs', 'checkout', 'evidence/OPS-019/implementation-v1/lfs-probe.bin'])
        assert (root / 'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes() == probe
        roots.append((label, head, root))
    assert (roots[0][2] / case.split('::')[0]).read_bytes() == (roots[1][2] / case.split('::')[0]).read_bytes()
    start_bridge(OUT)
    def state(root):
        git = lambda *a: subprocess.check_output(['git', '-C', str(root), *a]).decode().strip()
        return dict(head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                    refs=git('for-each-ref', '--format=%(refname) %(objectname)'),
                    status=git('status', '--porcelain=v1', '--untracked-files=all'))
    for label, head, root in roots:
        before = state(root)
        assert before['head'] == head and not before['status']
        profile, raw, xml = [OUT / (label + ext) for ext in ('.pstats', '.raw', '.xml')]
        env = dict(os.environ, GITHUB_ACTIONS='true', CI='true', GITHUB_REPOSITORY='ElectricDogCN/Guize',
                   GITHUB_EVENT_NAME='pull_request', GITHUB_HEAD_REF=c['branch'], GITHUB_BASE_REF='main',
                   GITHUB_REF='refs/pull/200/merge', GITHUB_REF_NAME='200/merge', GITHUB_SHA=head, GITHUB_WORKSPACE=str(root))
        argv = ['timeout', '--signal=TERM', '--kill-after=15s', '600', sys.executable, '-B', '-m',
                'cProfile', '-o', str(profile), '-m', 'pytest', '-vv', case, '--durations=10', '--junitxml=' + str(xml)]
        row = dict(label=label, source=head, root=str(root), argv=argv, before=before,
                   startedAt=datetime.now(timezone.utc).isoformat(), maximumCaseSeconds=600)
        result['commands'].append(row)
        save()
        tick = time.monotonic()
        with raw.open('x', encoding='utf8', buffering=1) as stream:
            stream.write('Source Commit: ' + head + '\nCommand: ' + shlex.join(argv) + '\n')
            child = subprocess.Popen(argv, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
            row['pid'] = child.pid
            save()
            code = child.wait()
            stream.write('\nExit Code: ' + str(code) + '\n')
        row.update(actualWaitCompleted=True, exitCode=code, elapsedSeconds=time.monotonic() - tick,
                   rawFile=raw.name, rawBytes=raw.stat().st_size, rawSha256=sha(raw), after=state(root))
        save()
        assert code == 0 and row['after'] == before
        cases = list(ET.fromstring(xml.read_bytes()).iter('testcase'))
        assert len(cases) == 1 and not any(x.find(k) is not None for x in cases for k in ('failure', 'error', 'skipped'))
        stats = pstats.Stats(str(profile))
        ranking = sorted(stats.stats.items(), key=lambda x: x[1][3], reverse=True)
        rows = [dict(file=k[0], line=k[1], function=k[2], calls=v[1], selfSeconds=v[2], cumulativeSeconds=v[3]) for k, v in ranking]
        row.update(junitCases=1, junitSha256=sha(xml), profileSha256=sha(profile), topFunctions=rows[:30],
                   governanceFunctions=[x for x in rows if '/scripts/' in x['file']],
                   testFunctions=[x for x in rows if '/tests/governance/' in x['file']])
        save()
        print(json.dumps(dict(label=label, exitCode=code, seconds=row['elapsedSeconds'], governanceFunctions=row['governanceFunctions'][:10])), flush=True)
    result.update(allTwoOriginalCasesPassed=True, sourceAndReferencesUnchanged=True,
                  finishedAt=datetime.now(timezone.utc).isoformat(), uniqueCloudCauseClaimed=False)
    save()


if __name__ == '__main__':
    main()
