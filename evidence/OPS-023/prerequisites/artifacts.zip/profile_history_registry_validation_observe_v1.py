"""Observe repeated structural validation inputs; delegate every real check."""
from pathlib import Path
import cProfile,hashlib,importlib.util,json,sys,time

profile_path,script=sys.argv[1:3]
assert Path(script).name=='check-program-plan-history.py'
sys.argv=sys.argv[2:];sys.path.insert(0,str(Path(script).parent))
spec=importlib.util.spec_from_file_location('observed_original_history',script)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.historical_registry_schema
rows=[]
def observed(root,ref,registry,label,errors):
    # Extra read is diagnostic observation only; every actual validator still runs.
    schema=module.read_ref(root,ref,module.REGISTRY_SCHEMA)
    try:
        doc=json.dumps(registry,sort_keys=True,separators=(',',':'),allow_nan=False)
        key=hashlib.sha256((str(schema)+'\0'+doc).encode()).hexdigest()
    except (TypeError,ValueError,RecursionError):key=None
    before=len(errors);tick=time.monotonic()
    try:return original(root,ref,registry,label,errors)
    finally:rows.append(dict(key=key,elapsedSeconds=time.monotonic()-tick,newErrors=len(errors)-before))
module.historical_registry_schema=observed
profiler=cProfile.Profile();profiler.enable()
try:
    code=module.main()
finally:
    profiler.disable();profiler.dump_stats(profile_path)
    path=Path(profile_path).with_suffix('.registry-observation.json')
    with path.open('x',encoding='utf-8') as f:f.write(json.dumps(dict(rows=rows,allChecksDelegated=True,structuralVerdictsCached=False),indent=2)+'\n')
raise SystemExit(code)
