"""Observe actual Program schema inputs while delegating every original check."""
from pathlib import Path
import cProfile,hashlib,importlib.util,json,sys,time
profile_path,script=sys.argv[1:3]
assert Path(script).name=='check-program-plan-history.py'
sys.argv=sys.argv[2:];sys.path.insert(0,str(Path(script).parent))
spec=importlib.util.spec_from_file_location('observed_original_history',script)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.snapshot_validator
rows=[]
class ObservedValidator:
    def __init__(self,validator):self.validator=validator
    def __getattr__(self,name):return getattr(self.validator,name)
    def iter_errors(self,document,*args,**kwargs):
        try:
            encoded=json.dumps([self.validator.schema,document],sort_keys=True,separators=(',',':'),allow_nan=False)
            key=hashlib.sha256(encoded.encode()).hexdigest()
        except (TypeError,ValueError,RecursionError):key=None
        tick=time.monotonic();count=0
        try:
            for error in self.validator.iter_errors(document,*args,**kwargs):
                count+=1;yield error
        finally:rows.append(dict(key=key,elapsedSeconds=time.monotonic()-tick,errors=count))
def observe(*args,**kwargs):
    validator=original(*args,**kwargs)
    return ObservedValidator(validator) if args[2]==module.PROGRAM_SCHEMA else validator
module.snapshot_validator=observe
profiler=cProfile.Profile();profiler.enable()
try:code=module.main()
finally:
    profiler.disable();profiler.dump_stats(profile_path)
    with Path(profile_path).with_suffix('.program-observation.json').open('x',encoding='utf-8') as f:
        f.write(json.dumps(dict(rows=rows,allChecksDelegated=True,structuralVerdictsCached=False),indent=2)+'\n')
raise SystemExit(code)
