"""Profile a diagnostic history CLI while preserving its actual SystemExit."""
from pathlib import Path
import cProfile,runpy,sys

profile_path,script=sys.argv[1:3]
assert Path(script).name=='check-program-plan-history.py'
sys.argv=sys.argv[2:]
sys.path.insert(0,str(Path(script).parent))
profiler=cProfile.Profile()
profiler.enable()
try:
    runpy.run_path(script,run_name='__main__')
finally:
    profiler.disable()
    profiler.dump_stats(profile_path)
