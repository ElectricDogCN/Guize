"""One unchanged original case with profiler prefixes on its exact history children.

Diagnostic only: no CI acceptance, source modification or production experiment.
"""
from pathlib import Path
from datetime import datetime,timezone
import cProfile,fcntl,hashlib,importlib.util,json,os,pstats,subprocess,sys,time,unittest
from live_github_transport import start_bridge

T=Path(__file__).resolve().parent
R=Path('/home/sur/.cache/guize-takeover/poc003-recovery-forward-sync-v2-main-seven-693586d')
OUT=T/'poc003-main989-original-history-case-profile-v1'
H='693586d8ae25c4c2a0654aa7a9cb449c58eba8ce'
CASE='test_foundation_post_own_work_old_side_lease_rejected'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git','-C',str(R),*a]).decode().strip()
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))

def main():
 assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
 before=state();assert before['head']==H and not before['status'] and not OUT.exists()
 lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 OUT.mkdir();(OUT/'method.actual.py').write_bytes(Path(__file__).read_bytes())
 for key in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','PYTHONHOME','GIT_LFS_SKIP_SMUDGE'):
  os.environ.pop(key,None)
 os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
 start_bridge(OUT)
 file=R/'tests/governance/test_program_plan_history.py'
 assert file.read_bytes()==subprocess.check_output(['git','-C',str(R),'show',H+':tests/governance/test_program_plan_history.py'])
 spec=importlib.util.spec_from_file_location('original_history_case_diagnostic',file)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 result=dict(kind='ONE_INSTRUMENTED_UNCHANGED_ORIGINAL_HISTORY_CASE',source=H,case='tests/governance/test_program_plan_history.py::TestProgramPlanHistory::'+CASE,testFileSha256=sha(file),historyFileSha256=sha(R/'scripts/check-program-plan-history.py'),before=before,children=[],startedAt=datetime.now(timezone.utc).isoformat(),sourceOrTestsChanged=False,officialCiAccepted=False,third989Requested=False,productionExperimentExecuted=False)
 save=lambda:(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 original_run=subprocess.run
 def profiled_child(argv,*args,**kwargs):
  target=isinstance(argv,(list,tuple)) and len(argv)>1 and str(R/'scripts/check-program-plan-history.py') in argv
  if not target:return original_run(argv,*args,**kwargs)
  index=len(result['children']);profile=OUT/('history-child-'+str(index)+'.pstats')
  script_index=argv.index(str(R/'scripts/check-program-plan-history.py'))
  actual=[*argv[:script_index],'-m','cProfile','-o',str(profile),*argv[script_index:]]
  row=dict(originalArgv=list(argv),instrumentedArgv=actual,startedAt=datetime.now(timezone.utc).isoformat());result['children'].append(row);save()
  tick=time.monotonic();completed=original_run(actual,*args,**dict(kwargs,timeout=120))
  row.update(actualWaitCompleted=True,exitCode=completed.returncode,elapsedSeconds=time.monotonic()-tick,profile=str(profile),profileSha256=sha(profile));save()
  return completed
 subprocess.run=profiled_child
 profile=cProfile.Profile();tick=time.monotonic()
 try:
  with (OUT/'case.raw').open('x',encoding='utf-8') as raw:
   suite=unittest.TestSuite([module.TestProgramPlanHistory(CASE)])
   outcome=profile.runcall(unittest.TextTestRunner(stream=raw,verbosity=2).run,suite)
 finally:
  subprocess.run=original_run;profile.dump_stats(str(OUT/'parent.pstats'))
 result.update(elapsedSeconds=time.monotonic()-tick,actualCasePassed=outcome.wasSuccessful(),testsRun=outcome.testsRun,failures=len(outcome.failures),errors=len(outcome.errors),after=state(),finishedAt=datetime.now(timezone.utc).isoformat())
 assert result['after']==before
 summaries=[]
 for path in [OUT/'parent.pstats',*[Path(x['profile']) for x in result['children']]]:
  stats=pstats.Stats(str(path));rows=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)]
  summary=dict(path=path.name,bytes=path.stat().st_size,sha256=sha(path),topFunctions=rows[:25],governanceFunctions=[x for x in rows if '/scripts/' in x['file']][:30]);summaries.append(summary)
 result['profiles']=summaries;save()
 print(json.dumps(dict(source=H,case=CASE,actualCasePassed=result['actualCasePassed'],testsRun=result['testsRun'],children=len(result['children']),elapsedSeconds=result['elapsedSeconds'],profiles=summaries)),flush=True)
 assert outcome.wasSuccessful() and outcome.testsRun==1

if __name__=='__main__':main()
