"""Cold native working-tree checks for exactly the two registered source paths."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,subprocess,sys
from live_github_transport import start_bridge
T=Path(__file__).resolve().parent;N=Path('/home/sur/.cache/guize-takeover')
R=N/'ops023-working-program-structure-v1';OUT=T/'ops023-working-program-structure-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17) and not R.exists() and not OUT.exists()
c=read(T/'ops023-implementation-v1-working-input.json');activation=read(T/'ops023-implementation-v1-activation-commit/results.json')
assert activation['activationCommitted'] and not activation['implementationTouched'] and activation['source']==c['activation']
review=read(T/'ops023-local-start-v1-decision-independent-review.json');assert review['localStartDecisionAccepted'] and not review['mustFix']
lock=(N/'guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for key in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','GITHUB_REF_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','PYTHONHOME'):
 os.environ.pop(key,None)
os.environ.update(PATH=str(N/'git-lfs-3.8.1-private-v1')+':'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],GIT_LFS_SKIP_SMUDGE='1',PYTHONDONTWRITEBYTECODE='1')
base=read(T/'ops023-reservation-v1-actual-main-candidate.json');bundle=T/base['bundle']
assert base['actualMain']==c['base'] and sha(bundle)==base['bundleSha256']
increment=T/c['activationBundle'];assert sha(increment)==c['activationBundleSha256']
OUT.mkdir();(OUT/'method.actual.py').write_bytes(Path(__file__).read_bytes())
subprocess.run(['git','clone','--quiet','--branch','main',str(bundle),str(R)],check=True)
git=lambda *a:subprocess.check_output(['git','-C',str(R),*a]).decode().strip()
subprocess.run(['git','-C',str(R),'fetch','--quiet','--no-tags',str(increment),c['branch']],check=True)
subprocess.run(['git','-C',str(R),'switch','--no-track','-c',c['branch'],'FETCH_HEAD'],check=True,capture_output=True)
assert git('rev-parse','HEAD')==c['activation'] and not (R/'.git/objects/info/alternates').exists()
subprocess.run(['git','-C',str(R),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b';probe='evidence/OPS-019/implementation-v1/lfs-probe.bin';raw=(T/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes()
assert len(raw)==4096 and hashlib.sha256(raw).hexdigest()==oid
cache=R/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True);(cache/oid).write_bytes(raw)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:subprocess.run(['git','-C',str(R),'config','--local',key,value],check=True)
os.environ.pop('GIT_LFS_SKIP_SMUDGE');subprocess.run(['git','-C',str(R),'lfs','checkout',probe],check=True,capture_output=True)
assert (R/probe).read_bytes()==raw
author=Path('/mnt/c'+Path(c['author']).as_posix()[2:]) if not c['author'].startswith('C:') else Path('/mnt/c/'+c['author'][3:].replace('\\','/'))
for pin in c['files']:
 source=author/pin['path'];assert source.stat().st_size==pin['bytes'] and sha(source)==pin['sha256']
 (R/pin['path']).write_bytes(source.read_bytes());assert sha(R/pin['path'])==pin['sha256']
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert git('diff','--name-only').splitlines()==['scripts/check-program-plan-history.py'] and git('ls-files','--others','--exclude-standard').splitlines()==['tests/governance/test_program_schema_cache.py']
start_bridge(OUT)
argv=[sys.executable,'-B','-m','pytest','-v','-ra','--durations=10','--junitxml='+str(OUT/'junit.xml'),
 'tests/governance/test_program_schema_cache.py',
 'tests/governance/test_reservation_role_amendment.py::test_schema_reuse_keeps_selected_draft_formats_and_fresh_validator',
 'tests/governance/test_reservation_role_amendment.py::test_one_schema_read_binds_validation_to_a_moving_ref',
 'tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_post_own_work_old_side_lease_rejected']
result=dict(base=c['base'],activation=c['activation'],workingFiles=c['files'],before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),performanceSourceCommitted=False,officialCiAccepted=False,experimentExecuted=False)
save=lambda:(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');save()
with (OUT/'pytest.raw').open('xb') as stream:
 child=subprocess.Popen(argv,cwd=R,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait()
result.update(actualWaitCompleted=True,exitCode=code,after=state(),rawSha256=sha(OUT/'pytest.raw'),finishedAt=datetime.now(timezone.utc).isoformat());save()
assert result['before']==result['after']
print(json.dumps(dict(actualWaitCompleted=True,exitCode=code,sourceUnchanged=True,officialCiAccepted=False)),flush=True)
raise SystemExit(code)
