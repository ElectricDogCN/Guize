"""Two instrumented original H invocations on one byte/graph-exact fixture."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,subprocess,sys,time
from live_github_transport import start_bridge
T=Path(__file__).resolve().parent;N=Path('/home/sur/.cache/guize-takeover')
OUT=T/'ops023-exact-original-fixture-comparison-v1';F=N/'ops023-exact-original-fixture-comparison-v1'
BASE=N/'ops023-reservation-v1-main-seven-0d540a3';WORK=N/'ops023-working-program-structure-v1'
read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda root,*args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
state=lambda root:dict(head=git(root,'rev-parse','HEAD'),tree=git(root,'rev-parse','HEAD^{tree}'),refs=git(root,'for-each-ref','--format=%(refname) %(objectname)'),status=git(root,'status','--porcelain=v1','--untracked-files=all'))

def main():
 assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17) and not OUT.exists() and not F.exists()
 test=read(T/'ops023-working-program-structure-v4/results.json');assert test['actualWaitCompleted'] and test['exitCode']==0 and test['before']==test['after']
 for pin in test['workingFiles']:assert sha(WORK/pin['path'])==pin['sha256']
 assert git(BASE,'rev-parse','HEAD')==test['base']=='0d540a3241f6ba9681081d03b6206158444dce67'
 carrier=read(T/'poc003-ci979-fixed-original-fixture-v1-carrier/results.json')
 inc=T/carrier['bundle'];assert inc.stat().st_size==carrier['bundleBytes']==29370 and sha(inc)=='36a0e705dc69807c88ee906c8beae0340cd7ae7dd7d342ea1b35638c91c5a617'
 parent=read(T/'ops023-reservation-v1-actual-main-candidate.json');full=T/parent['bundle'];assert sha(full)==parent['bundleSha256']
 lock=(N/'guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for key in ('GITHUB_TOKEN','GIT_TEMPLATE_DIR','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):
  os.environ.pop(key,None)
 os.environ.update(PATH=str(N/'git-lfs-3.8.1-private-v1')+':'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GIT_LFS_SKIP_SMUDGE='1')
 OUT.mkdir();(OUT/'method.actual.py').write_bytes(Path(__file__).read_bytes());start_bridge(OUT)
 prep=[]
 def command(label,argv,**kwargs):
  with (OUT/(label+'.stdout.raw')).open('xb') as so,(OUT/(label+'.stderr.raw')).open('xb') as se:
   child=subprocess.Popen(argv,stdout=so,stderr=se,**kwargs);code=child.wait()
  prep.append(dict(label=label,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code));assert code==0,label
 command('init',['git','init','--quiet',str(F)])
 command('base-objects',['git','-C',str(F),'fetch','--quiet','--no-tags',str(full),'refs/heads/main'])
 command('original-fixture',['git','-C',str(F),'fetch','--quiet','--no-tags',str(inc),'refs/heads/*:refs/heads/*'])
 actual=dict(line.split(' ',1) for line in git(F,'for-each-ref','--format=%(refname) %(objectname)').splitlines());assert actual==carrier['refs']
 command('checkout',['git','-C',str(F),'checkout','--quiet','main'])
 command('origin',['git','-C',str(F),'remote','add','origin','https://github.com/ElectricDogCN/Guize.git'])
 assert git(F,'rev-parse','HEAD')==carrier['fixtureActualMain']=='bb573f2b681be889a7a769b16370d6e3ed52b978' and git(F,'rev-parse','--is-shallow-repository')=='false'
 oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b';probe='evidence/OPS-019/implementation-v1/lfs-probe.bin'
 payload=(T/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes();assert len(payload)==4096 and hashlib.sha256(payload).hexdigest()==oid
 pointer=subprocess.check_output(['git','-C',str(F),'show','HEAD:'+probe]);assert pointer==('version https://git-lfs.github.com/spec/v1\noid sha256:'+oid+'\nsize 4096\n').encode()
 cache=F/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True);(cache/oid).write_bytes(payload)
 for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:command('config-'+key.rsplit('.',1)[1],['git','-C',str(F),'config','--local',key,value])
 os.environ.pop('GIT_LFS_SKIP_SMUDGE');command('hydrate',['git','-C',str(F),'lfs','checkout',probe]);assert (F/probe).read_bytes()==payload
 original=read(T/'poc003-ci979-actual-fixture-history-child-profile-v1/results.json')
 assert original['fixtureBase']==carrier['fixtureBase'] and original['fixtureActualMain']==carrier['fixtureActualMain']
 os.environ.update(GITHUB_ACTIONS='true',CI='true',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_EVENT_NAME='pull_request',GITHUB_HEAD_REF='chore/POC-003-qualified-lfs-evidence-v2',GITHUB_BASE_REF='main',GITHUB_REF='refs/pull/200/merge',GITHUB_REF_NAME='200/merge',GITHUB_SHA=original['checkerSource'])
 before=state(F);assert not before['status']
 result=dict(kind='SAME_EXACT_ORIGINAL_FIXTURE_INSTRUMENTED_COMPARISON',fixtureRepo=str(F),fixtureBefore=before,fixtureBase=carrier['fixtureBase'],fixtureSource=carrier['fixtureSource'],fixtureActualMain=carrier['fixtureActualMain'],carrierSha256=sha(inc),preparationCommands=prep,commands=[],originalFixtureUnmodified=True,wholeCiSpeedupClaimed=False,officialCiAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
 save=lambda:(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');save()
 for label,checker in [('current-base',BASE),('registered-working',WORK)]:
  cb=state(checker);profile=OUT/(label+'.pstats');raw=OUT/(label+'.raw');source=checker/'scripts/check-program-plan-history.py'
  original_args=[str(source),'--repo-root',str(F),'--base-ref',carrier['fixtureBase'],'--head-ref',carrier['fixtureActualMain'],'--task','POC-003','--branch-name','chore/POC-003-qualified-lfs-evidence-v2']
  argv=['timeout','--signal=TERM','--kill-after=15s','600',sys.executable,'-B',str(T/'profile_history_cli_preserve_exit_v1.py'),str(profile),*original_args]
  row=dict(label=label,checkerBefore=cb,historySha256=sha(source),originalArgs=original_args,argv=argv,startedAt=datetime.now(timezone.utc).isoformat());result['commands'].append(row);save();tick=time.monotonic()
  with raw.open('xb') as stream:
   child=subprocess.Popen(argv,cwd=checker,env=dict(os.environ,GITHUB_WORKSPACE=str(checker)),stdout=stream,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait()
  row.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawSha256=sha(raw),checkerAfter=state(checker),fixtureAfter=state(F));save()
  assert code==0 and row['checkerAfter']==cb and row['fixtureAfter']==before
  stats=pstats.Stats(str(profile));functions=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)]
  row.update(profileBytes=profile.stat().st_size,profileSha256=sha(profile),governanceFunctions=[x for x in functions if '/scripts/' in x['file']],topFunctions=functions[:20]);save()
 result.update(fixtureAfter=state(F),bothActualExitZero=True,finishedAt=datetime.now(timezone.utc).isoformat());save()
 print(json.dumps(dict(bothActualExitZero=True,measurements=[{k:r[k] for k in ['label','elapsedSeconds','exitCode','historySha256']} for r in result['commands']],wholeCiSpeedupClaimed=False)),flush=True)

if __name__=='__main__':main()
