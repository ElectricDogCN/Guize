"""One corrected working-source run; retain the actual initial failed run."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,subprocess,sys
from live_github_transport import start_bridge
T=Path(__file__).resolve().parent;N=Path('/home/sur/.cache/guize-takeover')
R=N/'ops023-working-program-structure-v1';OUT=T/'ops023-working-program-structure-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17) and R.exists() and not OUT.exists()
first=read(T/'ops023-working-program-structure-v1/results.json');c=read(T/'ops023-implementation-v1-working-input-v2.json')
assert first['actualWaitCompleted'] and first['exitCode']==1 and first['before']==first['after'] and first['activation']==c['activation']
lock=(N/'guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
git=lambda *a:subprocess.check_output(['git','-C',str(R),*a]).decode().strip()
assert git('rev-parse','HEAD')==c['activation']
for pin in first['workingFiles']:assert sha(R/pin['path'])==pin['sha256']
for key in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','GITHUB_REF_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','PYTHONHOME','GIT_LFS_SKIP_SMUDGE'):
 os.environ.pop(key,None)
os.environ.update(PATH=str(N/'git-lfs-3.8.1-private-v1')+':'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
author=Path('/mnt/c/'+c['author'][3:].replace('\\','/'))
for pin in c['files']:
 path=author/pin['path'];assert path.stat().st_size==pin['bytes'] and sha(path)==pin['sha256'];(R/pin['path']).write_bytes(path.read_bytes())
OUT.mkdir();(OUT/'method.actual.py').write_bytes(Path(__file__).read_bytes());start_bridge(OUT)
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert git('diff','--name-only').splitlines()==['scripts/check-program-plan-history.py'] and git('ls-files','--others','--exclude-standard').splitlines()==['tests/governance/test_program_schema_cache.py']
argv=[sys.executable,'-B','-m','pytest','-v','-ra','--durations=10','--junitxml='+str(OUT/'junit.xml'),
 'tests/governance/test_program_schema_cache.py',
 'tests/governance/test_reservation_role_amendment.py::test_schema_reuse_keeps_selected_draft_formats_and_fresh_validator',
 'tests/governance/test_reservation_role_amendment.py::test_one_schema_read_binds_validation_to_a_moving_ref',
 'tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_post_own_work_old_side_lease_rejected']
result=dict(base=c['base'],activation=c['activation'],workingFiles=c['files'],before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),initialFailureRetained=True,designRefinementSha256=c['designRefinementSha256'],performanceSourceCommitted=False,officialCiAccepted=False,experimentExecuted=False)
save=lambda:(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');save()
with (OUT/'pytest.raw').open('xb') as stream:
 child=subprocess.Popen(argv,cwd=R,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait()
result.update(actualWaitCompleted=True,exitCode=code,after=state(),rawSha256=sha(OUT/'pytest.raw'),finishedAt=datetime.now(timezone.utc).isoformat());save()
assert result['before']==result['after']
print(json.dumps(dict(actualWaitCompleted=True,exitCode=code,sourceUnchanged=True,officialCiAccepted=False)),flush=True)
raise SystemExit(code)
