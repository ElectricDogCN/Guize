"""Reproduce the independent review's two Schema-identity counterexamples."""
from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys
T=Path(__file__).resolve().parent;N=Path('/home/sur/.cache/guize-takeover');R=N/'ops023-working-program-structure-v1';OUT=T/'ops023-schema-bool-integer-reproduction-v1'
assert os.getuid()==1000 and not OUT.exists()
lock=(N/'guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(R/'scripts/check-program-plan-history.py')=='bab207142982d906dd7b2c7ec981c7cc9d008a504a9271ce23a09f117a7bac28'
author=T/'ops023-implementation-v1/tests/governance/test_program_schema_cache.py';target=R/'tests/governance/test_program_schema_cache.py';target.write_bytes(author.read_bytes())
OUT.mkdir();(OUT/'method.actual.py').write_bytes(Path(__file__).read_bytes())
argv=[sys.executable,'-B','-m','pytest','-v','-ra','--junitxml='+str(OUT/'junit.xml'),'tests/governance/test_program_schema_cache.py::test_python_equal_bool_integer_schema_change_cannot_reuse_structure']
with (OUT/'pytest.raw').open('xb') as raw:
 child=subprocess.Popen(argv,cwd=R,stdout=raw,stderr=subprocess.STDOUT);code=child.wait()
result=dict(actualWaitCompleted=True,exitCode=code,argv=argv,pid=child.pid,oldHistorySha256=sha(R/'scripts/check-program-plan-history.py'),newTestSha256=sha(target),rawSha256=sha(OUT/'pytest.raw'),officialCiAccepted=False)
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(code)
