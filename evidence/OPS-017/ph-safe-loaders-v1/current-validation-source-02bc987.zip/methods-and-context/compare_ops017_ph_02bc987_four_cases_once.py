"""One sequential untraced before/after sample of four unchanged existing cases."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,ast,hashlib,json,os,platform,resource,shlex,signal,subprocess,sys,time
import xml.etree.ElementTree as ET
import yaml
from live_github_transport import start_bridge

assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--context',type=Path,required=True);args=p.parse_args();context=json.loads(args.context.read_bytes())
c=json.loads((t/'ops017-ph-safe-loaders-02bc987-candidate.json').read_bytes())
assert context['checkout']==c['source']=='02bc9876ab77e4aab5dce61b387df5e82c2658d3'
assert context['localWorkflowMethod']==Path(__file__).name and context['localWorkflowMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
qualification=json.loads((t/'ops017-ph-safe-loaders-02bc987-prepublication/results.json').read_bytes())
terminal=json.loads((t/'ops017-ph-safe-loaders-02bc987-controller/actual-terminal-wait.json').read_bytes())
assert qualification['source']==c['source'] and qualification['allNonFullCiChecksPassed'] and terminal['actualWaitCompleted'] and terminal['exitCode']==0
base=c['base'];assert base=='d15d8e106aef844992caa183d866e95189a56776'
out=t/'ops017-ph-02bc987-four-case-comparison-v1';out.mkdir()
targets=[
 'tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration',
 'tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_wrong_owner_producer_and_post_thaw_edits_remain_denied_for_new_scope',
 'tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair',
 'tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_own_evidence']
for key in ('PYTHONHOME','PUSH_BEFORE','GITHUB_TOKEN'):os.environ.pop(key,None)
os.environ.update(PATH=str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_BASE_REF='main',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request',GITHUB_HEAD_REF=c['branch'],GITHUB_REF_NAME=c['branch'])
start_bridge(out)
data=dict(base=base,source=c['source'],python=sys.version,executable=sys.executable,yamlVersion=yaml.__version__,cSafeLoaderAvailable=hasattr(yaml,'CSafeLoader'),platform=platform.platform(),targets=targets,runs=[],singleSequentialUntracedSample=True,hostSettingsChanged=False,otherOwnedQualificationCompletedBeforeStart=True,fullCiAccepted=False,performanceAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
def state(repo):return dict(head=git(repo,'rev-parse','HEAD'),tree=git(repo,'rev-parse','HEAD^{tree}'),refs=git(repo,'for-each-ref','--format=%(refname) %(objectname)'),status=git(repo,'status','--porcelain=v1','--untracked-files=all'))
method_asts=[]
save()
for label,head,bundle_name,bundle_sha,branch in [
 ('baseline',base,'ops017-amendment-d15d8e1-actual-main.bundle',None,'main'),
 ('candidate',c['source'],c['bundle'],c['bundleSha256'],c['branch'])]:
    # Verify the immutable baseline bundle using its accepted receipt value.
    if label=='baseline':
        accepted=json.loads((t/'ops017-amendment-actual-main-candidate.json').read_bytes());assert accepted['actualMain']==base and accepted['bundle']==bundle_name
        bundle_sha=accepted['bundleSha256']
    bundle=t/bundle_name;assert hashlib.sha256(bundle.read_bytes()).hexdigest()==bundle_sha
    repo=Path('/home/sur/.cache/guize-takeover/ops017-ph-four-case-'+label+'-'+head[:7]);assert not repo.exists()
    subprocess.run(['git','clone','--quiet','--branch',branch,str(bundle),str(repo)],check=True)
    subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
    before=state(repo);assert before['head']==head and not before['status'] and not (repo/'.git/objects/info/alternates').exists()
    asts=[]
    for target in targets:
        filename,classname,methodname=target.split('::')
        tree=ast.parse((repo/filename).read_text(encoding='utf-8'))
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==classname)
        asts.append(ast.dump(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==methodname),include_attributes=False))
    method_asts.append(asts)
    if label=='candidate':assert method_asts[0]==method_asts[1]
    env=dict(os.environ,GITHUB_HEAD_REF='chore/OPS-017-scope-amendment-v1' if label=='baseline' else c['branch'],GITHUB_REF_NAME='chore/OPS-017-scope-amendment-v1' if label=='baseline' else c['branch'])
    argv=[sys.executable,'-B','-m','pytest','-p','no:cacheprovider','-v','-ra',*targets,'--junitxml='+str(out/(label+'.xml'))]
    row=dict(label=label,head=head,before=before,argv=argv,environmentHeadRef=env['GITHUB_HEAD_REF'],raw=label+'.raw');data['runs'].append(row);save()
    with (out/row['raw']).open('x',encoding='utf-8',buffering=1) as raw:
        raw.write('Source Commit: '+head+'\nCommand: '+shlex.join(argv)+'\n')
        usage_before=resource.getrusage(resource.RUSAGE_CHILDREN);tick=time.monotonic_ns()
        child=subprocess.Popen(argv,cwd=repo,stdout=raw,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        row['pid']=child.pid;save()
        try:code=child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
            code=child.wait(timeout=30);row['timedOut']=True
        elapsed=time.monotonic_ns()-tick;usage_after=resource.getrusage(resource.RUSAGE_CHILDREN)
        raw.write('\nExit Code: '+str(code)+'\n')
    rawbytes=(out/row['raw']).read_bytes()
    row.update(actualWaitCompleted=True,exitCode=code,elapsedNs=elapsed,cpuUserSeconds=usage_after.ru_utime-usage_before.ru_utime,cpuSystemSeconds=usage_after.ru_stime-usage_before.ru_stime,rawBytes=len(rawbytes),rawSha256=hashlib.sha256(rawbytes).hexdigest(),after=state(repo));save()
    assert code==0 and row['after']==before
    xml=ET.parse(out/(label+'.xml')).getroot();assert len(xml.findall('.//testcase'))==4 and not any(xml.findall('.//'+name) for name in ['failure','error','skipped'])
    row.update(passed=4,failures=0,errors=0,skipped=0,junitSha256=hashlib.sha256((out/(label+'.xml')).read_bytes()).hexdigest());save()
before,after=data['runs'];data.update(caseMethodsAstIdentical=True,wallReductionFraction=1-after['elapsedNs']/before['elapsedNs'],cpuBeforeSeconds=before['cpuUserSeconds']+before['cpuSystemSeconds'],cpuAfterSeconds=after['cpuUserSeconds']+after['cpuSystemSeconds'],comparisonCompleted=True,finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(base=base,source=c['source'],baselineSeconds=before['elapsedNs']/1e9,candidateSeconds=after['elapsedNs']/1e9,wallReductionFraction=data['wallReductionFraction'],bothFourPassed=True,fullCiAccepted=False)),flush=True)
