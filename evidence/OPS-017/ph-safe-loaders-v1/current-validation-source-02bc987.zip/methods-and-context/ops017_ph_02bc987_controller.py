"""One owned, detached Linux source-qualification controller; no service or host configuration."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shlex,signal,subprocess,sys

assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
o=t/'ops017-ph-safe-loaders-02bc987-controller'
method=t/'qualify_ops017_ph_02bc987_once.py'
context=t/'ops017-ph-safe-loaders-02bc987-qualification-context.json'
source='02bc9876ab77e4aab5dce61b387df5e82c2658d3'
method_sha='19e00bdb0bb415f341017051c14e54fa212a2d418140f9641970218a5d63e03d'
now=lambda:datetime.now(timezone.utc).isoformat()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (o/name).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(data,indent=2)+'\n')
def process(pid):
    try:
        p=Path('/proc')/str(pid);stat=p.joinpath('stat').read_text();fields=stat[stat.rindex(')')+2:].split()
        args=p.joinpath('cmdline').read_bytes().decode().split(chr(0))
        return dict(pid=pid,uid=p.stat().st_uid,state=fields[0],startTicks=int(fields[19]),args=args)
    except (FileNotFoundError,PermissionError):return None
def public_process(pid,start,script):
    p=process(pid)
    return dict(pid=pid,matchingLive=bool(p and p['uid']==1000 and p['startTicks']==start and p['state']!='Z' and str(script) in p['args']),state=p['state'] if p else None)

a=argparse.ArgumentParser();a.add_argument('mode',choices=['launch','run','probe']);mode=a.parse_args().mode
if mode=='launch':
    assert digest(method)==method_sha
    c=json.loads(context.read_bytes());assert c['kind']=='source' and c['checkout']==source and c['localWorkflowMethod']==method.name and c['localWorkflowMethodSha256']==method_sha
    o.mkdir()
    write('launch-intent.json',dict(source=source,method=method.name,methodSha256=method_sha,context=context.name,contextSha256=digest(context),createdAt=now(),singleLaunch=True))
    with (o/'controller.stdout.raw').open('xb') as out,(o/'controller.stderr.raw').open('xb') as err:
        child=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'run'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
    p=process(child.pid);assert p and p['uid']==1000
    record=dict(source=source,controllerPid=child.pid,controllerStartTicks=p['startTicks'],createdAt=now(),uid=1000,detachedSession=True,controllerScript=str(Path(__file__).resolve()),controllerScriptSha256=digest(Path(__file__)),launchedNotWaited=True)
    write('launch-result.json',record);print(json.dumps(record),flush=True)
elif mode=='run':
    signal.signal(signal.SIGHUP,signal.SIG_IGN)
    intent=json.loads((o/'launch-intent.json').read_bytes());assert intent['methodSha256']==digest(method)==method_sha and intent['contextSha256']==digest(context)
    self_=process(os.getpid());write('controller-started.json',dict(pid=os.getpid(),startTicks=self_['startTicks'],startedAt=now()))
    argv=[sys.executable,'-B',str(method),'--context',str(context)]
    with (o/'driver.stdout.raw').open('x',encoding='utf-8',buffering=1) as out,(o/'driver.stderr.raw').open('x',encoding='utf-8',buffering=1) as err:
        out.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n')
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        p=process(child.pid);assert p and p['uid']==1000
        write('driver-started.json',dict(source=source,pid=child.pid,startTicks=p['startTicks'],startedAt=now(),argv=argv,methodSha256=digest(method),contextSha256=digest(context)))
        code=child.wait();out.write('\nExit Code: '+str(code)+'\n')
    write('actual-terminal-wait.json',dict(source=source,pid=child.pid,actualWaitCompleted=True,exitCode=code,finishedAt=now(),methodSha256=digest(method),contextSha256=digest(context),stdoutSha256=digest(o/'driver.stdout.raw'),stderrSha256=digest(o/'driver.stderr.raw')))
    raise SystemExit(code)
else:
    launched=json.loads((o/'launch-result.json').read_bytes())
    output=dict(source=source,observedAt=now(),controller=public_process(launched['controllerPid'],launched['controllerStartTicks'],Path(__file__).resolve()))
    if (o/'driver-started.json').exists():
        d=json.loads((o/'driver-started.json').read_bytes());output['driver']=public_process(d['pid'],d['startTicks'],method)
    if (o/'actual-terminal-wait.json').exists():output['actualTerminal']=json.loads((o/'actual-terminal-wait.json').read_bytes())
    print(json.dumps(output),flush=True)
