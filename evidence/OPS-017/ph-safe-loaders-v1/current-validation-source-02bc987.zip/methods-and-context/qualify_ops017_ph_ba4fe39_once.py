from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,shlex,signal,subprocess,sys,xml.etree.ElementTree as ET
from live_github_transport import start_bridge
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;c=json.loads((t/'ops017-ph-safe-loaders-current-candidate.json').read_bytes());repo=Path('/home/sur/.cache/guize-takeover/ops017-ph-safe-loaders-'+c['source'][:7])
parser=argparse.ArgumentParser();parser.add_argument('--context',type=Path,required=True);args=parser.parse_args();context=json.loads(args.context.read_bytes())
assert context['kind']=='source' and context['checkout']==c['source']=='ba4fe395444cacbb3e9a786af76034b4e3e8a660'
assert c['base']=='d15d8e106aef844992caa183d866e95189a56776' and context['tree']==c['tree']=='044621f37dd4880cc209967de6975134e5fc4ce1'
assert context['localWorkflowMethod']==Path(__file__).name and context['localWorkflowMethodSha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
assert not repo.exists()
subprocess.run(['git','clone','--quiet','--branch',c['branch'],str(bundle),str(repo)],check=True)
subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
commands=json.loads((t/'ops017-scope-amendment-current-candidate.json').read_bytes())['commands']
c['commands']=[[x.replace('76be38c26dea26669819f142c572e69aac84c32b',c['base']).replace('chore/OPS-017-scope-amendment-v1',c['branch']) for x in row] for row in commands]
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before['head']==c['source'] and before['tree']==c['tree'] and not before['status'] and not (repo/'.git/objects/info/alternates').exists()
o=t/('ops017-ph-safe-loaders-'+c['source'][:7]+'-prepublication');o.mkdir()
os.environ.pop('PYTHONHOME',None);os.environ.pop('PUSH_BEFORE',None)
os.environ.update(PATH=str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF=c['branch'],GITHUB_BASE_REF='main',GITHUB_REF_NAME=c['branch'],GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
start_bridge(o)
r=dict(source=c['source'],base=c['base'],tree=c['tree'],before=before,python=sys.version,commands=[],startedAt=datetime.now(timezone.utc).isoformat(),source14Passed=False,componentsPassed=False,allNonFullCiChecksPassed=False,fullCiAccepted=False)
save=lambda:(o/'results.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(label,args):
    argv=([sys.executable,'-B',*args[1:]] if args[0]=='python' else ['git','-c','core.longpaths=true','-c','core.autocrlf=false',*args[1:]]) if args[0] in {'python','git'} else args
    row=dict(label=label,argv=argv,raw=label+'.raw',startedAt=datetime.now(timezone.utc).isoformat())
    with (o/row['raw']).open('x',encoding='utf-8',buffering=1) as out:
        out.write('Source Commit: '+c['source']+'\nCommand: '+shlex.join(argv)+'\n')
        p=subprocess.Popen(argv,cwd=repo,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;r['commands'].append(row);save()
        try:code=p.wait(timeout=1200)
        except subprocess.TimeoutExpired:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
            code=p.wait(timeout=30);row['timedOut']=True
        out.write('\nExit Code: '+str(code)+'\n')
    raw=(o/row['raw']).read_bytes();row.update(actualWaitCompleted=True,exitCode=code,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());save();print(label+': '+str(code),flush=True)
    if code:r['after']=state();save();raise SystemExit(code)
    return raw.decode('utf-8')
save()
for i,a in enumerate(c['commands']):run('declared-%02d'%i,a)
assert len(c['commands'])==14;r['source14Passed']=True;save()
run('compile',['python','-m','compileall','-q','scripts','tests'])
text=run('collect-original-plus-new',['python','-m','pytest','-p','no:cacheprovider','--collect-only','-q','tests/governance/'])
collected={x for x in text.splitlines() if x.startswith('tests/governance/') and '::' in x}
original={x for x in (t/'ops017-fatal-frontier-components-v1/original-collection.stdout.raw').read_text(encoding='utf-8').splitlines() if x.startswith('tests/governance/') and '::' in x}
assert len(original)==828 and len(collected)==842 and original<=collected and len(collected-original)==14
r.update(original828NodeSetPreserved=True,addedNodes=sorted(collected-original),collectedCases=842);save()
for label,args in [('secret-scan',['python','scripts/check-secrets.py']),('linkage',['python','scripts/check-pr-task-link.py','--branch',c['branch']]),('spec-sync',['python','scripts/check-spec-sync.py','--base','origin/main']),('parent-directory-references',['python','-c',"import pathlib,re; paths=[pathlib.Path('Makefile'),*pathlib.Path('scripts').rglob('*')]; bad=[str(p) for p in paths if p.is_file() and re.search(r'\\.\\./tests/|/workspace/tests/',p.read_text(encoding='utf-8',errors='replace'))]; print(bad); raise SystemExit(bool(bad))"]),('workflow-static',['python','tests/governance/test_repository_boundary.py','TestCIWorkflowStatic'])]:run(label,args)
reports=list((repo/'evidence/OPS-017').glob('final-report-r*.md'))
preferred=repo/'evidence/OPS-017/final-report-r5-clean-recovery.md'
if preferred.exists():report=preferred
elif reports:report=sorted(reports,key=lambda p:[int(z) if z.isdigit() else z for z in re.split(r'(\d+)',p.name)])[-1]
else:report=repo/'evidence/OPS-017/final-report.md'
if report.exists():run('evidence-integrity',['python','scripts/check-evidence-integrity.py','--task','OPS-017','--report',str(report.relative_to(repo))])
else:run('evidence-integrity-no-report',['python','-c',"print('No final-report*.md exists for OPS-017; no commit claims require integrity validation.')"])
run('related-components',['python','-m','pytest','-p','no:cacheprovider','-v','-ra','tests/governance/test_poc_contract_repair_admission.py','tests/governance/test_program_lifecycle_guards.py','tests/governance/test_program_plan_history.py','tests/governance/test_program_planning_revision.py','tests/governance/test_history_yaml_loader.py','--junitxml='+str(o/'components.xml')])
xml=ET.parse(o/'components.xml').getroot();cases=xml.findall('.//testcase');r.update(componentCases=len(cases),failures=len(xml.findall('.//failure')),errors=len(xml.findall('.//error')),skipped=len(xml.findall('.//skipped')))
assert r['componentCases']>=87 and all(r[k]==0 for k in ['failures','errors','skipped'])
run('component-skip-audit',['python','scripts/check-pytest-skips.py',str(o/'components.xml'),'tests/governance/allowed-skips.txt'])
assert before==state();r.update(after=state(),componentsPassed=True,allNonFullCiChecksPassed=True,finishedAt=datetime.now(timezone.utc).isoformat());save();print(json.dumps(dict(source=c['source'],declared14=True,original828Preserved=True,newCases=14,components=r['componentCases'],allNonFullCiChecksPassed=True,fullCiAccepted=False)),flush=True)
