from pathlib import Path
import json,os,shlex,subprocess,sys
from live_github_transport import start_bridge
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent;repo=Path('/home/sur/.cache/guize-takeover/ops017-ph-safe-loaders-ba4fe39')
source=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip();assert source=='ba4fe395444cacbb3e9a786af76034b4e3e8a660'
out=t/'ops017-ph-ba4fe39-latest-code-failure-reproduction';out.mkdir()
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF='chore/OPS-017-fast-yaml-loaders',GITHUB_BASE_REF='main',GITHUB_REF_NAME='chore/OPS-017-fast-yaml-loaders',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
os.environ.pop('PYTHONHOME',None);os.environ.pop('PUSH_BEFORE',None);start_bridge(out)
argv=[sys.executable,'-B','-m','pytest','-p','no:cacheprovider','-vv','--tb=long','tests/governance/test_poc_contract_repair_admission.py::TestProspectiveScopeAmendment::test_normal_completed_authority_uses_latest_ph_only_code_identity','--junitxml='+str(out/'junit.xml')]
with (out/'stdout.raw').open('x',encoding='utf-8',buffering=1) as raw:
    raw.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n')
    p=subprocess.Popen(argv,cwd=repo,stdout=raw,stderr=subprocess.STDOUT);code=p.wait();raw.write('\nExit Code: '+str(code)+'\n')
(out/'results.json').write_text(json.dumps(dict(source=source,pid=p.pid,actualWaitCompleted=True,exitCode=code,existingFailureReproduction=True,sourceModified=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print('\n'.join((out/'stdout.raw').read_text(encoding='utf-8').splitlines()[-100:]),flush=True)
raise SystemExit(code)
