"""Compare real source300 audits, then check the uncommitted history selector overlay."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, importlib.util, json, os, subprocess, sys, time
import xml.etree.ElementTree as ET

assert os.name == 'posix' and os.getuid() == 1000
t=Path(__file__).resolve().parent
c=json.loads((t/'ops017-review-boundary-fixed-current-candidate.json').read_bytes())
source=c['source']; assert source=='300df8cb643c39871cb189898521a2b216763fa9'
author=t/'ops017-source-compatibility-admission-v1'
proof='scripts/poc-contract-repair-admission.py'
test='tests/governance/test_poc_contract_repair_admission.py'
git=lambda root,*a:subprocess.check_output(['git','-C',str(root),*a]).decode().strip()
state=lambda root:dict(head=git(root,'rev-parse','HEAD'),status=git(root,'status','--porcelain=v1','--untracked-files=all'))
before=state(author)
assert before['head']==source and set(git(author,'diff','--name-only').splitlines())=={proof,test}
overlay={p:(author/p).read_bytes() for p in (proof,test)}
bundle=t/c['bundle']; assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
r=Path('/home/sur/.cache/guize-takeover/ops017-history-selection-perf300-v1')
out=t/'ops017-history-selection-perf300-v1'
assert not r.exists() and not out.exists()
subprocess.run(['git','clone','--quiet','--branch',c['branch'],str(bundle),str(r)],check=True)
assert git(r,'rev-parse','HEAD')==source and not (r/'.git/objects/info/alternates').exists()
out.mkdir()
report=dict(source=source,uncommittedDevelopmentOverlay=True,before=before,overlayPins={p:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for p,v in overlay.items()},auditComparisons=[],phases=[],component62Passed=False,fullSourceAccepted=False)
save=lambda:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
def load(label):
    spec=importlib.util.spec_from_file_location('perf_proof_'+label,r/proof)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module
def measure(module,base):
    real=module.git; calls=Counter()
    def observed(root,*args):
        calls[args[0]]+=1
        return real(root,*args)
    module.git=observed
    tick=time.monotonic_ns()
    try: module.audit_source_authority_intent(str(r),base,source)
    finally: module.git=real
    return dict(accepted=True,elapsedNs=time.monotonic_ns()-tick,gitCalls=dict(calls),gitCallCount=sum(calls.values()))
old=load('old')
reservation_parent=json.loads((r/old.SOURCE_COMPATIBILITY.intent).read_bytes())['reservationParent']
for base in (c['base'],reservation_parent):
    report['auditComparisons'].append(dict(base=base,old=measure(old,base)))
    save()
(r/test).write_bytes(overlay[test])
def phase(label,selection,expected):
    argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q',*selection,'--durations=12','--junitxml='+str(out/(label+'.xml'))]
    row=dict(label=label,argv=argv,startedAt=datetime.now(timezone.utc).isoformat())
    tick=time.monotonic_ns()
    with (out/(label+'.raw')).open('xb') as raw:
        child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        row['pid']=child.pid; report['phases'].append(row); save()
        code=child.wait()
    data=(out/(label+'.raw')).read_bytes()
    row.update(exitCode=code,actualWaitCompleted=True,elapsedNs=time.monotonic_ns()-tick,rawBytes=len(data),rawSha256=hashlib.sha256(data).hexdigest())
    if (out/(label+'.xml')).exists():
        cases=list(ET.parse(out/(label+'.xml')).getroot().iter('testcase'))
        row.update(tests=len(cases),failures=[v.attrib['name'] for v in cases if v.find('failure') is not None],errors=[v.attrib['name'] for v in cases if v.find('error') is not None],skips=[v.attrib['name'] for v in cases if v.find('skipped') is not None])
    save(); print(json.dumps(row),flush=True)
    assert code==0 and row['tests']==expected and not row['failures'] and not row['errors'] and not row['skips']
phase('original300-side-history',[test+'::TestSourceCompatibilityRepairAdmission::test_treesame_merge_cannot_hide_side_branch_intent_edit_and_restore'],1)
(r/proof).write_bytes(overlay[proof])
new=load('new')
for comparison in report['auditComparisons']:
    base=comparison['base']; comparison['new']=measure(new,base)
    all_nodes=git(r,'rev-list','--reverse',base+'..'+source).splitlines()
    records=git(r,'rev-list','--full-history','--parents','--reverse',base+'..'+source,'--',new.SOURCE_COMPATIBILITY.intent).splitlines()
    candidates={v.split()[0] for v in records}
    changed_nodes={node for node in all_nodes if new.SOURCE_COMPATIBILITY.intent in new.changed(str(r),new.parent(str(r),node),node)}
    assert changed_nodes <= candidates
    assert comparison['new']['gitCallCount'] < comparison['old']['gitCallCount']
    comparison.update(introducedNodes=len(all_nodes),selectedNodes=len(candidates),originalFirstParentIntentChangeNodes=sorted(changed_nodes),allOriginalChangedNodesRetained=True)
    save(); print(json.dumps(comparison),flush=True)
phase('complete62',[test],62)
assert state(author)==before and all((author/p).read_bytes()==raw for p,raw in overlay.items())
report.update(component62Passed=True,authorContextUnchanged=True,after=state(author),finishedAt=datetime.now(timezone.utc).isoformat())
save(); print(json.dumps(dict(component62Passed=True,fullSourceAccepted=False)),flush=True)
