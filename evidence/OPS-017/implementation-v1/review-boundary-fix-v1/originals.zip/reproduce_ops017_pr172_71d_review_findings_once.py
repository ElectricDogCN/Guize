"""Independent bounded synthetic-Git reproductions; never edit an author repo."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import traceback

SOURCE = '71d720f6cc4ee23c532413e6d13c3ef58eb031a3'
ROOT = Path('/home/sur/.cache/guize-takeover/ops017-current-source7996-71d720f')
D = Path(__file__).resolve().parent
OUT = D / 'ops017-pr172-71d-independent-reproduction-v1'
AUTHOR = D / 'ops017-source-compatibility-admission-v1'
utc = lambda: datetime.now(timezone.utc).isoformat()
sha = lambda b: hashlib.sha256(b).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', '-c', 'core.longpaths=true', '-C', str(repo), *args])


def state(repo):
    return {k: git(repo, *args).decode().strip() for k, args in {
        'head': ('rev-parse', 'HEAD'), 'status': ('status', '--porcelain=v1', '--untracked-files=all'),
        'refs': ('for-each-ref', '--format=%(refname) %(objectname)')}.items()}


def write_json(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def cli(case_dir, fixture, base, head, branch):
    argv = [sys.executable, '-B', str(ROOT / 'scripts/check-program-lifecycle-guards.py'),
            '--repo-root', str(fixture), '--base-ref', base, '--head-ref', head,
            '--branch-name', branch]
    started = utc()
    with (case_dir / 'lifecycle.stdout.raw').open('xb') as out, (case_dir / 'lifecycle.stderr.raw').open('xb') as err:
        out.write(('Source Commit: ' + SOURCE + '\nCommand: ' + shlex.join(argv) + '\n').encode()); out.flush()
        child = subprocess.Popen(argv, cwd=fixture, stdout=out, stderr=err)
        code = child.wait()
        out.write(('\nExit Code: ' + str(code) + '\n').encode())
    stdout = (case_dir / 'lifecycle.stdout.raw').read_bytes()
    stderr = (case_dir / 'lifecycle.stderr.raw').read_bytes()
    r = dict(argv=argv, pid=child.pid, actualWaitCompleted=True, exitCode=code,
             startedAt=started, finishedAt=utc(), stdoutBytes=len(stdout), stdoutSha256=sha(stdout),
             stderrBytes=len(stderr), stderrSha256=sha(stderr))
    write_json(case_dir / 'lifecycle.json', r)
    return r, (stdout + stderr).decode('utf-8')


def one_case(name):
    case_dir = OUT / name
    case_dir.mkdir()
    spec = importlib.util.spec_from_file_location('ops017_independent_git_fixture',
        ROOT / 'tests/governance/test_poc_contract_repair_admission.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    C = module.TestSourceCompatibilityRepairAdmission
    C.setUpClass()
    t = C('test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration')
    try:
        t.setUp()
        P = module.PROOF
        result = dict(case=name, syntheticFixtureOnly=True, source=SOURCE, fixture=str(t.repo),
                      originalAuthorityReservation=C.reservation, authorityCompletion=t.completed)
        if name == 'clean_peer_import':
            registration = t.register()
            t.git(t.repo, 'checkout', '--detach', C.activation)
            t.write(t.repo, 'evidence/POC-005/independent-clean-sync-fixture.txt', 'Independent peer evidence.\n')
            peer = t.commit(t.repo, 'POC-005 fixture peer before authority Completion')
            merge = subprocess.run(['git', '-C', str(t.repo), 'merge', '--no-ff', registration,
                                    '-m', 'POC-005 fixture clean import of admitted main'], capture_output=True)
            (case_dir / 'merge.stdout.raw').write_bytes(merge.stdout)
            (case_dir / 'merge.stderr.raw').write_bytes(merge.stderr)
            if merge.returncode:
                raise RuntimeError('Synthetic clean import merge failed: ' + merge.stderr.decode())
            observed = t.git(t.repo, 'rev-parse', 'HEAD')
            chosen = P.introduction(str(t.repo), P.chain(str(t.repo), observed), 'OPS-018')
            actual, output = cli(case_dir, t.repo, registration, observed, 'chore/POC-005-fixture-sync')
            result.update(admittedBase=registration, peerBeforeMerge=peer, actualMerge=observed,
                          inferredIntroduction=chosen[0], inferredAdmissionParent=P.parent(str(t.repo), chosen[0]),
                          actualLifecycle=actual, confirmed=actual['exitCode'] != 0 and
                          'Authority has not normally completed and released capacity' in output,
                          expectedValidCleanImport=True)
        elif name == 'target_edit_restore_before_admission':
            target = 'docs/18-testing-and-acceptance.md'
            path = Path(t.repo, target); original = path.read_bytes()
            path.write_bytes(original + b'\nIndependent premature target change.\n')
            changed = t.commit(t.repo, 'Fixture target change after Completion before admission')
            path.write_bytes(original)
            restored = t.commit(t.repo, 'Fixture target restored before successor registration')
            t.entry['baseSha'] = restored
            registration = t.register()
            accepted = t.claims(base=registration)
            result.update(target=target, originalBytesSha256=sha(original), changed=changed,
                          restored=restored, actualSuccessorReservation=registration,
                          actualApprovedClaims=sorted(accepted),
                          actualCall='PROOF.prove_claims(repo, OPS-018, entry, actualSuccessorReservation)',
                          confirmed=accepted == P.SOURCE_COMPATIBILITY.paths,
                          expectedHistoryPreservationDenial=True)
        elif name == 'intent_edit_before_successor_registration':
            path = Path(t.repo, P.SOURCE_COMPATIBILITY.intent); original = path.read_bytes()
            path.write_bytes(original + b'\n')
            altered = t.commit(t.repo, 'OPS-017 fixture forbidden pre-successor intent edit')
            assert P.entry_at(str(t.repo), altered, 'OPS-018') is None
            actual, output = cli(case_dir, t.repo, t.completed, altered,
                                 'chore/OPS-017-fixture-evidence-correction')
            path.write_bytes(original)
            restored = t.commit(t.repo, 'OPS-017 fixture restore original intent after admitted edit')
            rejected = None
            try:
                t.claims(base=restored, entry=dict(t.entry, baseSha=restored))
            except P.AdmissionError as exc:
                rejected = str(exc)
            result.update(altered=altered, restored=restored, actualLifecycle=actual,
                          laterAdmissionError=rejected, confirmed=actual['exitCode'] == 0 and
                          rejected is not None and 'Authorization intent changed after registration' in rejected,
                          expectedImmediateImmutableIntentDenial=True)
        else:
            raise ValueError(name)
        graph = git(t.repo, 'log', '--graph', '--format=%H %P %s', C.reservation + '..HEAD')
        (case_dir / 'graph.raw').write_bytes(graph)
        result['graphSha256'] = sha(graph)
        write_json(case_dir / 'case.json', result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
    finally:
        t.doCleanups()
        C.tearDownClass()


def main():
    assert os.name == 'posix' and os.getuid() == 1000
    assert git(ROOT, 'rev-parse', 'HEAD').decode().strip() == SOURCE
    parser = argparse.ArgumentParser(); parser.add_argument('--case')
    args = parser.parse_args()
    if args.case:
        one_case(args.case)
        return
    OUT.mkdir()
    before = dict(nativeSource=state(ROOT), author=state(AUTHOR))
    results = dict(source=SOURCE, uid=os.getuid(), startedAt=utc(), methodSha256=sha(Path(__file__).read_bytes()),
                   before=before, cases=[], syntheticFixturesOnly=True, authorMutationAllowed=False)
    write_json(OUT / 'launch.json', results)
    for name in ['clean_peer_import', 'target_edit_restore_before_admission', 'intent_edit_before_successor_registration']:
        argv = [sys.executable, '-B', str(Path(__file__).resolve()), '--case', name]
        started = utc()
        with (OUT / (name + '.stdout.raw')).open('xb') as out, (OUT / (name + '.stderr.raw')).open('xb') as err:
            out.write(('Source Commit: ' + SOURCE + '\nCommand: ' + shlex.join(argv) + '\n').encode()); out.flush()
            child = subprocess.Popen(argv, stdout=out, stderr=err)
            code = child.wait()
            out.write(('\nExit Code: ' + str(code) + '\n').encode())
        raw = (OUT / (name + '.stdout.raw')).read_bytes()
        results['cases'].append(dict(case=name, argv=argv, pid=child.pid, actualWaitCompleted=True,
                                    exitCode=code, startedAt=started, finishedAt=utc(),
                                    stdoutBytes=len(raw), stdoutSha256=sha(raw)))
        print(json.dumps(results['cases'][-1]), flush=True)
    results.update(finishedAt=utc(), after=dict(nativeSource=state(ROOT), author=state(AUTHOR)))
    results['sourceAndAuthorUnchanged'] = results['before'] == results['after']
    write_json(OUT / 'results.json', results)
    assert results['sourceAndAuthorUnchanged']
    assert all(x['exitCode'] == 0 and x['actualWaitCompleted'] for x in results['cases'])


if __name__ == '__main__':
    main()
