"""Check the forward three-file boundary fix, first five regressions then the complete61-case component."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
author=t/'ops017-source-compatibility-admission-v1'
source='71d720f6cc4ee23c532413e6d13c3ef58eb031a3'
test='tests/governance/test_poc_contract_repair_admission.py'
paths=['scripts/poc-contract-repair-admission.py','scripts/check-program-lifecycle-guards.py',test]
git=lambda root,*a:subprocess.check_output(['git','-C',str(root),*a]).decode().strip()
state=lambda root:dict(head=git(root,'rev-parse','HEAD'),status=git(root,'status','--porcelain=v1','--untracked-files=all'))
before=state(author)
assert before['head']==source and set(git(author,'diff','--name-only').splitlines())==set(paths)
overlay={path:(author/path).read_bytes() for path in paths}
c=json.loads((t/'ops017-current-source-7996-candidate.json').read_bytes())
bundle=t/c['bundle']
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
r=Path('/home/sur/.cache/guize-takeover/ops017-review-boundary-green71-v1')
assert not r.exists()
subprocess.run(['git','clone','--quiet','--branch',c['branch'],str(bundle),str(r)],check=True)
assert git(r,'rev-parse','HEAD')==source
for path,raw in overlay.items():(r/path).write_bytes(raw)
out=t/'ops017-review-boundary-green71-v1'
out.mkdir()
names=['test_clean_peer_import_authenticates_the_admitted_successor_history','test_peer_import_cannot_erase_a_local_authority_intent_attack','test_peer_cannot_admit_a_successor_from_an_unadmitted_side_parent','test_target_edit_restore_between_completion_and_successor_reservation_is_denied','test_actual_pre_successor_intent_attack_is_rejected_when_submitted']
report=dict(baseSource=source,uncommittedDevelopmentOverlay=True,sourceQualified=False,before=before,overlayPins={path:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for path,raw in overlay.items()},phases=[],component61Passed=False)
save=lambda:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for label,selected,count in [('boundary5',[test+'::TestSourceCompatibilityRepairAdmission::'+name for name in names],5),('complete61',[test],61)]:
    argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q',*selected,'--junitxml='+str(out/(label+'.xml'))]
    phase=dict(label=label,argv=argv,startedAt=datetime.now(timezone.utc).isoformat())
    with (out/(label+'.raw')).open('xb') as raw:
        child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        phase['pid']=child.pid;report['phases'].append(phase);save()
        code=child.wait()
    data=(out/(label+'.raw')).read_bytes()
    phase.update(exitCode=code,actualWaitCompleted=True,finishedAt=datetime.now(timezone.utc).isoformat(),rawBytes=len(data),rawSha256=hashlib.sha256(data).hexdigest())
    if (out/(label+'.xml')).exists():
        cases=list(ET.parse(out/(label+'.xml')).getroot().iter('testcase'))
        phase.update(tests=len(cases),failures=[x.attrib['name'] for x in cases if x.find('failure') is not None],errors=[x.attrib['name'] for x in cases if x.find('error') is not None],skips=[x.attrib['name'] for x in cases if x.find('skipped') is not None])
    save()
    print(json.dumps(phase),flush=True)
    assert code==0 and phase['tests']==count and not phase['failures'] and not phase['errors'] and not phase['skips']
assert state(author)==before and all((author/path).read_bytes()==raw for path,raw in overlay.items())
report.update(after=state(author),authorContextUnchanged=True,component61Passed=True,finishedAt=datetime.now(timezone.utc).isoformat())
save()
print(json.dumps(dict(component61Passed=True,authorContextUnchanged=True,fullSourceAccepted=False)),flush=True)
