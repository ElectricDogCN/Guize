"""Run only five new real-Git regressions against unchanged71d code; preserve expected red output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
author=t/'ops017-source-compatibility-admission-v1'
source='71d720f6cc4ee23c532413e6d13c3ef58eb031a3'
path='tests/governance/test_poc_contract_repair_admission.py'
testbytes=(author/path).read_bytes()
git=lambda root,*a:subprocess.check_output(['git','-C',str(root),*a]).decode().strip()
assert git(author,'rev-parse','HEAD')==source
assert git(author,'diff','--name-only').splitlines()==[path]
c=json.loads((t/'ops017-current-source-7996-candidate.json').read_bytes())
bundle=t/c['bundle']
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
r=Path('/home/sur/.cache/guize-takeover/ops017-review-boundary-red71-v1')
assert not r.exists()
subprocess.run(['git','clone','--quiet','--branch',c['branch'],str(bundle),str(r)],check=True)
assert git(r,'rev-parse','HEAD')==source
(r/path).write_bytes(testbytes)
out=t/'ops017-review-boundary-red71-v1'
out.mkdir()
names=['test_clean_peer_import_authenticates_the_admitted_successor_history','test_peer_import_cannot_erase_a_local_authority_intent_attack','test_peer_cannot_admit_a_successor_from_an_unadmitted_side_parent','test_target_edit_restore_between_completion_and_successor_reservation_is_denied','test_actual_pre_successor_intent_attack_is_rejected_when_submitted']
argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q',*[path+'::TestSourceCompatibilityRepairAdmission::'+name for name in names],'--junitxml='+str(out/'junit.xml')]
started=datetime.now(timezone.utc).isoformat()
with (out/'suite.raw').open('xb') as raw:
    child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    (out/'launch.json').write_text(json.dumps(dict(source=source,argv=argv,pid=child.pid,startedAt=started,testsSha256=hashlib.sha256(testbytes).hexdigest(),expectedRed=True),indent=2)+'\n',encoding='utf-8',newline='\n')
    code=child.wait()
cases=list(ET.parse(out/'junit.xml').getroot().iter('testcase'))
failed=[x.attrib['name'] for x in cases if x.find('failure') is not None]
errors=[x.attrib['name'] for x in cases if x.find('error') is not None]
skips=[x.attrib['name'] for x in cases if x.find('skipped') is not None]
expected={names[0],names[3],names[4]}
data=(out/'suite.raw').read_bytes()
result=dict(source=source,testFileSha256=hashlib.sha256(testbytes).hexdigest(),argv=argv,pid=child.pid,actualWaitCompleted=True,pytestExitCode=code,totalTests=len(cases),failures=failed,errors=errors,skips=skips,expectedFailures=sorted(expected),baselineDefectsReproduced=set(failed)==expected and not errors and not skips,sourceScriptsUnchanged=True,startedAt=started,finishedAt=datetime.now(timezone.utc).isoformat(),rawBytes=len(data),rawSha256=hashlib.sha256(data).hexdigest(),fullSuitePassed=False)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
assert git(author,'rev-parse','HEAD')==source and (author/path).read_bytes()==testbytes
assert code==1 and len(cases)==5 and set(failed)==expected and not errors and not skips
print(json.dumps(result),flush=True)
