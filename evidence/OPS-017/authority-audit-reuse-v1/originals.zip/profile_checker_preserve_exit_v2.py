"""cProfile wrapper retaining the checker's real SystemExit status and argv."""
import cProfile,runpy,sys

profile_path,script,*arguments=sys.argv[1:]
sys.argv=[script,*arguments]
profile=cProfile.Profile()
try:
    profile.enable()
    runpy.run_path(script,run_name='__main__')
finally:
    profile.disable()
    profile.dump_stats(profile_path)
