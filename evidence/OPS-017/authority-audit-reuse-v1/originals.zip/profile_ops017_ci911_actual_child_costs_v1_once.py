"""Bounded diagnosis of three existing cases, with child checker CPU profiles.

This instrumentation is external to the source checkout and grants no gate,
full-CI, performance or experiment acceptance. No assertion is changed.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,pstats,subprocess,sys,time
import pytest

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
repo=Path('/home/sur/.cache/guize-takeover/ops017-historical-authority-fixture-source877-3396b93')
source='3396b93e880cbfc42b86128e64bc362c827195ca'
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
state=lambda:dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before==dict(source=source,tree='f093b7a81e36f62a6080f864026578ca9f9870f8',status='')
out=t/'ops017-ci911-attempt2-bounded-child-profile-v1';out.mkdir()
targets=['tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_missing_review_base','tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_legal_rework_metadata','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair']
original_run=subprocess.run
records=[]
checkers={'check-program-plan-history.py','check-program-lifecycle-guards.py'}
def diagnosed_run(argv,*args,**kwargs):
    if isinstance(argv,(list,tuple)) and len(argv)>1 and Path(str(argv[1])).name in checkers:
        index=len(records);profile=out/f'child-{index:02d}.pstats'
        actual=[argv[0],'-X','utf8','-B','-m','cProfile','-o',str(profile),*argv[1:]]
        row=dict(originalArgv=list(map(str,argv)),diagnosticArgv=list(map(str,actual)),profile=profile.name,startedAt=datetime.now(timezone.utc).isoformat())
        records.append(row);tick=time.monotonic_ns()
        result=original_run(actual,*args,**dict(kwargs,timeout=180))
        row.update(returncode=result.returncode,elapsedNs=time.monotonic_ns()-tick)
        stats=pstats.Stats(str(profile));functions=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in stats.stats.items()]
        row['topSelfTime']=sorted(functions,key=lambda v:v['selfSeconds'],reverse=True)[:16]
        row['yamlLoadFunctions']=[v for v in functions if v['function'] in {'load','safe_load','load_yaml_text','load_ref','load_current','document'} and ('yaml/' in v['file'] or '/scripts/' in v['file'])]
        return result
    return original_run(argv,*args,**kwargs)

if '--execute-child' in sys.argv:
    os.chdir(repo);subprocess.run=diagnosed_run
    code=pytest.main(['-q','--junitxml='+str(out/'diagnostic-junit.xml'),*targets])
    (out/'child-costs.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    raise SystemExit(code)

# The child needs the same output directory without ever overwriting an old run.
PYTHON=sys.executable
plugin=t/'ops017_ci911_child_profile_instrumentation_v1.py'
assert not plugin.exists()
plugin.write_text(Path(__file__).read_text().replace("out=t/'ops017-ci911-attempt2-bounded-child-profile-v1';out.mkdir()", "out=t/'ops017-ci911-attempt2-bounded-child-profile-v1';assert out.is_dir()"),encoding='utf-8',newline='\n')
argv=[PYTHON,'-X','utf8','-B',str(plugin),'--execute-child']
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    try:code=child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        child.terminate();code=child.wait();raise
after=state();assert after==before
result=dict(kind='BOUNDED_EXISTING_CASE_CHILD_CPU_DIAGNOSIS_ONLY',source=source,before=before,after=after,sourceContextUnchanged=True,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code,existingCases=targets,childCosts=json.loads((out/'child-costs.json').read_bytes()),raw={n:dict(bytes=(out/n).stat().st_size,sha256=hashlib.sha256((out/n).read_bytes()).hexdigest()) for n in ['stdout.raw','stderr.raw','diagnostic-junit.xml']},fullCiAccepted=False,codeModified=False,thirdCiRetryAllowed=False,finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(source=source,existingCases=3,profiledCheckerCalls=len(result['childCosts']),actualWaitCompleted=True,exitCode=code,sourceContextUnchanged=True)),flush=True)
raise SystemExit(code)
