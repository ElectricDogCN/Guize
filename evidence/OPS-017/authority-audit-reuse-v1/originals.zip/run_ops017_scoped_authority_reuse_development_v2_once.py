"""Exercise a pinned uncommitted overlay; never qualify a new source commit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
author=t/'ops017-source-compatibility-admission-v1'
source='3396b93e880cbfc42b86128e64bc362c827195ca'
bundle=t/'ops017-historical-authority-fixture-3396b93.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='cb556f386b9b0feae679f482dfef984e7c5e4e03be1f53a5d6861c14caaf502d'
pins={'scripts/poc-contract-repair-admission.py':'b13c27a21945802c3e4c8e7f2f7a73044e52ea923db8cb885f3716c25f5b7d10','scripts/check-program-lifecycle-guards.py':'3ad375207c6ebdeb5d007031c779e4eb17319d824e6c6fb879bf0dc398b2f13b','tests/governance/test_poc_contract_repair_admission.py':'0b0eec988183499cab9e070f468fe04a8d6d430dc5053fcaea16967b1db99490'}
out=t/'ops017-scoped-authority-reuse-development-v2';out.mkdir()
repo=Path('/home/sur/.cache/guize-takeover/ops017-scoped-authority-reuse-development-v2');assert not repo.exists()
subprocess.run(['git','clone','--quiet','--branch','chore/OPS-017-source-compatibility-admission',str(bundle),str(repo)],check=True)
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain=v1','--untracked-files=all')
for path,pin in pins.items():
    raw=(author/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin
    (repo/path).write_bytes(raw);(out/(Path(path).name+'.overlay')).write_bytes(raw)
state=lambda:dict(source=git('rev-parse','HEAD'),status=git('status','--porcelain=v1','--untracked-files=all'),pins={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in pins})
before=state();assert before['pins']==pins
selected=['tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_missing_review_base','tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_legal_rework_metadata','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration']
result=dict(kind='PINNED_UNCOMMITTED_OVERLAY_COMPONENT_DEVELOPMENT_ONLY',baseSource=source,pins=pins,before=before,commands=[],sourceQualified=False,fullCiAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for label,tests,count in [('focused-existing-four',selected,4),('all-existing-governance828',['tests/governance'],828)]:
    junit=out/(label+'.xml');argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q','--junitxml='+str(junit),*tests]
    row=dict(label=label,argv=argv,expectedExistingCases=count,startedAt=datetime.now(timezone.utc).isoformat());tick=time.monotonic_ns()
    with (out/(label+'.stdout.raw')).open('xb') as stdout,(out/(label+'.stderr.raw')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        row['pid']=child.pid;result['commands'].append(row);save();code=child.wait()
    row.update(exitCode=code,actualWaitCompleted=True,elapsedNs=time.monotonic_ns()-tick,raw={n:dict(bytes=(out/n).stat().st_size,sha256=hashlib.sha256((out/n).read_bytes()).hexdigest()) for n in [label+'.stdout.raw',label+'.stderr.raw',junit.name]});save()
    print(label+': exit '+str(code),flush=True)
    if code:result.update(after=state());save();raise SystemExit(code)
    suites=list(ET.parse(junit).getroot().iter('testsuite'));assert sum(int(s.attrib['tests']) for s in suites)==count
    assert all(int(s.attrib.get(k,0))==0 for s in suites for k in ['failures','errors','skipped'])
cases=list(ET.parse(out/'all-existing-governance828.xml').getroot().iter('testcase'))
assert len([v for v in cases if 'test_poc_contract_repair_admission' in v.attrib.get('classname','')])==62
assert state()==before
result.update(after=state(),sourceContextUnchanged=True,focusedFourPassed=True,existingComponent62Passed=True,fullExistingGovernance828Passed=True,finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({'baseSource':source,'overlayOnly':True,'focusedFourPassed':True,'existingComponent62Passed':True,'fullExistingGovernance828Passed':True,'sourceContextUnchanged':True}),flush=True)
