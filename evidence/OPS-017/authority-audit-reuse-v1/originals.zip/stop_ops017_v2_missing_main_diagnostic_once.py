"""Gracefully stop only our exact invalid-context pytest; retain all originals."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,signal,subprocess

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent;out=t/'ops017-scoped-authority-reuse-development-v2'
record=json.loads((out/'results.json').read_bytes());row=record['commands'][-1]
assert row['label']=='all-existing-governance828' and 'exitCode' not in row and row['pid']==832907
pid=row['pid'];process=Path('/proc')/str(pid)
assert process.joinpath('cwd').resolve()==Path('/home/sur/.cache/guize-takeover/ops017-scoped-authority-reuse-development-v2')
actual=[v.decode() for v in process.joinpath('cmdline').read_bytes().split(b'\0') if v]
assert actual==row['argv']
repo=process.joinpath('cwd').resolve()
missing={ref:subprocess.run(['git','-C',str(repo),'show-ref','--verify','--quiet',ref]).returncode for ref in ['refs/heads/main','refs/remotes/origin/main']}
assert all(v!=0 for v in missing.values()),missing
intent=out/'invalid-main-context-graceful-stop.json';assert not intent.exists()
intent.write_text(json.dumps(dict(pid=pid,actualArgv=actual,missingCanonicalRefs=missing,signal='SIGINT',reason='One actual project-readiness test failed because the diagnostic clone omitted real canonical main refs; preserve negative context, do not mutate this live checkout',wholeSuiteAccepted=False,requestedAt=datetime.now(timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
os.kill(pid,signal.SIGINT)
print(json.dumps({'signalSentToExactOwnPytest':pid,'canonicalRefsNotChanged':True,'negativeOriginalsRetained':True}),flush=True)
