from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,subprocess
import yaml
assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
original=Path('/home/sur/.cache/guize-takeover/ops017-ci917-actual-checkout-profile-09c9adf')
overlay=Path('/home/sur/.cache/guize-takeover/ops017-ci917-safe-loader-overlay-profile-v1')
out=t/'ops017-lifecycle-safe-loader-parity-v1';assert not out.exists();(out/'corpus').mkdir(parents=True)
git=lambda root,*a:subprocess.check_output(['git','-C',str(root),*a])
state=lambda root:dict(head=git(root,'rev-parse','HEAD').decode().strip(),tree=git(root,'rev-parse','HEAD^{tree}').decode().strip(),diff=hashlib.sha256(git(root,'diff','--binary')).hexdigest(),status=git(root,'status','--porcelain=v1','--untracked-files=all').decode())
before=[state(original),state(overlay)]
assert all(row['head']=='09c9adff551bdcc45597cf9327cae3335c7f9c75' for row in before)
assert before[0]['status']=='' and len(before[1]['status'].splitlines())==1
def module(root,name):
    spec=importlib.util.spec_from_file_location(name,root/'scripts/check-program-lifecycle-guards.py')
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
old=module(original,'original_lifecycle_parser');new=module(overlay,'overlay_lifecycle_parser')
cases=[]
for path in ['specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml','specs/coordination/task-completions.yaml','specs/designs/module-ownership.yaml']:
    raw=git(original,'show','HEAD:'+path);cases.append((path,raw.decode(),hashlib.sha256(raw).hexdigest()))
for path in git(original,'ls-tree','-r','--name-only','HEAD','specs/tasks').decode().splitlines():
    if not path.endswith('.md'):continue
    raw=git(original,'show','HEAD:'+path);text=raw.decode();parts=text.split('---',2)
    if len(parts)==3 and text.startswith('---'):cases.append((path+'#front',parts[1],hashlib.sha256(raw).hexdigest()))
for index,text in enumerate(['','\n','null\n','true\n','[1, two, null]\n','a: 1\na: 2\n','a: &x [1, 2]\nb: *x\n','name: 归泽\nquoted: "with space"\n','date: 2026-10-30\n','tasks: [\n','x: !unknown value\n','a: 1\n---\nb: 2\n','invalid: \0\n']):cases.append(('synthetic/'+str(index),text,None))
def observe(call):
    try:
        value=call();return dict(accepted=True,digest=hashlib.sha256(repr(value).encode()).hexdigest()),value
    except Exception as exc:
        family='yaml.YAMLError' if isinstance(exc,yaml.YAMLError) else type(exc).__name__
        return dict(accepted=False,family=family,errorType=type(exc).__name__),None
rows=[];mismatches=[];type_differences=[]
backend=new.SAFE_DOCUMENT_LOADER
for index,(label,text,source_sha) in enumerate(cases):
    filename=str(index)+'.yaml';(out/'corpus'/filename).write_text(text,encoding='utf-8',newline='\n')
    for method in ['load_yaml_text','load_current','parse_front']:
        def invoke(value):
            if method=='load_current':return value.load_current(str(out/'corpus'),filename)
            if method=='parse_front':return value.parse_front('---\n'+text+'\n---\nParity body\n')
            return value.load_yaml_text(text)
        baseline,bvalue=observe(lambda:invoke(old));fast,fvalue=observe(lambda:invoke(new))
        new.SAFE_DOCUMENT_LOADER=yaml.SafeLoader
        fallback,pvalue=observe(lambda:invoke(new));new.SAFE_DOCUMENT_LOADER=backend
        equal=lambda a,av,b,bv:a['accepted']==b['accepted'] and (av==bv if a['accepted'] else a['family']==b['family'])
        same=equal(baseline,bvalue,fast,fvalue) and equal(baseline,bvalue,fallback,pvalue)
        row=dict(label=label,method=method,sourceRawSha256=source_sha,inputSha256=hashlib.sha256(text.encode()).hexdigest(),legacy=baseline,fast=fast,fallback=fallback,semanticEqual=same);rows.append(row)
        if not same:mismatches.append(dict(label=label,method=method))
        if not baseline['accepted'] and baseline['errorType']!=fast.get('errorType'):type_differences.append(dict(label=label,method=method,legacy=baseline['errorType'],fast=fast.get('errorType')))
after=[state(original),state(overlay)];assert after==before
result=dict(kind='ISOLATED_UNCOMMITTED_LOADER_SEMANTIC_PARITY_ONLY',source=before[0]['head'],originalAndOverlayBefore=before,originalAndOverlayAfter=after,sourceContextsUnchanged=True,loaderBackend=backend.__name__,corpusDocuments=len(cases),comparisons=len(rows),mismatches=mismatches,rejectedYamlExceptionSubtypeDifferences=type_differences,allComparedSemanticOutcomesEqual=not mismatches,rows=rows,productionEdited=False,fullCiAccepted=False,createdAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['loaderBackend','corpusDocuments','comparisons','mismatches','rejectedYamlExceptionSubtypeDifferences','sourceContextsUnchanged','allComparedSemanticOutcomesEqual']}),flush=True)
raise SystemExit(bool(mismatches))
