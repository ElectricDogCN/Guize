from pathlib import Path
from datetime import datetime,timezone
from live_github_transport import start_bridge
import hashlib,json,os,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
original=Path('/home/sur/.cache/guize-takeover/ops017-ci917-actual-checkout-profile-09c9adf')
repo=Path('/home/sur/.cache/guize-takeover/ops017-safe-loader-regression-components-v1')
out=t/'ops017-safe-loader-regression-components-v1'
assert not repo.exists() and not out.exists();out.mkdir()
c=json.loads((t/'ops017-ci917-actual-checkout-diagnostic-candidate.json').read_bytes())
overlay=t/'ops017-lifecycle-safe-loader-regression-overlay-v1';manifest=json.loads((overlay/'overlay.json').read_bytes())
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
subprocess.run(['git','clone','--quiet','--branch',c['diagnosticBranch'],str(bundle),str(repo)],check=True)
subprocess.run(['git','-C',str(repo),'branch','main',c['base']],check=True)
subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
subprocess.run(['git','-C',str(repo),'checkout','--detach','--quiet',c['source']],check=True)
assert not (repo/'.git/objects/info/alternates').exists()
git=lambda root,*a:subprocess.check_output(['git','-C',str(root),*a])
for path,pin in manifest['files'].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==pin['originalSha256']
    assert hashlib.sha256((overlay/path).read_bytes()).hexdigest()==pin['sha256']
    shutil.copyfile(overlay/path,repo/path)
state=lambda root:dict(source=git(root,'rev-parse','HEAD').decode().strip(),tree=git(root,'rev-parse','HEAD^{tree}').decode().strip(),status=git(root,'status','--porcelain=v1','--untracked-files=all').decode(),diffSha256=hashlib.sha256(git(root,'diff','--binary')).hexdigest())
before=[state(original),state(repo)];assert before[0]['status']=='' and len(before[1]['status'].splitlines())==2
assert all(v['source']==c['source'] for v in before)
assert git(repo,'rev-parse','main').decode().strip()==git(repo,'rev-parse','origin/main').decode().strip()==c['base']
os.environ.update(PATH=str(Path(sys.executable).parent)+':'+os.environ['PATH'],GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF='chore/OPS-017-source-compatibility-admission',GITHUB_BASE_REF='main',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request',GITHUB_REF='refs/pull/176/merge',PYTHONDONTWRITEBYTECODE='1')
start_bridge(out)
result=dict(kind='UNCOMMITTED_SAFE_LOADER_COMPONENTS_ONLY',actualDiagnosticCheckout=c['source'],overlay=manifest,before=before,collections=[],commands=[],original828NodesPreserved=False,componentsPassed=False,productionEdited=False,currentSourceAccepted=False,fullCiAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save();node_sets=[]
for label,root in [('original',original),('overlay',repo)]:
    argv=[sys.executable,'-X','utf8','-B','-m','pytest','-p','no:cacheprovider','--collect-only','-q','tests/governance']
    row=dict(label=label,argv=argv,startedAt=datetime.now(timezone.utc).isoformat());result['collections'].append(row);save()
    with (out/(label+'-collection.stdout.raw')).open('xb') as stdout,(out/(label+'-collection.stderr.raw')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=root,env=os.environ.copy(),stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(actualWaitCompleted=True,exitCode=code);save();assert code==0
    nodes=[line for line in (out/(label+'-collection.stdout.raw')).read_text(encoding='utf-8').splitlines() if line.startswith('tests/governance/') and '::' in line]
    assert len(nodes)==len(set(nodes))==828
    node_sets.append(set(nodes));row['uniqueNodes']=len(nodes);save()
assert node_sets[0]==node_sets[1];result['original828NodesPreserved']=True;save()
files=['tests/governance/test_poc_contract_repair_admission.py','tests/governance/test_program_lifecycle_guards.py']
expected={node for node in node_sets[0] if node.split('::')[0] in files}
argv=[sys.executable,'-X','utf8','-B','-m','pytest','-p','no:cacheprovider','-q','--durations=8','--junitxml='+str(out/'components.xml'),*files]
row=dict(argv=argv,expectedExistingCases=len(expected),startedAt=datetime.now(timezone.utc).isoformat());result['commands'].append(row);tick=time.monotonic_ns();save()
with (out/'components.stdout.raw').open('xb') as stdout,(out/'components.stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=repo,env=os.environ.copy(),stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
row.update(actualWaitCompleted=True,exitCode=code,elapsedNs=time.monotonic_ns()-tick);save()
xml=ET.parse(out/'components.xml').getroot();cases=xml.findall('.//testcase')
row.update(testcases=len(cases),failures=len(xml.findall('.//failure')),errors=len(xml.findall('.//error')),skipped=len(xml.findall('.//skipped')));save()
after=[state(original),state(repo)];assert before==after
result.update(after=after,sourceContextsUnchanged=True,componentsPassed=code==0 and len(cases)==len(expected) and all(row[k]==0 for k in ['failures','errors','skipped']),raw={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file() and p.suffix in {'.raw','.xml'}},finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(actualDiagnosticCheckout=c['source'],original828NodesPreserved=True,expectedCases=len(expected),actualCases=len(cases),exitCode=code,failures=row['failures'],errors=row['errors'],skipped=row['skipped'],sourceContextsUnchanged=True)),flush=True)
assert result['componentsPassed']
