"""Bounded diagnosis of three existing cases, with child checker CPU profiles.

This instrumentation is external to the source checkout and grants no gate,
full-CI, performance or experiment acceptance. No assertion is changed.
"""
from pathlib import Path
from live_github_transport import start_bridge
from datetime import datetime,timezone
import hashlib,json,os,pstats,subprocess,sys,time
import pytest

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
repo=Path('/home/sur/.cache/guize-takeover/ops017-ci916-actual-checkout-profile-cc508f7')
source='cc508f7a2ffb6bb82e7aee0ad3e2c9cdf400e605'
candidate=json.loads((t/'ops017-ci916-actual-checkout-diagnostic-candidate.json').read_bytes())
bundle=t/candidate['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==candidate['bundleSha256']
assert candidate['source']==source and candidate['base']=='a55680b9d06901729fcae7f35cb167b8b59d33f4'
if '--execute-child' not in sys.argv:
    assert not repo.exists()
    subprocess.run(['git','clone','--quiet','--branch',candidate['diagnosticBranch'],str(bundle),str(repo)],check=True)
    subprocess.run(['git','-C',str(repo),'branch','main',candidate['base']],check=True,capture_output=True)
    subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
    subprocess.run(['git','-C',str(repo),'checkout','--detach','--quiet',source],check=True)
assert not (repo/'.git/objects/info/alternates').exists()
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','main']).decode().strip()==candidate['base']
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','origin/main']).decode().strip()==candidate['base']
assert subprocess.check_output(['git','-C',str(repo),'show','-s','--format=%P','HEAD']).decode().strip().split()==[candidate['base'],candidate['ciSource']]

git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
state=lambda:dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before==dict(source=source,tree='d71b817f2922b3c53d6cda7abb409def374bb19c',status='')
out=t/'ops017-ci916-attempt2-bounded-child-profile-v1';out.mkdir()
if '--execute-child' not in sys.argv:
    os.environ.update(GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF='chore/OPS-017-normal-review-v2',GITHUB_BASE_REF='main',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request',GITHUB_REF='refs/pull/175/merge')
    start_bridge(out)
targets=['tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_missing_review_base','tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_legal_rework_metadata','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair']
original_run=subprocess.run
records=[]
checkers={'check-program-plan-history.py','check-program-lifecycle-guards.py'}
def diagnosed_run(argv,*args,**kwargs):
    script_index=next((i for i,v in enumerate(argv) if i>0 and Path(str(v)).name in checkers),None) if isinstance(argv,(list,tuple)) else None
    if script_index is not None:
        index=len(records);profile=out/f'child-{index:02d}.pstats'
        actual=[argv[0],*argv[1:script_index],str(t/'profile_checker_preserve_exit_v2.py'),str(profile),*argv[script_index:]]
        row=dict(originalArgv=list(map(str,argv)),diagnosticArgv=list(map(str,actual)),profile=profile.name,startedAt=datetime.now(timezone.utc).isoformat())
        records.append(row);tick=time.monotonic_ns()
        result=original_run(actual,*args,**dict(kwargs,timeout=180))
        row.update(returncode=result.returncode,elapsedNs=time.monotonic_ns()-tick)
        stats=pstats.Stats(str(profile));functions=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in stats.stats.items()]
        row['topSelfTime']=sorted(functions,key=lambda v:v['selfSeconds'],reverse=True)[:16]
        row['yamlLoadFunctions']=[v for v in functions if v['function'] in {'load','safe_load','load_yaml_text','load_ref','load_current','document'} and ('yaml/' in v['file'] or '/scripts/' in v['file'])]
        return result
    return original_run(argv,*args,**kwargs)

if '--execute-child' in sys.argv:
    os.chdir(repo);subprocess.run=diagnosed_run
    code=pytest.main(['-q','--junitxml='+str(out/'diagnostic-junit.xml'),*targets])
    (out/'child-costs.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    raise SystemExit(code)

# The child needs the same output directory without ever overwriting an old run.
PYTHON=sys.executable
plugin=t/'ops017_ci916_child_profile_instrumentation_v1.py'
assert not plugin.exists()
plugin.write_text(Path(__file__).read_text().replace("out=t/'ops017-ci916-attempt2-bounded-child-profile-v1';out.mkdir()", "out=t/'ops017-ci916-attempt2-bounded-child-profile-v1';assert out.is_dir()"),encoding='utf-8',newline='\n')
argv=[PYTHON,'-X','utf8','-B',str(plugin),'--execute-child']
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    try:code=child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        child.terminate();code=child.wait();raise
after=state();assert after==before
result=dict(kind='BOUNDED_EXISTING_CASE_CHILD_CPU_DIAGNOSIS_ONLY',source=source,before=before,after=after,sourceContextUnchanged=True,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code,existingCases=targets,childCosts=json.loads((out/'child-costs.json').read_bytes()),raw={n:dict(bytes=(out/n).stat().st_size,sha256=hashlib.sha256((out/n).read_bytes()).hexdigest()) for n in ['stdout.raw','stderr.raw','diagnostic-junit.xml']},fullCiAccepted=False,codeModified=False,thirdCiRetryAllowed=False,finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(source=source,existingCases=3,profiledCheckerCalls=len(result['childCosts']),actualWaitCompleted=True,exitCode=code,sourceContextUnchanged=True)),flush=True)
raise SystemExit(code)
