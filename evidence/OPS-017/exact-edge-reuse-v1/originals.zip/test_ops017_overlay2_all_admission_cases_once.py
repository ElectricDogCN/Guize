from pathlib import Path
from live_github_transport import start_bridge
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
repo=Path('/home/sur/.cache/guize-takeover/ops017-exact-edge-overlay-v2')
out=t/'ops017-exact-edge-overlay-v2-all62'
assert not out.exists()
manifest=json.loads((t/'ops017-exact-edge-overlay-v2/overlay.json').read_bytes())
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a])
assert git('rev-parse','HEAD').decode().strip()=='cc508f7a2ffb6bb82e7aee0ad3e2c9cdf400e605'
assert git('rev-parse','main').decode().strip()==manifest['base']
assert git('rev-parse','origin/main').decode().strip()==manifest['base']
assert not (repo/'.git/objects/info/alternates').exists()
for path,row in manifest['files'].items():assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==row['sha256']
out.mkdir()
os.environ.update(GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF='chore/OPS-017-normal-review-v2',GITHUB_BASE_REF='main',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request',GITHUB_REF='refs/pull/175/merge',PYTHONDONTWRITEBYTECODE='1')
start_bridge(out)
argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q','--durations=8','--junitxml='+str(out/'junit.xml'),'tests/governance/test_poc_contract_repair_admission.py']
before=git('diff','--binary');tick=time.monotonic_ns()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=repo,env=os.environ.copy(),stdout=stdout,stderr=stderr)
    code=child.wait(timeout=900)
assert git('diff','--binary')==before
xml=ET.parse(out/'junit.xml').getroot()
result=dict(kind='DIAGNOSTIC_OVERLAY_ALL62_ADMISSION_CASES',overlay=manifest,argv=argv,pid=child.pid,actualWaitCompleted=True,exitCode=code,elapsedNs=time.monotonic_ns()-tick,testcases=len(xml.findall('.//testcase')),failures=len(xml.findall('.//failure')),errors=len(xml.findall('.//error')),skipped=len(xml.findall('.//skipped')),productionEdited=False,currentSourceAccepted=False,raw={p:dict(bytes=(out/p).stat().st_size,sha256=hashlib.sha256((out/p).read_bytes()).hexdigest()) for p in ['stdout.raw','stderr.raw','junit.xml']},finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['exitCode','testcases','failures','errors','skipped','elapsedNs']}),flush=True)
raise SystemExit(code)
