from pathlib import Path
from datetime import datetime,timezone
from live_github_transport import start_bridge
import hashlib,json,os,shutil,subprocess,sys,time,xml.etree.ElementTree as ET

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
overlay=t/'ops017-exact-edge-overlay-v2'
manifest=json.loads((overlay/'overlay.json').read_bytes())
c=json.loads((t/'ops017-ci916-actual-checkout-diagnostic-candidate.json').read_bytes())
repo=Path('/home/sur/.cache/guize-takeover/ops017-exact-edge-overlay-v2')
out=t/'ops017-exact-edge-overlay-v2-tests'
assert not repo.exists() and not out.exists()
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
subprocess.run(['git','clone','--quiet','--branch',c['diagnosticBranch'],str(bundle),str(repo)],check=True)
subprocess.run(['git','-C',str(repo),'branch','main',c['base']],check=True)
subprocess.run(['git','-C',str(repo),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
subprocess.run(['git','-C',str(repo),'checkout','--detach','--quiet',c['source']],check=True)
assert not (repo/'.git/objects/info/alternates').exists()
for path,row in manifest['files'].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==row['originalSha256']
    assert hashlib.sha256((overlay/path).read_bytes()).hexdigest()==row['sha256']
    shutil.copyfile(overlay/path,repo/path)
out.mkdir()
os.environ.update(GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF='chore/OPS-017-normal-review-v2',GITHUB_BASE_REF='main',GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request',GITHUB_REF='refs/pull/175/merge',PYTHONDONTWRITEBYTECODE='1')
start_bridge(out)
targets=['tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration', 'tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair']
argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q','--durations=5','--junitxml='+str(out/'junit.xml'),*targets]
before=subprocess.check_output(['git','-C',str(repo),'diff','--binary'])
tick=time.monotonic_ns()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    process=subprocess.Popen(argv,cwd=repo,env=os.environ.copy(),stdout=stdout,stderr=stderr)
    code=process.wait(timeout=600)
assert subprocess.check_output(['git','-C',str(repo),'diff','--binary'])==before
suite=ET.parse(out/'junit.xml').getroot()
result=dict(kind='DIAGNOSTIC_OVERLAY_FOCUSED_TESTS',baseCheckout=c['source'],overlay=manifest,argv=argv,pid=process.pid,actualWaitCompleted=True,exitCode=code,elapsedNs=time.monotonic_ns()-tick,testcases=len(suite.findall('.//testcase')),failures=len(suite.findall('.//failure')),errors=len(suite.findall('.//error')),skipped=len(suite.findall('.//skipped')),raw={p:dict(bytes=(out/p).stat().st_size,sha256=hashlib.sha256((out/p).read_bytes()).hexdigest()) for p in ['stdout.raw','stderr.raw','junit.xml']},productionModified=False,fullCiAccepted=False,finishedAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['exitCode','testcases','failures','errors','skipped','elapsedNs']}),flush=True)
raise SystemExit(code)
