"""Compare current introduction with fresh batched Git reads; never grant scope."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,subprocess,time

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
root=Path('/home/sur/.cache/guize-takeover/ops017-historical-authority-fixture-source877-3396b93')
spec=importlib.util.spec_from_file_location('read_only_batch_probe',root/'scripts/poc-contract-repair-admission.py')
proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a]).decode().strip()
before={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1','--untracked-files=all')}
assert before=={'head':'3396b93e880cbfc42b86128e64bc362c827195ca','status':''}
out=t/'ops017-registry-batch-readonly-probe-v1';out.mkdir()

def batch_introduction(repo,history,task_id):
    expressions=[node+':'+proof.ACTIVE for node in history]
    metadata=subprocess.run(['git','-C',str(repo),'cat-file','--batch-check'],input=('\n'.join(expressions)+'\n').encode(),capture_output=True,check=True).stdout.splitlines()
    assert len(metadata)==len(history)
    order=[];oids=[]
    for line in metadata:
        if line.endswith(b' missing'):order.append(None);continue
        oid,kind,size=line.split();assert kind==b'blob' and len(oid)==40 and int(size)>=0
        order.append(oid)
        if oid not in oids:oids.append(oid)
    contents=subprocess.run(['git','-C',str(repo),'cat-file','--batch'],input=b'\n'.join(oids)+b'\n',capture_output=True,check=True).stdout if oids else b''
    offset=0;blobs={}
    for oid in oids:
        end=contents.index(b'\n',offset);actual,kind,size=contents[offset:end].split();assert actual==oid and kind==b'blob'
        length=int(size);offset=end+1;blobs[oid]=contents[offset:offset+length];offset+=length
        assert len(blobs[oid])==length and contents[offset:offset+1]==b'\n';offset+=1
    assert offset==len(contents)
    decoded={};found=None;was_present=False
    for node,oid in zip(history,order):
        if oid is None:
            proof.require(found is None,'Registry disappeared after repair registration');continue
        if oid not in decoded:
            value=proof.yaml.load(blobs[oid],Loader=proof.SAFE_DOCUMENT_LOADER)
            proof.require(isinstance(value,dict),'Repair authority document must be a mapping')
            decoded[oid]=proof.rows(value.get('tasks'))
        entry=decoded[oid].get(task_id)
        if entry and not was_present:
            proof.require(found is None,'Repair identity was reintroduced');found=(node,entry)
        was_present=entry is not None
    return found,{'historicalCommits':len(history),'uniqueRegistryBlobs':len(oids),'batchContentsBytes':len(contents),'gitChildren':2 if oids else 1}

history=proof.chain(str(root),'877d1b0fbd717f71fa9ad1e2ea4db4723ded3bcc');rows=[]
for task in ['OPS-013','OPS-017','OPS-099']:
    tick=time.monotonic_ns();old=proof.introduction(str(root),history,task);old_elapsed=time.monotonic_ns()-tick
    tick=time.monotonic_ns();new,observed=batch_introduction(root,history,task);new_elapsed=time.monotonic_ns()-tick
    assert new==old
    rows.append(dict(taskId=task,oldElapsedNs=old_elapsed,batchElapsedNs=new_elapsed,identical=True,resultDigest=hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),observed=observed))
after={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1','--untracked-files=all')};assert after==before
result=dict(kind='READONLY_FRESH_BATCH_IO_COMPARISON_NOT_SOURCE_OR_CI_ACCEPTANCE',source=before['head'],before=before,after=after,rows=rows,scopeGranted=False,codeModified=False,createdAt=datetime.now(timezone.utc).isoformat())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result),flush=True)
