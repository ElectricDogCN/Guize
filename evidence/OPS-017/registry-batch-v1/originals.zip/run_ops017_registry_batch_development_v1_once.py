"""Exercise a pinned uncommitted overlay; never qualify a new source commit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET

assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
author=t/'ops017-source-compatibility-admission-v1'
source='30794b65dd81b256d88c4ad616c0130712f2168b'
bundle=t/'ops017-authority-reuse-30794b6.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='646567052307eb38386bc0b0f045ff9856c28dc2e8cadfd30d7d68e0dd42548d'
pins={'scripts/poc-contract-repair-admission.py':'f8b9fc75e9aef0c5fbf8f7aefe1cac35610d00c941bf9480207d6bf2902685c3','tests/governance/test_poc_contract_repair_admission.py':'a07a581864fd6504b17c020375d7794e18885e9203006f35dc180dcfa0e89e54'}
overlays={'scripts/poc-contract-repair-admission.py':t/'ops017-registry-batch-on307-production-v1.py','tests/governance/test_poc_contract_repair_admission.py':t/'ops017-registry-batch-on307-tests-v1.py'}
out=t/'ops017-registry-batch-development-v1';out.mkdir()
repo=Path('/home/sur/.cache/guize-takeover/ops017-registry-batch-development-v1');assert not repo.exists()
subprocess.run(['git','clone','--quiet','--branch','chore/OPS-017-source-compatibility-admission',str(bundle),str(repo)],check=True)
git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain=v1','--untracked-files=all')
accepted=json.loads((t/'ops017-implementation-actual-main-independent-review.json').read_bytes())
base='877d1b0fbd717f71fa9ad1e2ea4db4723ded3bcc'
assert accepted['actualMain']==base and accepted['actualCodeMainAccepted'] and accepted['fullMainCiAccepted'] and not accepted['mustFix']
assert not git('for-each-ref','--format=%(refname)','refs/heads/main','refs/remotes/origin/main')
git('branch','main',base)
git('update-ref','refs/remotes/origin/main',base,'0'*40)
git('remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git')
for path,pin in pins.items():
    raw=overlays[path].read_bytes();assert hashlib.sha256(raw).hexdigest()==pin
    (repo/path).write_bytes(raw);(out/(Path(path).name+'.overlay')).write_bytes(raw)
state=lambda:dict(source=git('rev-parse','HEAD'),canonicalMain=git('rev-parse','main'),originMain=git('rev-parse','origin/main'),originUrl=git('remote','get-url','origin'),status=git('status','--porcelain=v1','--untracked-files=all'),pins={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in pins})
before=state();assert before['pins']==pins
assert hashlib.sha256((repo/'scripts/check-program-lifecycle-guards.py').read_bytes()).hexdigest()=='3ad375207c6ebdeb5d007031c779e4eb17319d824e6c6fb879bf0dc398b2f13b'
selected=['tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_missing_review_base','tests/governance/test_program_plan_history.py::TestProgramPlanHistory::test_foundation_postclaim_legal_rework_metadata','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_actual_no_task_lifecycle_accepts_real_registered_frozen_repair','tests/governance/test_poc_contract_repair_admission.py::TestSourceCompatibilityRepairAdmission::test_real_new_authority_admits_exact_five_and_preserves_legacy_configuration']
result=dict(kind='PINNED_UNCOMMITTED_OVERLAY_COMPONENT_DEVELOPMENT_ONLY',baseSource=source,pins=pins,before=before,commands=[],sourceQualified=False,fullCiAccepted=False,startedAt=datetime.now(timezone.utc).isoformat())
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for label,tests,count in [('native-main-readiness1',['tests/governance/test_check_project_readiness.py::TestProjectReadiness::test_current_repository_indexes_pass'],1),('focused-existing-four',selected,4),('all-existing-component62',['tests/governance/test_poc_contract_repair_admission.py'],62)]:
    junit=out/(label+'.xml');argv=[sys.executable,'-X','utf8','-B','-m','pytest','-q','--junitxml='+str(junit),*tests]
    row=dict(label=label,argv=argv,expectedExistingCases=count,startedAt=datetime.now(timezone.utc).isoformat());tick=time.monotonic_ns()
    with (out/(label+'.stdout.raw')).open('xb') as stdout,(out/(label+'.stderr.raw')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        row['pid']=child.pid;result['commands'].append(row);save();code=child.wait()
    row.update(exitCode=code,actualWaitCompleted=True,elapsedNs=time.monotonic_ns()-tick,raw={n:dict(bytes=(out/n).stat().st_size,sha256=hashlib.sha256((out/n).read_bytes()).hexdigest()) for n in [label+'.stdout.raw',label+'.stderr.raw',junit.name]});save()
    print(label+': exit '+str(code),flush=True)
    if code:result.update(after=state());save();raise SystemExit(code)
    suites=list(ET.parse(junit).getroot().iter('testsuite'));assert sum(int(s.attrib['tests']) for s in suites)==count
    assert all(int(s.attrib.get(k,0))==0 for s in suites for k in ['failures','errors','skipped'])
cases=list(ET.parse(out/'all-existing-component62.xml').getroot().iter('testcase'))
assert len([v for v in cases if 'test_poc_contract_repair_admission' in v.attrib.get('classname','')])==62
assert state()==before
result.update(after=state(),sourceContextUnchanged=True,focusedFourPassed=True,existingComponent62Passed=True,fullExistingGovernance828Passed=False,finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({'baseSource':source,'overlayOnly':True,'focusedFourPassed':True,'existingComponent62Passed':True,'fullExistingGovernance828Passed':False,'sourceContextUnchanged':True}),flush=True)
