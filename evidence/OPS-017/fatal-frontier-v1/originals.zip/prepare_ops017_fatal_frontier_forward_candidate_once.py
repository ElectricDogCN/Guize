"""Prepare one owned forward correction from failed actual main after component acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,copy,hashlib,json,re,shlex,subprocess,zipfile
import yaml
t=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--component-review-sha256',required=True);args=p.parse_args()
base='76be38c26dea26669819f142c572e69aac84c32b';oldbase='a55680b9d06901729fcae7f35cb167b8b59d33f4'
branch='chore/OPS-017-source-compatibility-admission';relative='scripts/check-program-lifecycle-guards.py'
rp=t/'ops017-lifecycle-fatal-frontier-component-independent-review.json'
assert hashlib.sha256(rp.read_bytes()).hexdigest()==args.component_review_sha256
review=json.loads(rp.read_bytes());assert review['componentOverlayAccepted'] and review['actualCandidatePreparationAllowed'] and not review['mustFix']
route=t/'ops017-main919-attempt2-negative-and-forward-repair-route-independent-review.json'
assert hashlib.sha256(route.read_bytes()).hexdigest()=='ea0d17021f69a3c9e9a6addf224b989e03941cb73c8883d98557a26cffe912e6'
assert not json.loads(route.read_bytes())['mustFix']
overlay=t/'ops017-lifecycle-fatal-frontier-overlay-v1';manifest=json.loads((overlay/'overlay.json').read_bytes())
assert hashlib.sha256((overlay/'overlay.json').read_bytes()).hexdigest()==review['overlayManifestSha256']
assert manifest['base']==base and manifest['path']==relative and manifest['allOriginalAstRetained'] and not manifest['testAssertionsModified']
assert manifest['newSha256']=='26c414a6e3634520a76831fe36a90f9297ba8cc2193e705766063ba902f728e5'
components=t/'ops017-fatal-frontier-components-v1';comp=json.loads((components/'results.json').read_bytes())
component_pin=next(v for v in review['component']['componentEvidence'] if v['path']=='.takeover-tools/ops017-fatal-frontier-components-v1/results.json')
component_raw=(components/'results.json').read_bytes();assert len(component_raw)==component_pin['bytes'] and hashlib.sha256(component_raw).hexdigest()==component_pin['sha256']
assert comp['overlay']==manifest and comp['componentsPassed'] and comp['sourceContextsUnchanged'] and comp['original828NodesPreserved']
assert [r['uniqueNodes'] for r in comp['collections']]==[828,828]
assert len(comp['commands'])==1;row=comp['commands'][0]
assert row['actualWaitCompleted'] and row['exitCode']==0 and row['testcases']==row['expectedExistingCases']==73
assert all(row[k]==0 for k in ['failures','errors','skipped'])
for name,pin in comp['raw'].items():
    raw=(components/name).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
c=json.loads((t/'ops017-lifecycle-loader-actual-main-candidate.json').read_bytes());assert c['actualMain']==base and c['source']=='75c146410ee356d74102134ddede0639e9f2f999' and c['base']==oldbase
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
canonical=t.parent/'Guize'
cg=lambda *v:subprocess.check_output(['git','-c','core.longpaths=true','-C',str(canonical),*v]).decode().strip()
assert cg('rev-parse','HEAD')==base and cg('branch','--show-current')=='main' and not cg('status','--porcelain=v1','--untracked-files=all')
assert cg('ls-remote','--heads','origin','refs/heads/main').split()==[base,'refs/heads/main']
r=t/'ops017-fatal-frontier-forward-v1';assert not r.exists()
subprocess.run(['git','-c','core.longpaths=true','-c','core.autocrlf=false','clone','--quiet','--branch','main',str(bundle),str(r)],check=True)
g=lambda *v:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*v])
dec=lambda *v:g(*v).decode().strip()
assert not (r/'.git/objects/info/alternates').exists() and dec('rev-parse','HEAD')==base and dec('rev-parse','HEAD^{tree}')==c['tree']
g('remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git');g('switch','-c',branch)
registry='specs/coordination/active-work.yaml';taskpath='specs/tasks/OPS-017.md'
raw=(r/registry).read_text(encoding='utf-8');before=yaml.safe_load(raw);expected=copy.deepcopy(before)
own=next(x for x in expected['tasks'] if x['taskId']=='OPS-017')
assert own['baseSha']==oldbase and own['status']=='in_progress' and own['agentRole']=='implementer' and own['branch']==branch
assert own['implementer']=='/root' and own['reviewer']=='/root/gz022_planning_independent_review'
claims=['AGENTS.md','scripts/poc-contract-repair-admission.py',relative,'tests/governance/test_poc_contract_repair_admission.py']
assert set(own['exclusivePaths'])==set(claims) and own['sharedPaths']==[]
assert own['lease']=={'acquiredAt':'2026-10-29T09:16:44Z','expiresAt':'2026-11-05T09:16:44Z'}
assert datetime.now(timezone.utc)<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
own['baseSha']=base;m=re.search(r'(?ms)^- taskId: OPS-017\n.*?(?=^- taskId:|\Z)',raw);assert m
block,n=re.subn(r'(?m)^  baseSha: '+oldbase+'$','  baseSha: '+base,m[0]);assert n==1
updated=raw[:m.start()]+block+raw[m.end():];assert yaml.safe_load(updated)==expected
(r/registry).write_text(updated,encoding='utf-8',newline='\n')
task=(r/taskpath).read_bytes();parts=task.decode().split('---',2);front,body=parts[1:]
front,n=re.subn(r'(?m)^baseSha: '+oldbase+'$','baseSha: '+base,front);assert n==1
(r/taskpath).write_text('---'+front+'---'+body,encoding='utf-8',newline='\n')
assert (r/taskpath).read_bytes().split(b'---',2)[2]==task.split(b'---',2)[2]
blocks=re.findall(r'```bash\n(.*?)\n```',body,re.S);assert len(blocks)==1
historical=[shlex.split(line) for line in blocks[0].splitlines() if line.strip()];assert len(historical)==14
commands=[[v.replace('22ab6a0668da2d64a016fccef2c3b5a634638a24',base).replace('chore/OPS-017-source-compatibility-admission-reservation',branch) for v in argv] for argv in historical]
assert hashlib.sha256((r/relative).read_bytes()).hexdigest()==manifest['oldSha256']
raw=(overlay/relative).read_bytes();assert len(raw)==manifest['newBytes'] and hashlib.sha256(raw).hexdigest()==manifest['newSha256'];(r/relative).write_bytes(raw)
protected=[p for p in claims if p!=relative]+['scripts/check-program-plan-history.py','scripts/program-planning-revision.py','specs/coordination/program-plan.yaml','specs/coordination/task-completions.yaml','evidence/OPS-017/source-compatibility-admission-intent.json','specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md']
for name in protected:assert (r/name).read_bytes()==g('show',base+':'+name)
files=[rp,route,t/'ops017-lifecycle-loader-actual-main-candidate.json',t/'ops017-lifecycle-loader-official-merge.json',t/'ops017-lifecycle-loader-75c1464-final-independent-review.json',t/'ops017-main919-attempt1-negative-and-bounded-retry-independent-review.json',t/'ops017-ci919-attempt2-fresh-dispatch-guard.json',t/'ops017-ci919-attempt2-single-dispatch-intent.json',t/'ops017-ci919-attempt2-actual-dispatch-envelope.json',t/'ops017-ci919-attempt2-initial-official-state.json',t/'ops017-main919-attempt2-single-dispatch-result-independent-review.json',t/'ops017-main919-bounded-profile-facts-and-repair-scope-independent-review.json',t/'ops017-lifecycle-fatal-frontier-overlay-v1-static-and-diagnostic-independent-review.json',overlay/'overlay.json',overlay/relative,Path(__file__)]
for folder in ['ops017-lifecycle-loader-source-ci','ops017-lifecycle-loader-sourcea556-75c1464-native-gates-v1','ops017-lifecycle-loader-76be38c-native-main-checks','ops017-lifecycle-loader-main-ci-attempt1-negative','ops017-lifecycle-loader-main-ci-attempt2-negative','ops017-main919-bounded-common-checker-profile-v1','ops017-main919-rejected-case-profile-v1','ops017-main919-fatal-frontier-overlay-profile-v1','ops017-fatal-frontier-components-v1']:
    files.extend(path for path in sorted((t/folder).iterdir()) if path.is_file())
assert len(files)==len(set(files)) and all(path.is_file() for path in files)
phase=r/'evidence/OPS-017/fatal-frontier-v1';phase.mkdir();records=[]
with zipfile.ZipFile(phase/'originals.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in files:
        name=path.relative_to(t).as_posix();raw=path.read_bytes();z.writestr(name,raw);records.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(phase/'index.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
(phase/'commands.txt').write_text('\n'.join(shlex.join(v) for v in commands)+'\n',encoding='utf-8',newline='\n')
context=dict(taskId='OPS-017',phase='definiteFatalFrontier',base=base,parent=base,branch=branch,originalCodeSource='75c146410ee356d74102134ddede0639e9f2f999',originalCodePr=176,targetFullMainCiAccepted=False,originalTaskBodyAnd14Preserved=True,originalLease=own['lease'],historicalTaskCommands=historical,currentSourceCommands=commands,codePins={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in claims},original828NodesPreserved=True,allExistingAssertionsRetained=True,component73Passed=True,laterSupplementalDiagnosticsOmittedOnAlreadyRejectedInput=True,currentFixedSource14Executed=False,currentFullCiAccepted=False,sourceCommitted=False,normalReviewMayStart=False,highCapacityReleased=False,experimentApproved=False,createdAt=datetime.now(timezone.utc).isoformat())
(phase/'context.json').write_text(json.dumps(context,indent=2)+'\n',encoding='utf-8',newline='\n')
note='''# OPS-017 definite failure frontier

PR176/source75 complete sourceCI918 passed828/28steps in1191.14s, and actual code main76 passed its own7 checks. Its pushCI919 attempts1/2 nevertheless hit the unchanged30-minute cap with768/771 PASS and60/57 incomplete, no complete summary. Both full negatives, the only approved retry and actual one dispatch remain originals. Main76 is the real current integration target and has not received full-main acceptance; this forward correction does not rewrite that fact or dispatch a third unchanged run.

The lifecycle checker executes the complete original source-intent, bound014/018 repair, frozen-change and recovery front stage. If those checks already collect definite failures, it emits every collected FAIL and returns1. Inputs still eligible for acceptance continue every original check. No earlier history prefix or normal proof is removed. Later supplemental diagnostics on already rejected inputs are omitted; complete stdout equivalence is not claimed. All original AST statements and test assertions remain, and neither unclaimed P/H bytes nor runtime implementations are patched.

The bounded unchanged-case comparison measured rejected checker15.922→10.500s and intent rejection5.508→0.606s. The valid case16.978s retained consumer/classifier and normal proofs. All73 existing admission/lifecycle cases and identical828-node collections passed in a frozen uncommitted L-only overlay; these facts do not qualify this future source or the full CI budget. Registry and Task change only Own current target baseM→N; Task body/literal14, actors/lease, original fourclaims, intent, Program, ledger, frozen5 and foreign data remain. High capacity remains occupied.

Next: independent exact candidate review, ordinary commit, all current-source14, exact-old75 fast-forward publication and a new PR targeting actual76, complete828 CI and independent source/actual-main acceptance, then normal Review/Completion and exact ended remote cleanup. Original authors, refs, failures and recovery material stay. No OPS018 or POC runtime approval is supplied here.
'''
(phase/'README.md').write_text(note,encoding='utf-8',newline='\n')
for name in ['summary.md','handoff.md','test-results/README.md']:
    with (r/'evidence/OPS-017'/name).open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n'+note.rstrip()+'\n')
with (r/'evidence/OPS-017/commands.txt').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n# Fatal-frontier source14 UNEXECUTED / target '+base+'\n'+'\n'.join(shlex.join(v) for v in commands)+'\n')
paths=set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines())|{'evidence/OPS-017/changed-files.md'};assert len(paths)==13
with (r/'evidence/OPS-017/changed-files.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## Definite-failure frontier forward correction\nTarget and parent: '+base+'\n'+''.join('- '+p+'\n' for p in sorted(paths)))
assert set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines())==paths
assert all(p in set(claims)|{registry,taskpath} or p.startswith('evidence/OPS-017/') for p in paths)
for name in protected:assert (r/name).read_bytes()==g('show',base+':'+name)
g('diff','--check')
snapshot=[dict(path=p,bytes=(r/p).stat().st_size,sha256=hashlib.sha256((r/p).read_bytes()).hexdigest()) for p in sorted(paths)]
with (t/'ops017-fatal-frontier-precommit-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(dict(context,author=str(r),changedPaths=sorted(paths),targetChangedPaths=sorted(paths),fileSnapshot=snapshot,protectedPaths=protected,prerequisiteRecords=len(records)),indent=2)+'\n')
print(json.dumps(dict(parent=base,base=base,changedPaths=len(paths),archivedOriginals=len(records),committed=False)),flush=True)
