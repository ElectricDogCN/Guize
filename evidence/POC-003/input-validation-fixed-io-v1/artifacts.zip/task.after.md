---
schemaVersion: 2
id: POC-003
title: Validate ATS Range Slice and authorization cache isolation
titleZh: ATS Range/Slice、大文件与权限缓存键
type: chore
status: in_progress
baseBranch: main
baseSha: 760f6c5838597d1d66c0a536ecbf440ef5a7dfec
workBranch: chore/POC-003-ats-range
evidencePath: evidence/POC-003
issue: 131
workPackage: WP-M0-POC-03
programPlan: specs/coordination/program-plan.yaml
programTaskId: POC-003
wave: W2
requirementIds: REQ-V1-0003,REQ-V1-0008
moduleIds: MOD-EDGE,MOD-IAM
producesContracts: POC-03-EVIDENCE
consumesContracts: POC-PROTOCOL-V1
exitGate: POC-03 具有可复现环境、命令、原始结果、失败限制、退出决策与回滚
taskOwner: ElectricDogCN
coordinator: program-coordinator-agent
implementer: /root
reviewer: /root/independent_review
integrator: integration-agent
agentRole: implementer
riskLevel: medium
coordinationMode: registry
coordinationGroup: poc-results
dependsOn: GZ-010
handoffPath: evidence/POC-003/handoff.md
integrationStrategy: merge
integrationOrder: 2
leaseExpiresAt: 2026-10-29T12:47:06Z
---

# POC-003 ATS 实现与实验

## 采集端固定缓冲与原始文件写入

本轮Own Collector改用固定64KiB backing和HTTPResponse.readinto，首个body读取仍只提供1字节视图，保留原首字节时钟；随后读与IncompleteRead只处理实际返回内容。每个固定backing读取前核实际__alloc__，原始响应文件使用无用户态文件缓冲的写入并处理部分写入/无进展错误，比较来源也用固定raw readinto。响应buffer在控制轮询前释放，比较buffer在元数据保存和整个请求区间结束前释放；原输入/Chunk/每响应与累计预算/原矩阵与故障约束保持。

直接执行 `python poc/POC-03-ats-range/test_collector_raw_io.py` 的5项真实本机HTTP合成回归；当前Windows54/Linux63相关回归与独立组件接受不授完整源或实验资格。实际23个子命令及源快照保存在 `evidence/POC-003/collector-raw-io-v1/` 标准ZIP，index提供逐条目摘要。原fixture的超首target部分响应和JSON tuple/array表示比较失败均按实际范围保留，不把工具观测误称为未捕获的原始child流。

新增真实本机HTTP合成服务回归覆盖Content-Length、chunked、截断、部分文件写入与无进展失败；既有生命周期fixture改为读入实际owned backing，读取时应仅该一块在用，控制与最终元数据时仍要求零存活。此为实现语义相应的fixture调整，不授全媒体容量或实验资格。原生HTTP/IO与解释器身份绑定、Gateway、导出/重组、完整窗口及ATS/native/hash/sendall聚合仍需完成。只改Own POC/Task正文/Evidence，冻结契约、阈值与旧原件保持，无ATS或真实素材实验；回滚为保留证据的普通前向改动。

## 来源与哈希的固定原始文件缓冲

在Own lab中把digest和Origin来源读取改为原始阻塞文件readinto及单个固定bytearray/memoryview：哈希仍按1MiB工作缓冲、媒体仍按原chunkBytes=65536，不改配置/阈值/输入或限额；不再依赖有缓冲read返回bytes后的扩缩容容量推断。来源每次实际读取字节数仍进入原计数、写入、慢速等待和截断摘要；原始文件与所有视图在终止活动区间/截断保持前关闭或释放。HEAD与鉴权拒绝仍不得读取来源。

每次读取前同步核对该bytearray的实际`__alloc__()`为请求长度加终止字节，拒绝相同逻辑长度但仍保留更大backing的对象；Origin把实际容量记入原始请求行。该字段需随实际运行解释器身份一同验证，不能单独证明所有HTTP/原生分配。

直接执行 `python poc/POC-03-ats-range/test_fixed_origin_io.py` 的5项回归；当前Windows49/Linux58相关回归及独立组件接受仅绑定本次八个源快照。完整运行域和资格仍待。原始字节使用标准ZIP保存于 `evidence/POC-003/fixed-origin-io-v1/`，index提供逐条目摘要；较早48/57阶段只保留真实receipt的源哈希，不冒充另存的原始草稿源。

先用合成输入及原相关回归验证内容摘要、短尾、空文件、错误关闭和既有首字节/截断语义。此源组件不授真实实验或完整内存域：bytearray实际分配路径需绑定批准CPython实现，Gateway/Collector HTTP、缓存导出/重组及整个窗口/原生epoch聚合仍须各自证明。仅Own POC/Task正文/Evidence可改，冻结checkers/Schema/阈值、Program/Active与旧原件保持。没有ATS或新媒体实验；回滚是保留证据的受审查前向改动。

## 聚合容量证明的同步请求重叠记录

本轮在Own lab/Collector中，于原共享锁下同步更新Origin、Gateway和完整Collector请求区间的累计并发峰值；区间须先登记后读取媒体，已接受的逐块释放和流关闭须先于区间结束。快照与采集回执仅报告从各自进程初始化至该快照的高水位，不能把两用户、全程请求上限、轮询当前值或尚未结束窗口当作完整并发证明。不新增并发上限、输入、资源阈值或实验批准。

用实际执行的合成Origin/Gateway处理器重叠及Collector线程重叠回归验证峰值不会随请求结束而丢失；同时保留生命周期与相关原有回归。HTTP/IO单区间容量、整个运行闭合和原生epoch聚合仍待。仅Own POC/Task正文/Evidence可改，冻结checker/Schema/阈值和旧记录保持；没有ATS、真实输入或新媒体实验，回滚为保留证据的受审查前向改动。

直接执行 `python poc/POC-03-ats-range/test_request_concurrency.py` 的4项合成重叠回归；当前Windows44/Linux53相关回归及独立组件审查已通过，完整源与媒体容量资格仍未授予。原3个测试fixture漏补新增初始化字段的两平台失败已保留，修正仅补字段，旧断言保持；具体命令/退出码/raw/源快照见 `evidence/POC-003/request-concurrency-v1/index.json`。

## 当前媒体引用生命周期修复

已接受身份主线055ccf18e4b125850d59c93f5ec3204e630f101c通过真实双父合并de2f4f3bceffa964cc4ebbc0278fb6229845c31d导入；Task保留原in_progress状态、创建基线和租约，自动stage0未手改。当前在Own POC路径内修复Origin/Gateway/Collector最后媒体块及缓存导出actual/expected跨迭代存活：每块处理或异常退出后释放引用，关闭相关流并释放引用后才结束活动区间、终止日志或开始控制轮询；截断前缀摘要、首body时钟、传输结果和完整缓存重组判定保持。

新增离线生命周期回归验证正常、截断、IncompleteRead、写入失败和相邻块交接时的实际弱引用存活，并验证导出比较结果与跨键释放；不运行ATS或真实媒体实验。该修复不等同于完整聚合容量证明，HTTP/IO中间容量、真实并发上界、原生全部epoch、完整源检查/CI、原矩阵、独立热缓存撤权与新的资源/窗口批准仍须各自完成。冻结checker、Schema、阈值、Program、Active与所有旧原件不修改。回滚为保留证据的受审查前向改动。

本组件直接执行 `python poc/POC-03-ats-range/test_payload_lifetime.py` 的11项离线回归，并保留相关原有测试；当前Windows40/Linux49通过及独立组件接受仅绑定本次四文件快照，完整源门禁和实验资格仍待。实际命令、退出码、原始结果及明确标注的旧测试重构件在 `evidence/POC-003/payload-lifetime-v1/index.json`。

## Single-thread execution owner integration (pure results accepted; native validation pending)

Current source-level integration review c169f392... and actual30-case pure result review e7c0a3ea... are accepted; zero failures/errors/skips,11 unchanged source pins. The16 new cases check mocked protocol/control branches plus actual regular-file/probe-open interfaces without native owner/target/filter/signal/ATS execution. Full results, four corrected P2 findings, actual v2 source copies and explicitly labelled23011-byte source-v1 reconstruction are losslessly retained under evidence/POC-003/single-owner-integration-v1/index.json (18 items/161090 decoded bytes). Source work remains an uncommitted component until exact precommit review; it is not whole-source CI or POC qualification. Native owner/ATS compatibility still needs separate prospective profile/window approval.

The existing approved component controls are prerequisite evidence, not ATS acceptance. The next implementation remains within `poc/POC-03-ats-range/**` and this task's Evidence: a POC-specific single-thread owner process, started before HTTP threads, exclusively owns every instrumented ATS helper/start/restart target, fixed listener handoff, pidfd, abort, actual wait and journal closure. It consumes the already implemented fixed policy without weakening `_deadline_owner`, changing frozen measurement rules or tracing requests.

The instrumented profile requires the lab controller to be private-namespace PID1, ordinary UID/caps0. Parent and owner use one private CLOEXEC SOCK_SEQPACKET channel with bounded, strictly typed metadata and only the two validated stdout/stderr file descriptors on launch. Requests select the existing ATS service, verify_config or clear_cache operations; they cannot select arbitrary executables, environment, input paths or signal numbers. Protocol sequence and epoch identity are checked. No listener crosses this channel. Preparation binds the actual interpreter plus owner/filter/gate sources separately from the existing exact compiled-runtime component set, and fixes locale to C.UTF-8/PYTHONCOERCECLOCALE=0.

The owner alone records actual target Popen wait and journal outcome. The HTTP controller receives a bound process view for existing probes and returned owner facts; it never relabels an RPC response, absent PID, socket EOF or its own owner wait as an actual target wait. Owner/channel failure invalidates the run and exits the private PID1 scope, so remaining namespace processes terminate by namespace containment; individual target exits remain unknown unless actually observed by the owner. Normal stop uses the owner's bound pidfd, finite wait/abort and journal closure before shutting down the owner. Source-level review and pure failure-path tests precede separate prospective resource/window approval for actual owner/ATS compatibility tests. No native test, media run or filter installation is authorized by this task-body update. The current POC-005 measurement must finish before other experiments run.

Completion still requires the complete media ownership domain, same-run untraced latency, accepted-main synchronization, fixed-source gates/CI, original15 and hot-cache revocation plus full frozen POC qualification. Rollback is an ordinary reviewed forward change retaining all component, launch and failure evidence; Program, Active, roles, lease, contracts and thresholds remain unchanged.

## Pending fixed single-initial-exec handoff implementation

TaskPOC-003/Issue131 remainsin_progress under its existing scope/roles/lease. Goal: close the first-loader and later-exec gap in the existing same-PID owned epoch, without attaching a tracer to measured requests. The accepted static feasibility review86732caf requires a fixed native-x86_64 filter installed by a trusted single-thread/non-media gate before FDexec: reject compat/x32, fork/vfork/nonthreadclone and subsequent SYS_seccomp/PR_SET_SECCOMP; clone3 returnsENOSYS only under an actually validated libc fallback; firstexec requests USER_NOTIF. Exactly one listener crosses a privateCLOEXEC SOCK_SEQPACKET channel, sender closes its copy before a close-ack/EOF and READY. Parent must verify ownedbirth/singleton/defaultsignals/exactFD/empty-path/argv/env/notificationID before one irreversible CONTINUE attempt, then close its sole listener.

This implementation is not a general security sandbox or policy language. Pointer checks rely on the exact trusted blocked bootstrap, no mutating siblings and immutable verified target; ID_VALID alone is not a lock. Finite deadlines and real owned cleanup/wait remain mandatory. Initial source work is limited to Ownpoc fixed filter/transport/one-grant helpers and source-level tests/docs; existinglab integration remains disabled until separately reviewed concrete canaries establish kernel/Docker/filter availability, actual denied syscalls, actualpthreadfallback and closure/race/error behavior. No prctl/seccomp/filter/nativecanary/ATS/media run is approved by writing code or by pure tests. Full other-media ownership, stable-main sync/source15/CI, original15/hotcache/qualifiedPOC remain pending. Frozencheckers/Schema/thresholds/Program/Active/roles/claims/lease/oldraw are excluded. Rollback is ordinary reviewed forward changes; failed artifacts are retained.



## Durable tracked-peak component V2 (not full-media qualification)

The process-lifetime logical-allocation ledger now writes/fsyncs each increasing peak under its lock before payload acquisition. No cache-ready reset; accounting, publication, external attachment, inherited fork and reused exec epochs fail closed. A native ordinary child preserves its released 1MiB peak across actual wait0; partial/failed streams cannot be promoted to complete success.

The original reader had a P2: opening a FIFO could block. Its original bytes and negative independent review remain archived. V2 uses nonblocking open plus path/FD identity checks; real FIFO-without-writer and path replacement after open/before validation and during read are rejected. The corrected reader's Windows55 and Linux55, actual live/final capture, ten retained native success/failure streams and three filesystem regressions passed. Earlier native11 scenarios plus six original ledger cases retain their original source hashes. The observer compiles against the exact SDK. Independent component review accepts this limited scope.

Reversible originals and source snapshots: durable-tracked-peak-v2/index.json. Current core build is still pending and is not accepted here. This ledger measures logical live ownership; retained physical freelist capacity, all short-lived helper/restart/final epochs, exec chain and other media owners remain incomplete. Full media bound, source Task15/current CI, original15 ATS cases, current-source warm-cache revocation and formal POC qualification are not granted. No ATS service or new media experiment was started by these component checks.

Next: finish exact core build; account for retained pools and all process windows/other media owners; ordinary sync a fully accepted stable main, run new fixed-source gates and CI, then obtain explicit representative input/resource/window acceptance and execute the full POC. Old failed/unknown methods remain preserved. Actual Task roles, claims, lease and base remain unchanged by this component commit.


## Retained ioBufAllocator capacity component (full POC still pending)

The exact native ink_queue.cc grow site now durably charges checked page/huge-round-up backing capacity before any allocation. Returning/reusing blocks does not decrement that backing charge. Original logical IOBufferData capacity remains deliberately double-counted. The current lab requires the entire current instrumentation manifest, preventing reuse of the former five-file core merely because its ledger/journal headers match.

The old actual core is a preserved negative: 65536 backing bytes versus a 40960 logical peak, with logical current zero after return/reuse (actual exit2; physical coverage failed). The new six-file/three-header ordinary-user core builds and links successfully. The same actual pool driver passes: backing65536, held/peak106496, return/reuse65536; sixteen concurrent payloads retain their actual pool backing too. Independent implementation, actual build/behaviour and failure/fallback reviews accept their stated scope.

Real private invalid-product and 37-byte partial-journal cases exit70 before the allocation call returns, preserving failed/partial raw and rejecting complete epochs. The actual unavailable-hugepage profile has huge enabled/2097152, direct huge allocation ENOMEM, normal 4096-byte target mapping pages, backing2097152 and retained current2097152. Hugepage success remains unmeasured. Smaps mapping Size is not a media-payload measurement, and journal peak rows do not claim to record final release snapshots; return/current facts come from actual driver snapshots/stdout.

Old/current real runtime receipts were exercised through lab.prepare with synthetic input/exporter setup only: the old core is rejected at the exact manifest guard and the new core reaches the intercepted pre-run-creation boundary. No input media, sandbox, listener or ATS workload was created. Manifest draft/no-qualification flags remain the original build-input snapshot; actual component results are in immutable test/review archives, not retroactively rewritten flags.

Recoverable originals: retained-pool-capacity-v1/index.json; the previously accepted five-file build/link/API evidence is separately archived in durable-core-build-v1/index.json. Remaining: exact all-helper/restart/final epochs and exec chain, other ATS/media owners and alternative allocation paths as applicable, complete media-domain approval, stable-main sync/new fixed-source Task15/CI, original15 cases/current-source hot-cache revocation and full qualification. No new media experiment is approved here.


## Same-PID exec gate component (not integrated or full-family proof)

The ordinary-user ELF gate binds the actual owned Python gate birth and verified target descriptor before GO. It waits for the entire bounded control stream to be exactly one G followed by EOF; the former prefix-only read was found by static independent review and its original bytes remain archived. The parent preserves gate and target identities separately without rewriting Popen.args, uses pidfd ownership and bounded cleanup, and requires actual wait0 plus a fresh trusted same-PID/start core journal before accepting the tracked epoch. Clean CLOEXEC EOF alone never proves exec or completion.

The exact reviewed native driver/core ran once after the actual POC-005 scan had completed. All22 real/injected component cases passed: held same-birth target identity, a fast target exiting before any target proc read with a retained3MiB peak, no-journal exit0 rejection, core70/partial37-byte journal rejection, actual exec EACCES13/ENOEXEC8 exit71, hash/input/directory guards, actual pre-exec death producing empty EOF but no completed epoch, stopped-gate deadline and owned kill/wait, malformed/split duplicate/missing GO, duplicate activation, injected partial setup and before/after component changes. Every case returned to the same6 open parent FDs. Injected setup failures are labeled and are not claims of actual kernel EMFILE. Native private originals and their terminal Windows export were independently compared.

Recoverable original sources, controls, native raw journals, partial/failure outputs and independent decisions: same-pid-exec-gate-v1/index.json. No ATS service, network request or media workload was started by these checks. The gate is not yet integrated into lab.py. Integration must reap every owned launch in finally, including helper/restart/final/error paths; finish_journal alone does not abort a still-live child. All-descendant coverage, no subsequent uninstrumented exec and the full-media upper bound remain unproven. Existing pool/core results retain their own source identities. Remaining: full lab integration and all process/media owners, stable-main sync, current fixed-source gates/CI, original15/current hot-cache revocation and full POC qualification.


## Opt-in eager core journal component (full process/media closure still pending)

The same translation unit now initializes the existing ledger after its loaded-PID initialization when an explicit nonempty journal directory is present. Its ordinary C++ initializer publishes actual initial zero before main even when a linked helper never calls a Guize API; no constructor-priority attribute, ABI/parser/header change, baseline subtraction or reset is introduced. Missing/empty environment preserves the former lazy version-probe behavior. Existing precharge, sticky external/fork/exec rejection and deliberate retained-pool overcount remain.

The exact six-file/three-header native v3 source was built and privately installed by an ordinary user; all four stages actually exited0 (make242.256s). The first unexecuted build method had two static timeout/group/PID-record defects; its exact rejected f677 bytes were reconstructed against the prior independent SHA and archived with the rejection. The accepted 5a006 correction records PID/PGID/birth and anchors timeout group cleanup to the unreaped leader, always failing a timeout. This actual build had no timeout, so the cleanup branch is not reported as runtime-tested.

Five new real checks passed: a --no-as-needed linked zero-API target demonstrably loaded the old v2 core via actual DT_NEEDED and executable maps yet exited0 without a journal, correctly rejecting completion; the same target with v3 had one358-byte initial-zero record before main and a real wait0; a post-prepare0500 directory violated the journal-mode contract and exited70 before main, without claiming an actual write/fsync failure; unset and empty directory --version probes each returned9.2.3/exit0. Separately all22 existing gate cases passed on the actual v3 core. The earlier no-journal gate target returns before dlopen and remains a different negative, not the loaded-core counterexample.

Independent result review checked192 native/export files128399bytes byte-exactly and all27 recorded exact PIDs gone. Reversible build/raw/source/decision records are in eager-core-journal-v1/index.json; original v2 builds and failed/partial streams remain untouched. No ATS service/network/media workload ran. This is limited component acceptance: lab helper/start/restart/final integration, actual effective NULL crash-helper/empty TLS configuration, full exec/descendant coverage and the explicitly approved media domain still remain. Source audit does not cover Python Origin/Gateway or kernel buffers by silently calling them ATS allocations. Current fixed-source gates/CI, original15/current hot-cache revocation and full POC remain pending; no new experiment or full V1 acceptance follows.


## Owned-epoch lab control integration (real ATS/media execution still pending)

The instrumented lab code now routes helpers and each server start/restart/stop/error wait through the accepted OwnedEpoch bridge, with separate exclusive per-launch journal/launch/closure records. Actual gate and target identities remain distinct; helpers close in finally, live snapshots use the current private journal, and only real wait0 plus the strict journal and stable configuration can accept a tracked epoch. Seven effective configuration files are pinned before/after launches; the diagnostic preparation explicitly fixes NULL crash helper and a private empty TLS multicert file. The process signal/reap race now catches ProcessLookupError and still performs the owned wait.

Six control-only native cases passed and were independently read: the real v3 --version helper used a private runroot and initial-zero journal/accepted closure; an explicitly synthetic false ELF only tested nonzero cleanup; changed configuration before GO produced no child, and changed configuration after actual exit0 rejected acceptance; legacy nonlive --version retained its existing behavior; an actual held target was told to exit and genuinely reaped between abort poll and the original real pidfd syscall, which raised ESRCH3. Abort still recorded actual wait0/stateaborted/completefalse. This imposed real reaping interleaving does not assume that a zombie signal must return ESRCH. The runtime captured OSError is retained; there was no additional syscall tracer. All54 native/export files43443bytes were byte-exact, four recorded owned children plus runner were gone. Legacy has actual CompletedProcess0/raw but no recorded PID; none was fabricated. Portable buffer/live/durable reader regressions additionally passed62 tests.

Reversible source/raw/decisions are in owned-epoch-lab-control-v1/index.json. These tests deliberately used no-input/no-user control fixtures, not lab.prepare's approved sample/resource profile. They did not start ATS services or fabricate cache-ready, and --version does not verify application of live ATS configuration. Actual verify_config, clear_cache, genuine cache-ready, server graceful-stop/exit code, restart/final closure and helper30s timeout remain to be exercised under the required source/input/resource/window conditions. Nonzero target epochs remain rejects. Process-family/no-later-exec and the complete approved media domain are still unproven; current source gates/CI, original15/current hot-cache revocation and full POC remain pending. No new service/media/experiment permission follows from this archive.


## Private PID-namespace lifetime method (two non-media cases only)

The existing engine was read without starting the old retained container: Docker29.8.0/kernel6.18.54.1/cgroup2, UID1000, private/default PID namespace, private IPC/cgroup namespace, networknone, readonly root, no mounts/devices, no capabilities and no-new-privileges. The first read-only template encountered a missing optional StopSignal field; its raw and exact reader remain retained. The corrected read used an optional lookup and observed null, without changing a container or host setting.

The prospectively approved V1 control attempt created a new stopped container but Docker refused to start its local logger: default compression is incompatible with max-file1. Actual start CLI1, created/Pid0/zeroStartedAt and the logger error remain failed; no PID1/workers began and the second case was not created. V2 was a separate reviewed namespace/name/output/window with explicit compress=false, retaining max-size1m/max-file1 and all prior limits. No daemon edit, restart, image pull, root, host cgroup write or deletion occurred.

V2 actually executed two finite cases on the existing fixed Python image, each with private namespace PID1 and two live setsid workers in different process groups; one worker was adopted after its intermediate parent actually exited0/waited. Actual proc status/stat/namespace/cohort and engine state preceded the signal. USR1 caused the PID1 handler to exit0 (1.8276s case); engine KILL ended PID1 with137 (1.3881s case). All34 actual CLI commands returned0 with both stdout/stderr EOF,68 retained raw streams match their hashes, total4.1569s, within the unchanged90s/65s budgets and25s child alarms. Independent fresh reads confirmed both V2 containers exited/Pid0 with0/137 and the old V1 still created128 with its original logger error. All containers and raw remain retained.

The fixed control-profile lifetime method is accepted. Namespace-wide termination is inferred from actual private PID1 exit plus Linux PID-namespace semantics, not from fabricated individual worker wait codes. Sequential namespaces can reuse an inode; these two cases do not claim simultaneously unique namespace IDs or directly observed namespace-object destruction. See namespace-lifetime-v2/index.json and the independent ca466a5d result. The earlier attach/EXITKILL incompatibility remains; no strace, ATS or media run occurred. Actual integration of containment, complete execve/execveat/family observation, same-run untraced latency and all non-ATS/external media ownership remain unresolved before formal source gates/CI, representative experiments, original15, hot-cache revocation and POC qualification. Kernel memory.peak remains rejected as a strict bound.


## Fixed first-exec control component (actual four cases; lab integration pending)

The default-off OwnedEpoch.fixed_single_exec caller pins the interpreter, bootstrap and literal29-instruction native-x86_64 policy, transfers one private CLOEXEC listener, binds the real birth/ELF/argv/environment and sends at most one CONTINUE. The final listener closes on every path. Fork/vfork/non-thread clone and filter replacement are rejected; clone3 returns ENOSYS and later exec is not serviced. This is a fixed trusted bootstrap, not a general hostile-code sandbox.

Current Linux14 pure/pipe tests and Windows62 reader regressions passed with actual wait0, zero failures/errors/skips and unchanged source hashes. The first caller test run11pass/2fail used an incomplete fake Popen object; only that fixture changed. A subsequent independent P2 found a listener ownership gap before argument lookups; the actual source was corrected and a real-pipe missing-target rejection added before the14-case run. The helper's earlier deadline/FD-consumption findings and all original raw/source versions remain losslessly archived.

V1's WSL launcher actually exited1 with WSAETIMEDOUT before any controller output marker. It is not a kernel/filter failure; original UTF16 bytes were not locally captured and that limitation remains explicit. The Windows Docker Desktop health call also timed out. After the observed host boot, fresh WSL and the existing Ubuntu Docker29.8.0/kernel6.18.54.1/cgroup2/builtin-seccomp engine reads actually completed0. No host-service restart or security relaxation was performed. V1 approval was not extended or relabeled.

Separately approved V2 executed once in one existing-image private PID namespace as UID1000/caps0 with default seccomp, no-new-privileges, readonly root, no network/host mounts and finite tmpfs/CPU/memory/PID limits. Four native cases passed: first owned FDexec plus actual C main/syscall denials and working pthread; last listener closed before GO; a deliberate sole parent duplicate holding syscall322 pending until lastclose; and an actual NOTIF_RECV timeout followed by owned SIGKILL/wait. Target outcomes were0/71/71/-9, each FD count4 to4. Ten actual CLI waits returned0 with20 complete raw streams;33 exact exported files total22644B. Independent4487a8ae accepted this control compatibility only; the container is stopped/Pid0/exit0 and retained. It does not prove pthread's internal syscall selection, dynamic ATS loader/journal, media memory domain or latency.

The lab still uses the old caller. Its origin and gateway threads are active during ATS launches and HTTP-triggered restart/helper paths; the current fixed helper requires an actual singleton native main thread, exclusive default/unblocked SIGALRM and a finite setup/activation deadline on every launch. Moving only first startup before threads is insufficient. Resolve that concrete ownership path before enabling the fixed mode in lab; preserve real birth/pidfd/wait, journals, all media owners, untraced latency and original15/hot-cache revocation. Current source is an unpublished component, not whole-source CI, POC completion or Ready. See single-exec-control-v1/index.json for originals and explicit limitations.


## 当前实施上下文

已普通合入完整接受的实际主线 760f6c5838597d1d66c0a536ecbf440ef5a7dfec，同步提交 8fabc3137c60e8eed07024cd8101777396bf21dc。该主线七项本地检查与CI841742项/1628.73s/零测试跳过及独立审查已通过，OPS-013正常完成。仅刷新自身Task/Active基线和交接；原角色、claims、order2、租约与缓存修复代码字节保持。先前47090d6在第六项history失败（前五项通过、后九项未执行），另行44项组件测试通过；原始结果分别完整归档，组件通过不替代整体接受。新固定源Task15、44项组件及同头CI仍待验证；原15项实测、当前源热缓存撤权、完整media数域与POC资格仍未完成，没有新的ATS实验批准。

### 历史同步时点（原样保留）

独立干净集成副本已从已发布1cc28415f2f2383b0272a518828d7ee3660f7545普通合入实际接受主线 43270da544d9df3da68a45d2eca3e0a2fed2de6e，同步提交为 5d7b0abad1da1f88fe4147e03970036e37c71426。该主线七项本地检查、CI839742项/1581.41s/零测试跳过及独立完整接受已完成。当前仅前向更新自身Task/登记基线和交接；状态、角色、claims、order2和原租约不变，缓存切片读取修复现按既有独立组件接受的精确字节导入；新固定源验收尚待执行。新的固定源检查/CI及任何新实验均待执行；实际主线OPS-013仍review，不能借此提前释放high或登记后继。

### 历史实施上下文（保留原始时点）

当前实现已通过普通 merge 同步 POC-005 预留实际主线 f2e0150265e0c1eeca5f69fe85708b2434e5ee79；自己的 Task/登记 baseSha 与验证命令前向绑定该主线，原始创建基线 11c32830c0d1bb8ccdcc04aa278876065bce1f33 与历史结果保留。POC-005 的状态、租约和实现权不变；该实际主线五项及POC协议通过，完整CI816通过713项/1445.86s、无测试跳过，登记主线已接受。

PR #133 已普通合入真实 main 11c32830c0d1bb8ccdcc04aa278876065bce1f33，源2fa51e8的local15、同头CI807（713 passed/1463.80s/零跳过）、独立当前源内容和全部实际审查线程已通过。实际合并parents/tree、五项主线检查及独立POC协议检查均已核验。主线push CI808仍待最终结论，不宣称完整主线已接受。依据docs/25第6.2节，从包含预留的最新main开始可逆Own实现；原角色、路径、风险、顺序与租约保持。当前未审批样本/资源或运行正式实验；实际源和输入/配置经独立事前批准后才执行。

## 背景与目标

Issue #131：https://github.com/ElectricDogCN/Guize/issues/131 。GZ-010及BASELINE-GZ-021/GZ-022在实际接受main 44e5200ed506d30c0abc83ca38f1d6912cbab1c1已完成。原W2的POC-003/005完成前，GZ-006的W3激活被真实波次门禁拒绝；本任务保持原依赖、范围、15项测量及阈值，先依法登记，再执行真实ATS实验。

## 输入与输出

- 输入：specs/poc/plans/POC-003.yaml、POC-PROTOCOL-V1、既有policy/resources/samples/Schema/templates、REQ-V1-0003/0008、NFR-V1-PERF-002、module-ownership.yaml、AGENTS/Never Rules及已接受GZ-021/022。
- 登记输出仅Own Program/POC镜像状态、Active/Task/Evidence；不批准样本、不配置或执行实验。
- 实现输出：隔离ATS/origin/先鉴权gateway、确定性Range驱动、配置、全部原始观测、typed报告、执行/结果和独立批准；local-v1/v1使用自身profiles/local-v1/v1/唯一slot。
- 外部ATS及2GiB固定Range样本是历史准备，正式执行前重新核实版本/插件/实际输入字节、追踪引用与批准；不把生成统计、版本探测、外部未批准manifest或模拟代理当实验通过。

## 允许范围

- 预留已完成；当前仅在已登记实现路径及自身Task/Evidence内开发，Program tasks/pocs、Active仅作自身合法阶段转换；Program issue保留null，实际Issue131通过Task/Registry关联。
- `poc/POC-03-ats-range/**`
- `evidence/POC-003/**`
- `adr/**`
- `specs/poc/results-index.yaml`

## 禁止范围

- 不改冻结plans/program/policy/resources/samples/Schema/POC验证器、治理检查/工作流、旧账本、其他任务/租约/结果、产品需求、backend/services/edge、生产数据或凭据。
- 共享结果索引只改自身行；不把本机Window/WSL的ATS结果冒称公网、CDN或生产规模，不改变GZ-010 executionEnabled=false，不预占POC-005的样本/资源/结果。

## 依赖与集成顺序

- 原dependsOn为GZ-010；BASELINE-GZ-021和BASELINE-GZ-022均须真实普通Completion且在实际接受基线，现已满足。W1终态，W2开放；全局3活动/1高风险及critical独占规则保持。
- 先当前预留的真实源检查、完整同头CI、独立审查、正常合并和实际主线验证。随后使用原登记实现分支chore/POC-003-ats-range，从届时最新main开始实现，不提前运行实验。
- 与POC-005共享poc-results组，ADR/结果按order2→3串行集成。两项在同物理主机的ATS延迟/磁盘与metadata吞吐/RSS测量窗口不重叠，并记录实际负载。

## 独占写范围

- `poc/POC-03-ats-range/**`
- `evidence/POC-003/**`

## 共享修改范围

- `adr/**`
- `specs/poc/results-index.yaml`

## 协作与交接

- Owner ElectricDogCN；Coordinator program-coordinator-agent；Implementer/Executor task-owner-agent；Reviewer independent-review-agent；Integrator integration-agent。样本和结果实际Reviewer须独立于实现者/执行者。
- 当前in_progress/implementer，实现分支chore/POC-003-ats-range，base 760f6c5838597d1d66c0a536ecbf440ef5a7dfec；原预留PR133（创建基线11c32830c0d1bb8ccdcc04aa278876065bce1f33保留）；UTC lease 2026-10-22T12:47:06Z至2026-10-29T12:47:06Z，不自动续租；order2，handoff位于evidence/POC-003/handoff.md。
- 下一角色核精确source/tree/文件/命令/退出码/CI与实际Issue后集成；执行前固定sample approval、resourceConfiguration及适用booking、measurementDomainReview、testedSource与executionWindow。当前均未批准或执行。

## 验收标准

- [ ] 实现保持Own路径；Program仅更新自己状态，旧Issue字段/定义/政策/兄弟任务/账本/实验协议保持。
- [ ] 合法预留接受后，独立批准实际样本、资源与适用数域，实际受测源/字节/执行窗口可追溯，全部记录符合冻结Schema。
- [ ] 原15项完整：Range字节、ETag、If-Range、Slice跨块覆盖、源更新失效、源中断有界恢复、partial不提升完整缓存、缓存命中、缓存盘分配清理、授权缓存键隔离、大文件流式及热/冷/慢源/多用户延迟。
- [ ] 完成门禁必须同时满足：原15项正式测量/冻结矩阵及正式checker通过、下述独立热缓存撤权专项通过、独立结果审查通过；缺一不可，不将专项冒充原矩阵已覆盖撤权。
- [ ] 真实ATS/插件/配置及成功/故障观测可复现，量值仅从原始输出导出；同物理机测量窗口不重叠，所有失败与未测范围如实记录。
- [ ] 结果独立审查通过后只更新自己结果行；源/完整CI/实际主线接受后正常Review/Completion，保留真实实现身份。完整V1另行验收。

## 必须执行的测试

当前登记基线仍为 `760f6c5838597d1d66c0a536ecbf440ef5a7dfec`，Task frontmatter与Registry不变；已接受主线 `746e23e582501fa08380c3f3301bdc1774902f7c` 已普通合入作者分支（实际本地merge `43634485a674167c4c198bc406126f2127021a25`）。下列十五项使用当前集成基线，属于后续固定源验证命令，尚未执行；历史运行日志保留原来的source/base归属。

```bash
git diff --check 746e23e582501fa08380c3f3301bdc1774902f7c...HEAD
python scripts/check-task-file.py --task POC-003
python scripts/check-project-readiness.py
python scripts/check-schemas.py
python scripts/check-program-plan-integrity.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-program-plan-history.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003 --branch-name chore/POC-003-ats-range
python scripts/check-program-plan-transitions.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003 --branch-name chore/POC-003-ats-range
python scripts/check-program-plan-finalization.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003
python scripts/check-program-lifecycle-guards.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003 --branch-name chore/POC-003-ats-range
python scripts/run-program-lifecycle-gate.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003 --branch-name chore/POC-003-ats-range
python scripts/run-agent-coordination-gate.py --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c --head-ref HEAD --task POC-003 --branch-name chore/POC-003-ats-range
python scripts/run-task-scope-gate.py --task POC-003 --base 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-evidence.py --task POC-003
python specs/poc/check_program.py --task POC-003 --base-ref 746e23e582501fa08380c3f3301bdc1774902f7c
python scripts/check-markdown.py
```

以上十五项对每个候选登记源重新执行，完整治理在同头云端CI实际运行并审计零失败/错误/测试跳过。父源daed2f533a726bef3f519ce7f14109eee6447c25已真实通过local15及CI805；三项P1导致整体未准入，本修复源不得继承通过。实际日志、命令、退出码、源/tree、CI与发现见自身Evidence。正式实施另执行自身驱动全部原矩阵及`python specs/poc/check_program.py --profile local-v1 --require-results --poc POC-03`。

实现代码还必须直接执行`python poc/POC-03-ats-range/test_lab.py`，验证实际八项离线边界且零跳过；该结果不替代以下真实沙箱专项。

缓存导出修复另外执行`python poc/POC-03-ats-range/test_cache_body_bounds.py`的三项真实离线回归及`python poc/POC-03-ats-range/test_cache_probe.py`的四项catalogue回归；最大读取量绑定实际选中Slice长度，超长或读取中增长均拒绝，不裁剪原始导出文件。既有Windows/Linux各7项组件结果及独立接受保留在cache-body-bounds-forward-20261025/，新源不继承整体通过。

可选instrumented profile还须执行`python -m pytest -q -p no:cacheprovider poc/POC-03-ats-range/test_live_buffer_probe.py`，要求实际27项而非直接运行仅含pytest定义的文件；并执行`python poc/POC-03-ats-range/test_live_component_native.py`的两项实际Linux子进程映射测试。六项ledger场景、精确header/patch/core/observer构建和组件绑定结果分别保存。默认stock profile保持；真实新观测生命周期、具体输入/资源/数域/窗口及结果必须另行独立批准，不能从这些离线/构建记录继承实验通过。

### 实现阶段必须独立执行的热缓存撤权专项

预留正式接受、样本/资源和适用数域独立批准后，在既有独占范围内实现并直接执行`python poc/POC-03-ats-range/test_warm_cache_revocation.py`，将该命令、实际源、退出码、原始请求/响应及gateway、ATS、origin计数证据纳入结果交接。该命令是完成前必需的独立机器断言，不能由发现零测试的命令替代；文件缺失、无真实沙箱、零执行用例、跳过断言或只打印PASS均不得成功退出。当前metadata预留不新增测试实现、不执行实验、不批准输入，也不改变冻结RANGE_MATRIX_CASES、Schema、协议或原15项。

专项先用同一仍未过期grant实际成功读取并确认ATS热命中，再通过真实鉴权状态撤销该grant。撤权后重放请求的鉴权时刻也必须仍位于该grant原始有效区间内，记录该区间、真实撤权生效时间与鉴权拒绝原因revoked，证明403由撤权而非自然过期触发。在对象版本、URL、Range、旧凭据不变，缓存仍热、不purge、不重启ATS的条件下，撤权生效后的旧凭据请求必须HTTP403且零受保护媒体字节；拒绝窗口必须证明该请求零ATS转发、零受保护缓存读取、零新增origin读取，不能先读热缓存后拒绝。独立控制观测应证明旧缓存仍热，并保留拒绝窗口前后精确计数和原始观测。专项报告与原矩阵分别保存，原15项正式checker AND 撤权专项 AND 独立结果审查共同构成完成条件。

## 风险

ATS缓存与授权/版本失效、源中断partial、输入变更、配置或源身份漂移、同机资源竞争、环境准备冒充性能结果。使用冻结协议、实际观测与独立批准，不降低门槛。

## 回滚

登记未合并可撤回；已预留按合法取消释放Own租约。实现仅操作自建隔离实例/缓存/实验进程，停止后核监听与清理；保留固定输入/Evidence/历史，不重启Docker/WSL或操作其他项目服务。已合入缺陷受审查前向修复或回滚。

## Evidence

自身Evidence记录Task/Issue/源/实际命令/退出码/限制和下一角色。父源daed2f5的实际local15/CI805及三项P1已归档；该父源整体未准入。本次修复源的检查、CI、独立审查和主线接受待执行，实验未执行，前序结果不继承。


## 前向代表性输入支持（组件实现）

当前在合法in_progress实现分支上，为完整媒体观测准备显式representative-v1输入配置；固定prototype64MiB及其两哈希、原预算、冻结协议/原15项和旧失败保持。真实文件逐字节流式哈希、实际长度和身份校验、单文件/来源请求及累计响应预算绑定均为Raw Lab组件，不授样本或实验批准。Windows身份时间字段差异的首个失败及前向修正原件在evidence/POC-003/input-profile-v2/index.json；修正后两平台各25项实际通过、零跳过。

新固定源除既有15项与组件检查外，必须直接执行 `python poc/POC-03-ats-range/test_input_profile.py` 的9项实际离线用例，并保留旧lab8、revocation-binding2、cache-body-bounds3和cache-probe4的相关回归。当前结果仅按脏代码精确4哈希绑定；完整源门禁、CI、实际完整媒体域、原15项及新输入/资源/窗口的事前批准仍待办理。进入Review前同步届时已接受主线；Gov历史修复52a4779尚未合入，不重复已知旧history失败或提前运行ATS。

独审V2发现入口先无界加载manifest，回执原件保留。V3在lab.prepare入口最多实读65537B，超过64KiB即在读取runtime/创建run前拒绝，再以同一raw哈希和解析。新增真实入口回归在修正前8pass/1failure，修正后Windows/Linux各26项实际通过、零跳过；初次red harness未纳入新类、仅旧8项通过，明确不算red。当前4哈希和全部原件见evidence/POC-003/input-profile-v3/index.json。V3独立组件复核已接受、mustFix为空；回执SHA256为9c1e712fa28f91b15f275c10900c7f1d2d14c1e58fc08b6a7fb207dd978a6d05，其他完整源/数域/实验/资格边界保持。

## 前向代表性缓存分批组件

较大输入按真实大小校验并以最多128-key的原生请求分批导出，原每进程8-job/16-control/512MiB额度及原型128-key/128MiB保持。当前Windows10/native14仅组件接受；生产者模拟，原生ATS、完整sourceCI、原15和资格仍待验。固定源在既有检查外执行 test_representative_cache.py 与普通用户Linux的 test_representative_cache_native.py。cgroup peak严格上界路线已由实际内核复核拒绝；回到已有同步ledger的完整所有权和窗口覆盖。Evidence见representative-cache-batches-v2及其保留的原始失败。

## Fixed raw cache export/comparison/reassembly component after local246e264

Export comparison now uses two guarded64KiB backing slots with raw readinto and complete partial writes; native exports are never trimmed. Ordered reassembly uses one guarded64KiB raw slot. Exact-byte/hash/equality, selected-Slice bounds/growth rejection and error/release obligations remain. Three old bound and three lifetime cases were adapted to the streaming API with exact prior test preimages retained. Six new actual raw-file cases cover multiblock/short reads/partial writes, short and mismatched references, zero write progress, retained over-allocation rejection and assembly slot release.

Windows60/Linux69 related tests, all25 actual child waits0, no skips. Source/raw/preimages in cache-stream-io-v1/artifacts.zip with per-entry index.json. This is a local component awaiting independent review; no new source, Ready/main, runtime/HTTP/native aggregate/full-window, resource/window, original matrix/fresh revocation or formal POC acceptance is supplied. Frozen checker, thresholds, Program/Active, original lease/roles and old originals remain unchanged. Next: independent component review, then finish actual runtime/HTTP/native and closed-window aggregation; sync latest accepted main and qualify whole source before any approved workload. Use ordinary reviewed forward rollback, retaining evidence.

## Owned request-window closure component after local31a6cc8

Controller HTTP sockets are synchronously admitted before worker start; teardown retires only owned sockets and waits for actual admitted/finished equality. Delayed workers cannot disappear from closure. Collector closes request admission and records zero-active closure while preserving cumulative peaks; active work and late requests are rejected. Matrix and fresh revocation CLI explicitly seal their request windows; revocation probe bytes release before its success seal. Controller emits a new immutable request-window receipt only after owned HTTP/ATS teardown and zero media counts; cleanup failures retain a distinct nonclosed receipt.

Windows65/Linux74 related regressions/all27 actual child waits0/no skips. V1 Windows5/one real timeout and old Linux74 pass are retained with exact original draft source; no timeout, threshold or assertion was relaxed. HTTP makefile references motivated shutdown+detach+native close, verified by a separate private Windows socket diagnostic. Source/raw/preimages and offline fixed-image Python3.12.15 byte-match inspection are in request-window-v2/artifacts.zip and index.json.

This local component is pending independent review. Closed request intervals are not aggregate memory or native epoch acceptance; actual runtime binding, HTTP/native intermediates, hash/sendall and full native aggregation remain pending. No source/Ready/main, resources/window, original matrix/fresh revocation execution or formal POC qualification. Original policies/thresholds/roles/lease and old evidence remain; use a reviewed ordinary forward rollback retaining originals.

## Forward V3 request-close ownership correction

V2 was not committed: independent review found a real worker/controller native shutdown/close race and blocked component acceptance. Its exact negative review, candidate and standard ZIP (including the earlier Windows timeout) remain in request-window-v3/artifacts.zip and unchanged request-window-v2/. V3 uses the same existing request_condition for normal worker shutdown_request and the controller full shutdown/detach/nativeclose sequence. A sixth real HTTP thread race case actually failed on the old code (one test/exit1), then passed after the ownership lock. No timeout/threshold/assertion was relaxed.

V3 Windows66/Linux75 related regressions/all27 child waits0/no skips;37 current source snapshots and original raw/negative/red records are indexed at request-window-v3/index.json. Independent V3 review and ordinary local commit remain pending. All full-source/runtime/native aggregate/new experiment/POC boundaries from the preceding entry remain incomplete; this component only closes actual owned request intervals and their counters.

## Instrumented Python runtime component-byte binding after local424bab7

Instrumented prepare/controller/Collector now verify a fixed ten-component Python3.12.15/Linux-x86_64/OpenSSL3.5.7 profile before media input use (Collector before output creation). Seven native components must be the actual executable mapped device/inode, not merely equal bytes at another path; stdlib paths/bytes, ABI, IO size, hash backend and disallowed overrides are checked. Each future process records fresh PID/startTicks/maps and profile digest; controller closure and Collector receipt reference their own binding. Profile and helper are part of implementationSources.

Eight final real fixed-image tests and Windows66/Linux75 related regressions/all28 current child waits0/no skips; exact current source/profile/native observations/raw in python-runtime-binding-v1/artifacts.zip/index.json. Initial capture and earlier eight checks remain separately attributed, with no asserted contemporaneous full helper preimage; current proof comes from final exact-byte execution.

This component awaits independent review and local commit. Runtime component binding is not a complete HTTP/hash/sendall/native transient bound or aggregate capacity proof, and future workload must execute these guards again. No full-source/Ready/main, sample/resource/window, original matrix/fresh revocation or POC approval. Frozen checker/thresholds/roles/lease and old evidence remain; next complete source-derived native terms and actual epoch aggregation, then sync latest accepted main and qualify whole source before approved workloads.

Future entry compatibility: the old c_call-profile readiness harness installed before lab.serve is incompatible with this pre-input no-profile guard. Do not reuse it as a current approved entry or relax the guard. Prepare a new hook-free or independently reviewed legitimate readiness method and qualify it with the new source before any original matrix/revocation execution.

## Explicit readiness callback component after local8dde1cc

Own lab.serve now accepts an optional callable from a reviewed in-process supervisor. It invokes that callable once, after the singleton EpochOwner setup, both owned HTTP listeners and the fresh listeners-started marker. CLI behavior supplies no callback. Invalid callback types fail before State creation; callback failures follow the same owned HTTP/ATS/owner teardown and propagate. The runtime guard remains unchanged; no profiling/tracing hooks are installed or disabled by this component.

Five real loopback tests cover live-listener/marker ordering, callback failure teardown, occupied gateway port, default entry and invalid callback ingress. Windows5 and the fixed Python3.12.15 image5 pass, plus the unchanged fixed-image runtime guard8; three actual child waits0, no skips, full selected source bytes stable before/after. Synthetic State/ATS metadata is explicit: these tests exercise real owned HTTP servers but do not start ATS or prove native owner initialization. Exact source/preimages/raw and prospective original-matrix entry are preserved in hook-free-readiness-v1/artifacts.zip and index.json.

The prospective entry starts the original Collector from this callback, preserving singleton owner initialization and all matrix cases without a frame/profile hook. Only syntax preparation has run for that entry; actual entry/native owner/media execution, independent component/method acceptance, complete HTTP/hash/native capacity model, full-source checks/CI and new sample/resource/window approval remain pending. No new experiment or formal POC acceptance is granted; frozen policies, thresholds, original roles/lease and old evidence remain unchanged. Rollback uses an ordinary reviewed forward change with originals retained.

## Fixed raw input-validation slot after local25867db

The independently accepted hook-free readiness component was ordinarily committed as25867db (Windows5/fixed-image5+runtime-guard8). A separate source audit found input_profile._actual_digest still retained its previous os.read result during the next read. This component uses a raw FileIO wrapper on the same already validated descriptor, closefd=False and one guarded1MiB bytearray/memoryview, including a one-byte EOF growth probe. Actual read counts, shortened/grown inputs and all before/after descriptor/path identity checks remain enforced; views, stream and FD close on success and error. Original prototype/representative size/hash/budget rules are unchanged.

Five new real-file tests cover empty/multiblock/short tails, partial reads, original I/O errors, invalid counts/premature EOF and same-length excess backing, with actual slot/stream/descriptor release. Existing shortening/growth injection now targets the real readinto path while preserving failure assertions. Windows5+9 and fixed Python3.12.15 image5+9 all pass, four actual child waits0/no skips;43 selected sources remain byte-stable before/after. Exact preimages, source snapshots and raw are in input-validation-fixed-io-v1/artifacts.zip/index.json.

This local component awaits independent review. It fixes one missing input-validation owner; HTTP/native HASH provider/copy/final/CPU-dispatch capacity, complete same-owner native epoch aggregation, full-source/main sync/CI and actual approved original matrix/fresh revocation remain pending. No experiment, complete aggregate, formal POC or V1 acceptance is granted. Frozen checker/schema/thresholds, original Task front/roles/lease and all earlier evidence stay unchanged; rollback is a reviewed ordinary forward change retaining originals.
