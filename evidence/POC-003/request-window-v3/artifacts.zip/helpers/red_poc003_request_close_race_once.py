"""Run the real close-ownership race against the still-unfixed v2 implementation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1';rel=Path('poc/POC-03-ats-range')
out=t/'poc003-request-window-v3-red';out.mkdir()
pins={}
for name in ['lab.py','test_request_window.py']:
    raw=(r/rel/name).read_bytes();(out/(name+'.preimage')).write_bytes(raw)
    pins[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
argv=[sys.executable,'-X','utf8','-B','-m','unittest','-v','test_request_window.RequestWindowTests.test_worker_and_controller_native_close_sequences_share_one_owner']
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=r/rel,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));code=child.wait()
data=(out/'stderr.raw').read_bytes()
record={'argv':argv,'pid':child.pid,'exitCode':code,'actualWaitCompleted':True,'sourcePins':pins,'stderrBytes':len(data),'stderrSha256':hashlib.sha256(data).hexdigest()}
(out/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert code==1 and b'worker entered native close while controller owned it' in data and b'Ran 1 test' in data
print(json.dumps(record))
