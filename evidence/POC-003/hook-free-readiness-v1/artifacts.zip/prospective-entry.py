"""Prospective hook-free original matrix entry; requires new source and experiment approval."""
from pathlib import Path
import hashlib
import json
import os
import signal
import stat
import sys
import threading
import time

RUN=Path('/runlab/work')
LAB_FILE=Path('/poc/source/poc/POC-03-ats-range/lab.py')
REPORT=Path('/runlab/raw-matrix-client.json')
COLLECT_FILE=LAB_FILE.with_name('collect.py')
COLLECT_SHA256='356302081bbfbfd0ea6dda0cb2fb1a97acc18f9d5c6a91ecdaeacae72bc99977'
START_NS=time.time_ns()
record={'kind':'PRIVATE_PID1_HOOK_FREE_ORIGINAL_MATRIX_RAW_COLLECTION_ONLY',
        'pid':os.getpid(),'uid':os.getuid(),'checkpointObserved':False,'clientCompleted':False,'rawCollectionCompleted':False,
        'scenarioOutcomesAssessed':False,'formalActorBindingAccepted':False,'fullMediaAccepted':False,'untracedLatencyAccepted':False,'formalPocAccepted':False}
client_thread=None


def save():
    # This is this method's current progress, not a fabricated source/owner wait.
    raw=(json.dumps(record,indent=2)+'\n').encode()
    fd=os.open(REPORT,os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw)


def ordinary_init():
    if (os.getpid()!=1 or os.getuid()!=1000 or os.geteuid()!=1000
            or threading.get_native_id()!=os.getpid() or len(list(Path('/proc/self/task').iterdir()))!=1):
        raise ValueError('private singleton ordinaryUID1000 PID1 required')
    status=dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    if status.get('Seccomp','').strip()!='2':raise ValueError('actual initial engine seccomp filter required')
    record['initialSecurityStatus']={k:status.get(k,'').strip() for k in ('NoNewPrivs','Seccomp','Seccomp_filters','CapEff','CapBnd')}
    if status['NoNewPrivs'].strip()!='1' or any(int(status[k].strip(),16) for k in ('CapInh','CapPrm','CapEff','CapBnd','CapAmb')):
        raise ValueError('no capabilities and NNP required')
    if any(os.environ.get(k) for k in ('LD_LIBRARY_PATH','LD_PRELOAD','LD_AUDIT')):
        raise ValueError('image Python must not inherit target library injection')
    if sys.getprofile() is not None or sys.gettrace() is not None:
        raise ValueError('do not replace an unrelated tracing/profiling hook')
    if signal.getsignal(signal.SIGINT) is not signal.default_int_handler:
        raise ValueError('actual Python selfSIGINT handler required')


def client(state):
    collector=None
    try:
        # No startup profiling/tracing hook is installed by this entry.
        hooks={'threadProfile':sys.getprofile(),'threadTrace':sys.gettrace(),
               'defaultThreadProfile':threading.getprofile(),'defaultThreadTrace':threading.gettrace()}
        if any(value is not None for value in hooks.values()):
            raise ValueError('no profiling/tracing hooks during original matrix collection')
        record['requestHookObservations']=hooks
        if hashlib.sha256(COLLECT_FILE.read_bytes()).hexdigest()!=COLLECT_SHA256:
            raise ValueError('exact original Collector code required')
        import collect
        if Path(collect.__file__)!=COLLECT_FILE:
            raise ValueError('wrong loaded original Collector module')
        output=Path('/runlab/original-matrix')
        collector=collect.Collector(RUN,output)
        collector.save()
        record.update(collectorOutput=str(output),collectorSha256=COLLECT_SHA256,
                      collectorStartedAt=collector.started);save()
        # No scenario normalization, request substitution or early PASS assembler.
        collector.matrix()
        value=lab.unique_json((output/'collection.json').read_bytes())
        if (value.get('status')!='RAW_COLLECTION_COMPLETED_UNASSESSED'
                or value.get('missingCases')!=[] or set(value.get('collectedCases',[]))!=lab.CASES
                or value.get('formalPocAccepted') is not False
                or value.get('canonicalRecordsGenerated') is not False):
            raise ValueError('original raw matrix did not finish all declared cases')
        record.update(rawCollectionCompleted=True,collectorFinishedAt=value['finishedAt'],
                      collectedCases=value['collectedCases'],rawRequestCount=len(value['rows']),
                      rawControlCount=len(value['controls']),rawCacheStages=len(value['cacheStages']),
                      totalResponseBodyBytes=value['totalResponseBodyBytes'],
                      rawCollectionStatus=value['status'])
    except BaseException as error:
        record.update(clientErrorType=type(error).__name__,clientError=str(error)[:512])
        if collector is not None:
            collector.receipt.update(status='COLLECTION_STOPPED_RAW_PRESERVED',finishedAt=lab.utc(),
                                     errorType=type(error).__name__,error=str(error)[:512])
            collector.save()
    finally:
        record.update(clientCompleted=True,selfSigintRequested=True,selfSigintTargetPid=os.getpid(),
                      selfSigintAtMonotonicNs=time.monotonic_ns());save()
        os.kill(os.getpid(),signal.SIGINT)


def ready_callback(state):
    global client_thread
    if record['checkpointObserved'] or client_thread is not None:raise ValueError('duplicate matrix checkpoint')
    if threading.get_native_id()!=os.getpid():raise ValueError('actual controller main-thread readiness required')
    if any(hook is not None for hook in (sys.getprofile(),sys.gettrace(),threading.getprofile(),threading.gettrace())):
        raise ValueError('readiness must remain free of profiling/tracing hooks')
    cfg=state.cfg
    marker=RUN/'listeners-started.json'
    fd=os.open(marker,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as stream:
        before=os.fstat(stream.fileno());raw=stream.read(4097);after=os.fstat(stream.fileno())
    if (not stat.S_ISREG(before.st_mode) or stat.S_IMODE(before.st_mode)!=0o600 or before.st_uid!=1000 or before.st_nlink!=1
            or not 0<len(raw)<=4096 or before.st_mtime_ns<START_NS
            or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)):
        raise ValueError('fresh bounded private readiness artifact required')
    value=lab.unique_json(raw)
    if (set(value)!={'startedAt','controllerPid','atsPid','bind','ports','formalPocAccepted'}
            or value['controllerPid']!=os.getpid() or value['atsPid']!=state.ats.pid or value['bind']!='127.0.0.1'
            or value['ports']!=[18231,18232,18233] or value['formalPocAccepted'] is not False
            or cfg['runDir']!=str(RUN) or state.epoch_owner is None):
        raise ValueError('actual listeners/owner/State/PID binding required')
    record.update(checkpointObserved=True,checkpointMonotonicNs=time.monotonic_ns(),actualListeners=value,hookKind='explicit pinned serve readiness callback; no tracing or profiling installed')
    record['profileAbsentBeforeClient']=sys.getprofile() is None and sys.gettrace() is None
    save();client_thread=threading.Thread(target=client,args=(state,),name='original-matrix-client',daemon=True);client_thread.start()


def main():
    global lab
    ordinary_init();assert not RUN.exists() and not (RUN/'listeners-started.json').exists()
    if hashlib.sha256(LAB_FILE.read_bytes()).hexdigest()!='3c04cfb0fcb39cc2eddf427199080e27c6db5a818d4b972304119817de2f67c3':raise ValueError('exact current readiness lab required')
    sys.path.insert(0,str(LAB_FILE.parent));import lab as module;lab=module
    lab.prepare('/configuration/config.json',str(RUN));ordinary_init();save()
    try:
        lab.serve(str(RUN),ready_callback=ready_callback);record['serveReturnedNormally']=True
    except BaseException as error:
        record.update(serveReturnedNormally=False,serveErrorType=type(error).__name__,serveError=str(error)[:512])
    finally:
        if client_thread is not None:client_thread.join(timeout=10)
        record['clientThreadStopped']=client_thread is not None and not client_thread.is_alive();save()
    passed=all(record.get(k) is True for k in ('checkpointObserved','profileAbsentBeforeClient','clientCompleted','rawCollectionCompleted','serveReturnedNormally','clientThreadStopped'))
    print(json.dumps({'matrixCollectionCompleted':passed,'formalPocAccepted':False}),flush=True)
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':main()
