"""Capture public fixed-image component pins offline; no input or ATS mounts."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1';code=r/'poc/POC-03-ats-range'
out=t/'poc003-python-runtime-profile-capture-v1';out.mkdir()
image='sha256:df18428df8a0f9189c84e7424d214b4c50092af1f9dca5842a00c41c39bda316'
program="import sys,json;sys.path.insert(0,'/poc');import python_runtime as p;o=p.capture_runtime();print(json.dumps({'profile':p.pinned_profile(o),'observed':o},sort_keys=True))"
argv=['docker','run','--rm','--pull','never','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
      '--user','1000:1000','--pids-limit','32','--memory','256m','--cpus','1','--mount','type=bind,src='+str(code)+',dst=/poc,readonly',
      '--entrypoint','python3',image,'-I','-B','-c',program]
started=datetime.now(timezone.utc).isoformat()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);exit_code=child.wait()
raw=(out/'stdout.raw').read_bytes();error=(out/'stderr.raw').read_bytes()
row={'kind':'OFFLINE_FIXED_IMAGE_PROFILE_CAPTURE_NO_MEDIA','argv':argv,'pid':child.pid,'exitCode':exit_code,'actualWaitCompleted':True,
     'startedAt':started,'finishedAt':datetime.now(timezone.utc).isoformat(),'stdoutBytes':len(raw),'stdoutSha256':hashlib.sha256(raw).hexdigest(),
     'stderrBytes':len(error),'stderrSha256':hashlib.sha256(error).hexdigest(),'mediaMounted':False,'atsStarted':False,'experimentExecuted':False}
(out/'execution.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
assert exit_code==0,error.decode(errors='replace')
data=json.loads(raw);profile=data['profile']
assert profile['baseImage']==image and data['observed']['uid']==1000
profile_raw=(json.dumps(profile,ensure_ascii=False,indent=2)+'\n').encode()
with (code/'python-runtime-profile.json').open('xb') as stream:stream.write(profile_raw)
row.update(profileBytes=len(profile_raw),profileSha256=hashlib.sha256(profile_raw).hexdigest(),componentCount=len(profile['files']),
           actualMappedNativeComponents=data['observed']['actualMappedNativeComponents'],aggregateCapacityProofComplete=False)
(out/'results.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:row[k] for k in ['exitCode','profileBytes','profileSha256','componentCount','actualMappedNativeComponents','experimentExecuted']}),flush=True)
