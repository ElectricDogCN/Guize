"""Forward ownership-lock correction with actual close-race regression."""
from pathlib import Path
path=Path(__file__).resolve().parent/'verify_poc003_cache_stream_v1_once.py'
source=path.read_text(encoding='utf-8')
assert "names=['test_cache_stream_io.py'" in source
source=source.replace('poc003-cache-stream-v1-','poc003-python-runtime-v1-')
source=source.replace("names=['test_cache_stream_io.py'","names=['test_request_window.py','test_cache_stream_io.py'")
source=source.replace('246e264a9674326ffab4a03f11255d8580ea0ee6','424bab779a5d45f8d3708c7030fcf34ffd1936f0')
source=source.replace("60 if platform=='windows' else 69","66 if platform=='windows' else 75")
source=source.replace('ACTUAL_CACHE_STREAM_OFFLINE_DRAFT_COMPONENT_CHECKS','ACTUAL_REQUEST_WINDOW_OFFLINE_DRAFT_COMPONENT_CHECKS')
exec(compile(source,str(__file__),'exec'))
