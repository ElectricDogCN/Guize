"""Eight actual immutable-image tests; no ATS, input mounts or media workload."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1';code=r/'poc/POC-03-ats-range'
out=t/'poc003-python-runtime-v2-fixed-image-checks';out.mkdir()
files=['python_runtime.py','python-runtime-profile.json','test_python_runtime_binding_native.py','lab.py','collect.py']
pins=lambda:{name:{'bytes':(code/name).stat().st_size,'sha256':hashlib.sha256((code/name).read_bytes()).hexdigest()} for name in files}
before=pins()
argv=['docker','run','--rm','--pull','never','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
      '--user','1000:1000','--pids-limit','32','--memory','256m','--cpus','1','--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=16m,mode=1777',
      '--mount','type=bind,src='+str(code)+',dst=/poc,readonly','--entrypoint','python3',
      'sha256:df18428df8a0f9189c84e7424d214b4c50092af1f9dca5842a00c41c39bda316','-B','/poc/test_python_runtime_binding_native.py']
started=datetime.now(timezone.utc).isoformat()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);code_result=child.wait()
raw=(out/'stderr.raw').read_bytes();after=pins()
result={'kind':'ACTUAL_FIXED_RUNTIME_COMPONENT_TESTS_NOT_MEDIA','before':before,'after':after,'argv':argv,'pid':child.pid,
        'exitCode':code_result,'actualWaitCompleted':True,'startedAt':started,'endedAt':datetime.now(timezone.utc).isoformat(),
        'stderrBytes':len(raw),'stderrSha256':hashlib.sha256(raw).hexdigest(),'experimentExecuted':False,'aggregateCapacityProofComplete':False}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(raw.decode(),flush=True)
assert code_result==0 and b'Ran 8 tests' in raw and b'skipped' not in raw and before==after
