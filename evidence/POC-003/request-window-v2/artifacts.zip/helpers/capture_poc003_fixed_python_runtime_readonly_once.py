"""Inspect the existing fixed runtime offline, without sources or media mounts."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
t=Path(__file__).resolve().parent
image='sha256:df18428df8a0f9189c84e7424d214b4c50092af1f9dca5842a00c41c39bda316'
out=t/'poc003-fixed-python-runtime-readonly-v1';out.mkdir()
program='''import sys,os,platform,json,hashlib,http.client,socket,socketserver,_socket,_hashlib,ssl,io
from pathlib import Path
files={}
for name,module in [('http.client',http.client),('socket',socket),('socketserver',socketserver),('_socket',_socket),('_hashlib',_hashlib)]:
 p=Path(module.__file__).resolve();raw=p.read_bytes();files[name]={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
exe=Path(sys.executable).resolve();raw=exe.read_bytes();files['interpreter']={'path':str(exe),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps({'version':sys.version,'implementation':platform.python_implementation(),'machine':platform.machine(),'uid':os.getuid(),'executable':str(exe),'files':files,'openssl':ssl.OPENSSL_VERSION,'ioBufferSize':io.DEFAULT_BUFFER_SIZE,'bytearray65536Capacity':bytearray(65536).__alloc__(),'tracePresent':sys.gettrace() is not None,'profilePresent':sys.getprofile() is not None},sort_keys=True))'''
argv=['docker','run','--rm','--pull','never','--network','none','--read-only','--cap-drop','ALL',
      '--security-opt','no-new-privileges','--user','1000:1000','--pids-limit','32','--memory','256m','--cpus','1',
      '--entrypoint','python3',image,'-I','-B','-c',program]
started=datetime.now(timezone.utc).isoformat()
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);code=child.wait()
raw=(out/'stdout.raw').read_bytes();error=(out/'stderr.raw').read_bytes()
record={'kind':'READONLY_FIXED_IMAGE_RUNTIME_INSPECTION_NOT_MEDIA_EXPERIMENT','image':image,'argv':argv,'pid':child.pid,
        'actualWaitCompleted':True,'exitCode':code,'startedAt':started,'endedAt':datetime.now(timezone.utc).isoformat(),
        'stdoutBytes':len(raw),'stdoutSha256':hashlib.sha256(raw).hexdigest(),'stderrBytes':len(error),'stderrSha256':hashlib.sha256(error).hexdigest(),
        'mediaMounted':False,'mediaExperimentExecuted':False,'runtimeBindingImplemented':False,'aggregateCapacityProofComplete':False}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert code==0,error.decode(errors='replace')
data=json.loads(raw);assert data['version'].startswith('3.12.15 ') and data['uid']==1000
assert data['ioBufferSize']==8192 and data['bytearray65536Capacity']==65537 and not data['tracePresent'] and not data['profilePresent']
matches={}
for module,name in [('http.client','http-client.py'),('socket','socket.py')]:
    source=(t/'poc003-python31215-capacity-refs-v1'/name).read_bytes()
    matches[module]=hashlib.sha256(source).hexdigest()==data['files'][module]['sha256']
source=(t/'poc003-python31215-http-io-capacity-refs-v3/socketserver.py').read_bytes()
matches['socketserver']=hashlib.sha256(source).hexdigest()==data['files']['socketserver']['sha256']
assert all(matches.values()),matches
record.update(observed=data,officialReferenceSourceMatches=matches)
(out/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exitCode':code,'version':data['version'],'pureRuntimeFilesMatchReferences':matches,'aggregateCapacityProofComplete':False}),flush=True)
