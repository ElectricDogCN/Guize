"""One private socket pair verifies cancellation behavior without any media."""
from pathlib import Path
import json,socket,threading,time
t=Path(__file__).resolve().parent
listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(1)
client=socket.create_connection(listener.getsockname());owned,_=listener.accept();listener.close()
entered=threading.Event();finished=threading.Event();events=[]
def read():
    entered.set()
    try:events.append({'receivedBytes':len(owned.recv(1))})
    except OSError as error:events.append({'error':type(error).__name__,'errno':error.errno})
    finally:finished.set()
thread=threading.Thread(target=read);thread.start();assert entered.wait(1)
time.sleep(.05)
owned.shutdown(socket.SHUT_RDWR);owned.close()
closed=finished.wait(1)
client.close();thread.join(2)
result={'kind':'PRIVATE_WINDOWS_BLOCKING_RECEIVE_CANCELLATION_DIAGNOSTIC','shutdownAndCloseUnblockedBeforePeerClose':closed,
        'finishedAfterPeerCleanup':not thread.is_alive(),'events':events,'mediaExecuted':False}
with (t/'poc003-windows-owned-socket-close-diagnostic.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
assert not thread.is_alive()
print(json.dumps(result))
