"""Verify owned cancellation with the actual HTTP makefile-reference shape."""
from pathlib import Path
import json,socket,threading,time
t=Path(__file__).resolve().parent
listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(1)
client=socket.create_connection(listener.getsockname());owned,_=listener.accept();listener.close()
file_reference=owned.makefile('rb')
entered=threading.Event();finished=threading.Event();events=[]
def read():
    entered.set()
    try:events.append({'receivedBytes':len(owned.recv(1))})
    except OSError as error:events.append({'error':type(error).__name__,'errno':error.errno})
    finally:finished.set()
thread=threading.Thread(target=read);thread.start();assert entered.wait(1);time.sleep(.05)
owned.shutdown(socket.SHUT_RDWR)
descriptor=owned.detach();assert descriptor>=0 and owned.fileno()==-1
socket.close(descriptor)
closed=finished.wait(1)
client.close();thread.join(2);file_reference.close();owned.close()
result={'kind':'WINDOWS_OWNED_NATIVE_DESCRIPTOR_CANCELLATION_WITH_MAKEFILE_REFERENCE',
        'detachedBeforeNativeClose':True,'socketObjectDescriptorAfterDetach':owned.fileno(),
        'unblockedBeforePeerClose':closed,'finishedAfterCleanup':not thread.is_alive(),'events':events,'mediaExecuted':False}
with (t/'poc003-windows-owned-socket-detach-diagnostic.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
assert not thread.is_alive() and closed
print(json.dumps(result))
