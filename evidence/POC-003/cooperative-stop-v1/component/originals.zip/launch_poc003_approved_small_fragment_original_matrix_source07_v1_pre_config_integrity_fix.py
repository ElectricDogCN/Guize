"""Fresh actor/program/window checks before the exact approved one-shot native controller."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,yaml

parser=argparse.ArgumentParser();parser.add_argument('--approval-sha256',required=True);args=parser.parse_args()
t=Path(__file__).resolve().parent
canonical=t.parent/'Guize'
author=t/'poc003-feature-actor-import-v1'
approval=t/'poc003-small-fragment-original-matrix-source07-approval-v1/independent-approval.json'
approval_sha=args.approval_sha256
assert hashlib.sha256(approval.read_bytes()).hexdigest()==approval_sha
a=json.loads(approval.read_bytes())
now=datetime.now(timezone.utc)
assert a['originalMatrixExecutionApproved'] and not a['mustFix']
assert datetime.fromisoformat(a['validFrom'].replace('Z','+00:00'))<=now
assert (datetime.fromisoformat(a['validUntil'].replace('Z','+00:00'))-now).total_seconds()>=900
assert a['approvedBy']=='/root/independent_review' and a['maximumActualAttempts']==1
assert a['scope']=='OWNED_PID1_SOURCE07_SMALL_FRAGMENT_ORIGINAL21_RAW_MATRIX_ONLY'
assert a['configurationReviewSha256']=='417c751f097483d98477be54979cc07adbdf23fbdf5da2cc7d2f5586eb214e5d'
snapshot=json.loads((t/'poc003-small-fragment-original-matrix-source07-start-fresh-official.json').read_bytes())
captured=datetime.strptime(snapshot['capturedAt'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
assert 0<=(now-captured).total_seconds()<120
remote_main=json.loads(snapshot['main']['structuredContent']['content'])['commit']['sha']
pr=json.loads(snapshot['pr']['structuredContent']['content'])
assert remote_main=='7996dedc0b01c5208824eff4d70c95724ba1b26d'
assert pr['state']=='open' and pr['draft'] and not pr['merged']
assert pr['head']['sha']=='07d7f842f62a8a878915ebf60ea26f559eaed4eb' and pr['base']['sha']==remote_main
resource=json.loads((t/'poc003-small-fragment-original-matrix-source07-fresh-start-resources-v1/results.json').read_bytes())
assert 0<=(now-datetime.fromisoformat(resource['observedAt'])).total_seconds()<120
assert resource['uid']==1000 and resource['proposedNameAbsent'] and not resource['containerCreated']
assert resource['proposedContainerName']=='guize-poc003-small-fragment-original-matrix-source07-v1'
assert resource['disk']['free']>=4*1024**3
for row in a['ordinaryRecords']:
    p=Path(row['path'])
    raw=p.read_bytes()
    assert len(raw)==row['byteCount'] and hashlib.sha256(raw).hexdigest()==row['sha256']
assert a['ordinarySchemasValidated'] is True
assert a['configurationManifestSha256']=='f41696de40799b703f8e98dca83880cad009097264aa24ab343ca20766b1dc72'
assert a['packageManifestSha256']=='df989f487bec75972309914986c2816657256a4d3ca90c04f63013763d34b8e8'
git=lambda r,*args:subprocess.check_output(['git','-c','core.longpaths=true','-C',str(r),*args]).decode().strip()
assert git(canonical,'rev-parse','HEAD')=='7996dedc0b01c5208824eff4d70c95724ba1b26d'
assert git(canonical,'ls-remote','--heads','origin','refs/heads/main').split()==['7996dedc0b01c5208824eff4d70c95724ba1b26d','refs/heads/main']
assert git(author,'rev-parse','HEAD')==a['source']=='07d7f842f62a8a878915ebf60ea26f559eaed4eb'
assert git(author,'rev-parse','HEAD^{tree}')==a['tree']=='349b357c572e24e977c3dd1c5e1fdfa0c96ae1e1'
roles=[]
for r in [canonical,author]:
    assert not git(r,'status','--porcelain=v1','--untracked-files=all')
    assert yaml.safe_load((r/'specs/coordination/program-plan.yaml').read_bytes())['status']=='active'
    registry=yaml.safe_load((r/'specs/coordination/active-work.yaml').read_bytes())
    own=next(x for x in registry['tasks'] if x['taskId']=='POC-003')
    assert own['branch']=='chore/POC-003-ats-range' and own['implementer']=='/root' and own['reviewer']=='/root/independent_review'
    assert own['lease']['expiresAt']=='2026-11-05T11:01:07Z'
    assert datetime.fromisoformat(own['lease']['acquiredAt'].replace('Z','+00:00'))<=now<datetime.fromisoformat(own['lease']['expiresAt'].replace('Z','+00:00'))
    roles.append(dict(repository=str(r),own=own))
assert roles[0]['own']['lease']==roles[1]['own']['lease']
assert roles[1]['own']['status']=='in_progress' and roles[1]['own']['agentRole']=='implementer'
local61=json.loads((t/'ops017-history-selection-perf300-v1/results.json').read_bytes())
assert local61['component62Passed'] and all(x['actualWaitCompleted'] and x['exitCode']==0 for x in local61['phases'])
local14=json.loads((t/'ops017-history-selection-fixed-source7996-813f956-native-gates-v1/results.json').read_bytes())
assert local14['declared14Passed'] and all(x['actualWaitCompleted'] and x['exitCode']==0 for x in local14['commands'])
publication=json.loads((t/'ops017-history-selection-fixed-813f956-publication-v1/results.json').read_bytes())
assert publication['actualWaitCompleted'] and publication['exitCode']==0
method=t/'run_poc003_small_fragment_original_matrix_source07_v1.py'
assert hashlib.sha256(method.read_bytes()).hexdigest()==a['methodSha256']=='1c70977a28f903081e08f0748b38571d412b44fb1e2fff53684f73a978156b1b'
entry=t/'poc003_small_fragment_original_matrix_entry_v1.py'
assert hashlib.sha256(entry.read_bytes()).hexdigest()==a['entrySha256']=='cbad54cdaf3d918d049fbc07a443e861a82a15839fc7c51ca4b3d1c1b080b186'
out=t/'poc003-small-fragment-original-matrix-source07-launch-v1'
out.mkdir()
linux=lambda p:'/mnt/c'+p.resolve().as_posix()[2:]
argv=['wsl.exe','-d','Ubuntu','-u','sur','--','/home/sur/.cache/guize-takeover/governance-venv/bin/python','-B',linux(method),'--approval',linux(approval),'--approval-sha256',approval_sha]
result=dict(approvalSha256=approval_sha,source=a['source'],roles=roles,canonicalMain='7996dedc0b01c5208824eff4d70c95724ba1b26d',local62And14AndPublicationAllActuallyFinished=True,noOtherDeliberateLocalPocPerformanceOrBuildScheduled=True,argv=argv,startedAt=now.isoformat(),actualWaitCompleted=False,runtimeAccepted=False,fullMatrixApproved=True)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
with (out/'native.stdout.raw').open('xb') as stdout,(out/'native.stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr)
    result['pid']=child.pid
    save()
    code=child.wait()
result.update(actualWaitCompleted=True,exitCode=code,finishedAt=datetime.now(timezone.utc).isoformat())
save()
assert code==0
print(json.dumps(dict(pid=child.pid,actualWaitCompleted=True,exitCode=code,runtimeAccepted=False,fullMatrixApproved=True)),flush=True)
