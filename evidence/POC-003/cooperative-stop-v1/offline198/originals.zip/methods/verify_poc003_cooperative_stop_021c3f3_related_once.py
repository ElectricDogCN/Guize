"""Run relevant offline regressions against recorded draft bytes, never an experiment."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1'
platform=sys.argv[1];assert platform in ('windows','linux')
assert (os.name=='nt')==(platform=='windows')
if platform=='linux':assert os.getuid()==1000
rel=Path('poc/POC-03-ats-range')
out=t/('poc003-cooperative-stop-021c3f3-component-'+platform+'-checks');out.mkdir()
names=['test_serve_readiness.py','test_input_fixed_io.py','test_crypto_configuration.py','test_media_capacity.py','test_request_window.py','test_cache_stream_io.py','test_collector_raw_io.py','test_fixed_origin_io.py','test_request_concurrency.py',
       'test_payload_lifetime.py','test_lab.py','test_revocation_binding.py','test_cache_body_bounds.py',
       'test_cache_probe.py','test_input_profile.py','test_representative_cache.py']
if platform=='linux':names+=['test_gateway_native.py','test_http_timing_native.py','test_representative_cache_native.py']
def pins():return {p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((r/rel).glob('*.py'))}
assert subprocess.check_output(['git','-c','core.longpaths=true','-C',str(r),'rev-parse','HEAD'],text=True).strip()=='021c3f3eb5cbf67e263af65b74d17680d33cb554'
before=pins();rows=[]
for index,name in enumerate(names,1):
    prefix=f'{index:02}-'+name.removesuffix('.py')
    argv=[sys.executable,'-X','utf8','-B',str(rel/name)]
    row={'name':name,'argv':argv,'startedAt':datetime.now(timezone.utc).isoformat()}
    with (out/(prefix+'.stdout.raw')).open('xb') as stdout,(out/(prefix+'.stderr.raw')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=r,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        code=child.wait()
    raw={}
    for suffix in ('.stdout.raw','.stderr.raw'):
        data=(out/(prefix+suffix)).read_bytes();raw[suffix]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    stderr=(out/(prefix+'.stderr.raw')).read_text(encoding='utf-8')
    ran=re.findall(r'Ran (\d+) tests? in ',stderr)
    row.update(pid=child.pid,exitCode=code,actualWaitCompleted=True,raw=raw,testsRun=sum(map(int,ran)),
               skipped=bool(re.search(r'\bskipped[= (]',stderr)),finishedAt=datetime.now(timezone.utc).isoformat())
    rows.append(row);print(json.dumps({k:row[k] for k in ('name','exitCode','testsRun','skipped')}),flush=True)
    if code or row['skipped']:
        print(stderr,flush=True);break
after=pins()
result={'kind':'ACTUAL_COOPERATIVE_STOP_OFFLINE_COMPONENT_CHECKS','platform':platform,'source':'021c3f3eb5cbf67e263af65b74d17680d33cb554',
        'pythonVersion':sys.version,'before':before,'after':after,'commands':rows,'sourceBytesUnchanged':before==after,
        'allRequestedExecuted':len(rows)==len(names),'totalTests':sum(x['testsRun'] for x in rows),
        'sourceQualified':False,'aggregateCapacityProofComplete':False,'formalPocAccepted':False,'experimentExecuted':False}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
assert before==after and len(rows)==len(names) and all(x['exitCode']==0 and not x['skipped'] and x['testsRun'] for x in rows)
assert result['totalTests']==(89 if platform=='windows' else 98),result['totalTests']
