"""Run the declared fifteen checks against one exact synchronized POC-003 implementation source."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from live_github_transport import start_bridge

t=Path(__file__).resolve().parent
c=json.loads((t/'poc003-current-capacity-source-candidate.json').read_bytes())
source,base,tree,branch=(c[k] for k in ['source','base','tree','branch'])
assert os.name=='posix' and os.geteuid()==1000 and c['expectedCommands']==15 and c['trackedClean']
assert base=='22ab6a0668da2d64a016fccef2c3b5a634638a24'
accepted=json.loads((t/'poc005-actor-amendment-v1-actual-main-independent-review.json').read_bytes())
assert accepted['actualActorMainAccepted'] and accepted['fullMainCiAccepted'] and accepted['mustFix']==[]
bundle=t/c['bundle'];assert hashlib.sha256(bundle.read_bytes()).hexdigest()==c['bundleSha256']
w=Path('/home/sur/.cache/guize-takeover/poc003-current-capacity-source-'+source[:7]);assert not w.exists()
subprocess.run(['git','clone','--quiet','--branch',branch,str(bundle),str(w)],check=True)
assert not (w/'.git/objects/info/alternates').exists()
git=lambda *a:subprocess.check_output(['git','-C',str(w),*a],text=True).strip()
subprocess.run(['git','-C',str(w),'branch','main',base],check=True,capture_output=True)
subprocess.run(['git','-C',str(w),'update-ref','refs/remotes/origin/main',base,'0'*40],check=True,capture_output=True)
subprocess.run(['git','-C',str(w),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
def state():return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),parent=git('show','-s','--format=%P','HEAD'),branch=git('branch','--show-current'),main=git('rev-parse','main'),status=git('status','--porcelain','--untracked-files=all'))
before=state();assert before==dict(head=source,tree=tree,parent=' '.join(c['parents']),branch=branch,main=base,status='')
assert git('diff','--name-only',base,source,'--').splitlines()==c['changedPaths']
for path, digest in c['codePins'].items():
    assert hashlib.sha256((w/path).read_bytes()).hexdigest()==digest
filesystem=subprocess.check_output(['stat','-f','-c','%T',str(w)],text=True).strip();assert filesystem not in ['9p','v9fs','drvfs']
sections=re.findall(r'```bash\n(.*?)\n```',(w/'specs/tasks/POC-003.md').read_text(),re.S);assert len(sections)==1
declared=[shlex.split(x) for x in sections[0].splitlines() if x.strip()];assert len(declared)==15
command_blocks=re.findall(r'```bash\n(.*?)\n```',(w/'evidence/POC-003/commands.txt').read_text(),re.S);assert len(command_blocks)==1
assert declared==[shlex.split(x) for x in command_blocks[0].splitlines() if x.strip()]
commands=[[source if x=='HEAD' else x for x in argv] for argv in declared]
labels=['diff','task','readiness','schemas','integrity','history','transitions','finalization','raw-lifecycle','lifecycle-gate','coordination','scope','evidence','poc-protocol','docs']
out=t/('poc003-current-capacity-source-'+source[:7]+'-native-checks');out.mkdir()
for key in ['PYTEST_ADDOPTS','GITHUB_BASE_REF','PUSH_BEFORE']:os.environ.pop(key,None)
os.environ.update(PATH=str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF=branch,GITHUB_REF_NAME=branch,GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
start_bridge(out)
result=dict(c,before=before,nativeFilesystem=filesystem,commands=[],startedAt=datetime.now(timezone.utc).isoformat())
def save():(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save()
for label,argv in zip(labels,commands):
    row=dict(label=label,argv=argv,raw=label+'.raw',startedAt=datetime.now(timezone.utc).isoformat())
    with (out/row['raw']).open('x',encoding='utf-8',buffering=1) as f:
        f.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n')
        child=subprocess.Popen(argv,cwd=w,stdout=f,stderr=subprocess.STDOUT);row['pid']=child.pid
        result['commands'].append(row);save();code=child.wait();f.write('\nExit Code: '+str(code)+'\n')
    raw=(out/row['raw']).read_bytes();row.update(exitCode=code,actualWaitCompleted=True,waitCompleted=True,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),endedAt=datetime.now(timezone.utc).isoformat());save()
    print(label+': exit '+str(code),flush=True)
    if code:
        result.update(failedGate=label,after=state());save();raise SystemExit(code)
assert state()==before
result.update(after=state(),currentTask15Accepted=True,sourceQualified=False,experimentApproved=False,completedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(source=source,currentTask15Accepted=True,prPublicationAllowed=False,fullSourceAccepted=False)),flush=True)
