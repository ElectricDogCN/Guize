"""Classify immutable raw evidence correctly without rewriting any original byte."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile

t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1'
parent='8eae8a7f8ac132a2eac7f752eef4eae8412cf3e9';base='22ab6a0668da2d64a016fccef2c3b5a634638a24'
g=lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),*a])
assert g('rev-parse','HEAD').decode().strip()==parent and not g('status','--porcelain')
old=read=lambda p:json.loads(p.read_text(encoding='utf-8'))
failed=t/'poc003-current-capacity-source-8eae8a7-native-checks'
record=read(failed/'results.json')
assert record['failedGate']=='diff' and len(record['commands'])==1 and record['commands'][0]['exitCode']==2
attrs=['evidence/POC-003/payload-lifetime-v1/.gitattributes','evidence/POC-003/request-concurrency-v1/.gitattributes']
data_paths=[]
for folder in attrs:
    data_paths.extend(p for p in (r/folder).parent.iterdir() if p.is_file() and p.suffix in ('.raw','.json'))
pin=lambda raw:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
before={p.relative_to(r).as_posix():pin(p.read_bytes()) for p in data_paths}
preimages={name:(r/name).read_bytes() for name in attrs}
new=b'# Immutable captured stdout/stderr are opaque byte archives, not source text.\n*.raw binary\n# Keep structured receipts readable without changing their original Windows CRLF bytes.\n*.json -text whitespace=cr-at-eol\n'
for name in attrs:(r/name).write_bytes(new)
assert before=={p.relative_to(r).as_posix():pin(p.read_bytes()) for p in data_paths}
out=r/'evidence/POC-003/source-8eae8a7-stopped-validation';out.mkdir();entries=[]
with zipfile.ZipFile(out/'artifacts.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    def save(name,raw):z.writestr(name,raw);entries.append(dict(ref=name,**pin(raw)))
    for name,raw in preimages.items():save('preimages/'+name,raw)
    for name in ('diff.raw','results.json'):save(name,(failed/name).read_bytes())
    for name in ('verify_poc003_current_capacity_source_native_once.py','poc003-current-capacity-source-candidate.json'):
        save('methods/'+name,(t/name).read_bytes())
    save('methods/'+Path(__file__).name,Path(__file__).read_bytes())
with zipfile.ZipFile(out/'artifacts.zip') as z:
    assert z.testzip() is None
    for row in entries:assert pin(z.read(row['ref']))=={k:row[k] for k in ('bytes','sha256')}
index=dict(kind='ACTUAL_FIRST_SOURCE_GATE_FAILURE_AND_OPAQUE_RAW_ARCHIVE_CLASSIFICATION',
    source=parent,firstGateExitCode=2,otherFourteenGatesExecuted=False,entries=entries,
    archivePin=pin((out/'artifacts.zip').read_bytes()),originalDataPins=before,allOriginalDataBytesUnchanged=True,
    affectedAttributePaths=attrs,sourceOrCheckerOrThresholdOrGateCommandChanged=False)
with (out/'index.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(index,indent=2)+'\n')
note='''## Current source-gate correction: immutable raw archives

Source8eae8a7 reached only its first declared gate, unchanged git diff --check against accepted main22. It actually exited2 on captured raw stderr/CRLF receipts in payload-lifetime-v1 and request-concurrency-v1; the other fourteen commands were not executed. Original output and context are preserved at source-8eae8a7-stopped-validation/index.json.

Only these two archive directories now classify captured.raw streams as binary byte archives; their.json receipts retain original bytes and permit CR at end of line. No captured byte, source implementation, frozen checker/schema/threshold or declared gate command was changed. The complete original pin inventory is in that index. This is archive representation, not a skipped source check. The new exact source still needs all fifteen checks, related validation, same-head CI and independent final source acceptance before any new approved media experiment.

'''
docs=['evidence/POC-003/summary.md','evidence/POC-003/handoff.md']
for name in docs:
    p=r/name;p.write_bytes(note.encode()+p.read_bytes())
paths=attrs+docs+['evidence/POC-003/source-8eae8a7-stopped-validation/artifacts.zip','evidence/POC-003/source-8eae8a7-stopped-validation/index.json']
outcome=t/'poc003-raw-archive-attributes-correction-v1';outcome.mkdir()
g('add','--',*paths)
assert set(g('diff','--cached','--name-only').decode().splitlines())==set(paths)
for name in paths:assert g('show',':'+name)==(r/name).read_bytes(),name
argv=['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(r),'commit','-m',
      'fix(POC-003): preserve raw evidence as opaque byte archives','-m','Refs #131. Preserve exact original stderr and CRLF receipt bytes; retain the stopped first gate. No source/checker/threshold or declared command change.']
with (outcome/'stdout.raw').open('xb') as stdout,(outcome/'stderr.raw').open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW);code=child.wait()
assert code==0 and not g('status','--porcelain')
head=g('rev-parse','HEAD').decode().strip();tree=g('rev-parse','HEAD^{tree}').decode().strip()
assert g('rev-parse','HEAD^').decode().strip()==parent
bundle=t/('poc003-current-capacity-source-'+head[:7]+'.bundle');assert not bundle.exists()
g('bundle','create',str(bundle),'chore/POC-003-ats-range')
candidate=read(t/'poc003-current-capacity-source-candidate.json')
for name,expected in candidate['codePins'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected
candidate.update(source=head,tree=tree,parents=[parent],changedPaths=g('diff','--name-only',base,head,'--').decode().splitlines(),
                 bundle=bundle.name,bundleBytes=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest())
with (t/'poc003-current-capacity-source-v2-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(candidate,indent=2)+'\n')
result=dict(source=head,tree=tree,parent=parent,pid=child.pid,argv=argv,exitCode=code,actualWaitCompleted=True,
    paths=paths,allOriginalDataBytesUnchanged=True,sourceCodeUnchanged=True,checkersAndCommandsUnchanged=True,
    sourceQualified=False,experimentApproved=False)
with (outcome/'results.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('source','tree','parent','allOriginalDataBytesUnchanged','sourceCodeUnchanged','sourceQualified')}))
