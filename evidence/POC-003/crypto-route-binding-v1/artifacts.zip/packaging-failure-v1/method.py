"""Package exact existing crypto initialization guard checks for component review."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from datetime import datetime, timezone

t = Path(__file__).resolve().parent
r = t / 'poc003-feature-actor-import-v1'
stage = t / 'poc003-crypto-route-binding-v1'
own = r / 'poc/POC-03-ats-range'
parent = '7af0fa7dc56134adcf386f0e9cfa0b81d5b7b9ce'
assert subprocess.check_output(['git', '-C', str(r), 'rev-parse', 'HEAD'], text=True).strip() == parent
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
pin = lambda raw: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
checks = read(stage / 'checks/results.json')
capture = read(stage / 'profile-capture/results.json')
assert checks['before'] == checks['after']
assert capture['before'] == capture['after'] and capture['exitCode'] == 0 and capture['actualWaitCompleted']
assert len(checks['commands']) == 5
assert all(x['exitCode'] == 0 and x['actualWaitCompleted'] and x['sourcesStable']
           and x['testSummaryMatched'] and x['noSkips'] for x in checks['commands'])
for name, expected in checks['before'].items():
    assert pin((own / name).read_bytes()) == expected, name
for name, expected in capture['before'].items():
    assert hashlib.sha256((own / name).read_bytes()).hexdigest() == expected, name
assert (own / 'python-runtime-profile.json').read_bytes() == (stage / 'profile-capture/profile.json').read_bytes()
profile = read(own / 'python-runtime-profile.json')
assert profile['schemaVersion'] == 2 and len(profile['files']) == 14
assert profile['crypto']['algorithm']['provider'] == 'default'
assert not profile['crypto']['algorithm']['defaultDigestEnginePresent']
assert profile['crypto']['resolvedMemcpy']['offsetHex'] == '0x17b800'
pre = read(stage / 'preimages.json')
assert pre['head'] == parent
for path, row in pre['files'].items():
    raw = subprocess.check_output(['git', '-C', str(r), 'show', parent + ':' + path])
    assert pin(raw) == {k: row[k] for k in ('bytes', 'sha256')}, path
    assert (stage / row['file']).read_bytes() == raw, path

note = '''
## Crypto initialization and public native-route binding after local7af0fa7

POC-003 / Issue131 / chore/POC-003-ats-range retains creationbase760f6c5838597d1d66c0a536ecbf440ef5a7dfec, accepted integrationbase055ccf18e4b125850d59c93f5ec3204e630f101c, original lease, implementer/root and reviewer/root/independent_review. The prior input-validation fixed-slot component was independently accepted and ordinarily committed as7af0fa7.

The selected runtime profile advances explicitly to v2. The pre-input guard binds the actual public OpenSSL configuration bytes, compiled configuration/engine/module directories, global default SHA256 method/provider/FIPS/no-ENGINE metadata and public dispatch library offsets. It also binds actual resolved libc memcpy offset and the ctypes/_ctypes/libffi public-call dependencies:14 selected files and9 actual mapped native components. Active configuration includes, unsupported runtime selectors and profile drift are rejected. Existing HASH private layouts are not inspected. lab implementationSources includes the new helper. This binds an initialization route; a fresh public method query alone does not attest every existing HASH object or the complete experiment window.

Windows4 configuration cases and fixed-image4 configuration+11 runtime+5 readiness+9 input-profile cases pass, five actual child waits0/no skips. The profile capture is a separate actual child wait0 with exact three-source before/after pins. Original eight runtime assertions remain; three actual route/profile negative cases and four configuration cases are added. These use no media inputs or ATS. Exact preimages, current selected sources, capture and command/raw results are in crypto-route-binding-v1/artifacts.zip with per-entry index.json.

Component review and ordinary local commit are pending. HTTP/HASH native capacity and same-owner complete epoch aggregation, latest-main integration/full-source checks/CI, new method/sample/resource/window approval and actual original matrix/fresh revocation remain outstanding. The older prospective original_matrix_entry_v2 lab pin is stale after this source change; preserve it and prepare a forward v3 before any experiment. Frozen checker/schema/thresholds, original Task front, Program/Active, roles/lease and all old evidence remain unchanged. Rollback is an ordinary reviewed forward change retaining originals; this component does not grant source qualification, Ready, merge, experiment, formal POC or V1 acceptance.
'''
for name in ('specs/tasks/POC-003.md', 'evidence/POC-003/handoff.md'):
    path = r / name
    raw = path.read_bytes()
    expected = pre['files'][name]
    assert pin(raw) == {k: expected[k] for k in ('bytes', 'sha256')}
    path.write_bytes(raw.rstrip(b'\n') + b'\n' + note.encode('utf-8'))

out = r / 'evidence/POC-003/crypto-route-binding-v1'
out.mkdir()
archive = out / 'artifacts.zip'
entries = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    def save(name, raw, origin):
        z.writestr(name, raw)
        entries.append(dict(ref=name, **pin(raw), origin=origin))
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            assert path.suffix in ('.py', '.json', '.raw'), str(path)
            save('observations/' + path.relative_to(stage).as_posix(), path.read_bytes(), str(path))
    for path in ('specs/tasks/POC-003.md', 'evidence/POC-003/handoff.md'):
        save('current/' + path, (r / path).read_bytes(), str(r / path))
    save('helpers/' + Path(__file__).name, Path(__file__).read_bytes(), str(Path(__file__)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries) == len(set(z.namelist()))
    for row in entries:
        assert pin(z.read(row['ref'])) == {k: row[k] for k in ('bytes', 'sha256')}
index = dict(kind='CRYPTO_INITIALIZATION_COMPONENT_BINDING_NOT_NATIVE_CAPACITY', taskId='POC-003',
             parent=parent, capturedAt=datetime.now(timezone.utc).isoformat(),
             sourcePins=checks['before'], windowsTests=4, fixedImageTests=29,
             actualComponentCheckWaits=5, actualProfileCaptureWaits=1,
             profileFiles=14, actualMappedNativeComponents=9,
             archive=archive.name, archivePin=pin(archive.read_bytes()), entries=entries,
             componentAccepted=False, sourceQualified=False, aggregateCapacityProofComplete=False,
             experimentExecuted=False, formalPocAccepted=False)
with (out / 'index.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
paths = ['poc/POC-03-ats-range/' + name for name in (
    'crypto_runtime.py', 'python_runtime.py', 'python-runtime-profile.json', 'lab.py',
    'test_crypto_configuration.py', 'test_python_runtime_binding_native.py')]
paths += ['specs/tasks/POC-003.md', 'evidence/POC-003/handoff.md',
          'evidence/POC-003/crypto-route-binding-v1/artifacts.zip',
          'evidence/POC-003/crypto-route-binding-v1/index.json']
candidate = dict(parent=parent, repo=str(r), files={path: pin((r / path).read_bytes()) for path in paths},
                 componentAccepted=False, sourceQualified=False, experimentExecuted=False,
                 formalPocAccepted=False, windowsTests=4, fixedImageTests=29,
                 archiveEntries=len(entries), archivePin=index['archivePin'])
with (t / 'poc003-crypto-route-binding-v1-current-candidate.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(candidate, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: candidate[k] for k in ('parent', 'windowsTests', 'fixedImageTests', 'archiveEntries', 'archivePin')}))
