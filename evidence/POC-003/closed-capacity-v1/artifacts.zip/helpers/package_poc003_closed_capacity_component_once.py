"""Preserve the closed-record capacity component and both actual test attempts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,zipfile

t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1';own=r/'poc/POC-03-ats-range'
parent='cd804502f09ea2f8dca2fbdc988fbb3667e32360'
g=lambda *a:subprocess.check_output(['git','-c','core.longpaths=true','-C',str(r),*a])
assert g('rev-parse','HEAD').decode().strip()==parent
assert not g('diff','--name-only') and not g('diff','--cached','--name-only')
assert set(filter(None,g('ls-files','--others','--exclude-standard','-z').decode().split('\0')))=={
    'poc/POC-03-ats-range/media_capacity.py','poc/POC-03-ats-range/test_media_capacity.py'}
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
pin=lambda raw:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
first=read(t/'poc003-closed-capacity-v1/results.json');second=read(t/'poc003-closed-capacity-v2/results.json')
assert first['before']==first['after']==second['before']==second['after']
for name,row in first['before'].items():assert pin((own/name).read_bytes())==row,name
assert first['commands'][0]['exitCode']==0 and first['commands'][0]['summaryMatched'] and first['commands'][0]['noSkips']
assert first['commands'][1]['exitCode']==1 and b'dockerDesktopLinuxEngine' in (t/'poc003-closed-capacity-v1/fixed-image.stderr.raw').read_bytes()
assert len(second['commands'])==1 and all(x['exitCode']==0 and x['actualWaitCompleted'] and x['summaryMatched'] and x['noSkips'] for x in second['commands'])
preimages={path:g('show',parent+':'+path) for path in ('specs/tasks/POC-003.md','evidence/POC-003/handoff.md')}
note='''
## Closed-record native/request capacity aggregation component after accepted main22 import

The crypto initialization component was independently accepted and ordinarily committed asdbacbae; accepted main22 was normally imported in two-parent cd804502 (parentdbac+22ab), OwnPOC source bytes unchanged. Creationbase760f6c5838597d1d66c0a536ecbf440ef5a7dfec, implementer/root, reviewer/root/independent_review and original lease remain unchanged.

New media_capacity.py derives retained synchronous Origin/Gateway/Collector request peaks only from closed owned HTTP/Collector windows. It reparses every nonempty expected native epoch, including helper runs, verifies actual owner/target waits, initialization/complete journal, exact approved component digests with stable before/after device/inode, source-enforced single-initial-exec handoff, complete role/token sequence and monotonic raw identity. The singleton owner's no-overlap rule permits max across complete native target epochs; no artificial end timestamps or idle-count shortcuts are used. Every independent O/G/C term adds. The separately reviewed synchronous phase max1048577 and conditionalH4096 per concurrent source-payload owner remain explicit; a fresh revocation reader receives its own conservativeC+H allowance. This module returns conditional unapproved derivations, never a source/method/experiment/POC pass.

Seven Windows and seven actual fixed-image tests pass, two successful child waits0/no skips and47 selected sources unchanged. Regressions use synthetic closed records and real temporary files, including a missing middle helper, a retained middle peak, changed components/actual-wait rejection, tampered/truncated raw, unfinished request intervals and independently added owner terms. First Windows7 already passed; the first fixed-image attempt actually exited1 because Docker Desktop was stopped and its API pipe was absent. The installed desktop app was initially started (no restart), Docker server29.8.0 became available, and only that missing fixed-image check was executed on the unchanged source. Original environment failure/raw and both source snapshots are in closed-capacity-v1/artifacts.zip/index.json. Ordinary WSL7 also passed in tool output86bbc2 but is not a standalone captured raw claim.

Finite H4096 is conditionally accepted by hash-native-bound-v3 review (carrier2608), and the phase callgraph max was independently reviewed; actual fresh guards, immutable initialization/no-interposition, single source/entry and complete window conditions must still hold in the real experiment. The new exact-pin original matrix entryv3 is syntax-only and prospective. Component review/local commit, full-source checks/CI, independent method/input/resource/window approval and actual full original matrix/fresh revocation remain pending. No actual native or media experiment was run by these tests, no aggregate result/Ready/main/POC/V1 is accepted. Frozen checker/schema/thresholds/Program/Active, Task front/roles/lease and all old evidence stay unchanged; rollback is an ordinary reviewed forward change retaining originals.
'''
for name,raw in preimages.items():(r/name).write_bytes(raw.rstrip(b'\n')+b'\n'+note.encode('utf-8'))
out=r/'evidence/POC-003/closed-capacity-v1';out.mkdir();entries=[]
with zipfile.ZipFile(out/'artifacts.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    def save(name,raw,origin):
        z.writestr(name,raw);entries.append(dict(ref=name,**pin(raw),origin=origin))
    for name,raw in preimages.items():save('preimages/'+name,raw,'Exact committed parent'+parent)
    for folder in ('poc003-closed-capacity-v1','poc003-closed-capacity-v2'):
        for p in sorted((t/folder).rglob('*')):
            if p.is_file():save(folder+'/'+p.relative_to(t/folder).as_posix(),p.read_bytes(),str(p))
    for name in ('poc003-hash-native-bound-v3-independent-review.json','poc003-phase-callgraph-v2-independent-review.json',
                 'poc003-original-matrix-entry-v3-preparation.json','poc003_original_matrix_entry_v3.py',
                 'check_poc003_closed_capacity_component_once.py','check_poc003_closed_capacity_fixed_image_v2_once.py'):
        save('references/'+name,(t/name).read_bytes(),str(t/name))
    save('helpers/'+Path(__file__).name,Path(__file__).read_bytes(),str(Path(__file__)))
with zipfile.ZipFile(out/'artifacts.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(entries)
    for row in entries:assert pin(z.read(row['ref']))=={k:row[k] for k in ('bytes','sha256')}
index=dict(kind='SYNTHETIC_CLOSED_RECORD_CAPACITY_COMPONENT_NOT_ACTUAL_AGGREGATE',parent=parent,
    preparedAt=datetime.now(timezone.utc).isoformat(),sourcePins=first['before'],windowsTests=7,fixedImageTests=7,
    successfulActualWaits=2,firstFixedImageActualExitCode=1,firstFailurePreserved=True,
    archive='artifacts.zip',archivePin=pin((out/'artifacts.zip').read_bytes()),entries=entries,
    conditionalModelTerms=dict(origin=73729,gateway=409610,collector=532492,phase=1048577,hashPerPayloadOwner=4096),
    componentAccepted=False,actualAggregateAccepted=False,experimentExecuted=False,formalPocAccepted=False)
with (out/'index.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(index,indent=2)+'\n')
paths=['poc/POC-03-ats-range/media_capacity.py','poc/POC-03-ats-range/test_media_capacity.py',
    'specs/tasks/POC-003.md','evidence/POC-003/handoff.md','evidence/POC-003/closed-capacity-v1/artifacts.zip',
    'evidence/POC-003/closed-capacity-v1/index.json']
candidate=dict(parent=parent,repo=str(r),files={p:pin((r/p).read_bytes()) for p in paths},
    componentAccepted=False,actualAggregateAccepted=False,experimentExecuted=False,formalPocAccepted=False)
with (t/'poc003-closed-capacity-v1-current-candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(candidate,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'archiveEntries':len(entries),'archivePin':index['archivePin'],
    'windowsTests':7,'fixedImageTests':7,'actualAggregateAccepted':False}))
