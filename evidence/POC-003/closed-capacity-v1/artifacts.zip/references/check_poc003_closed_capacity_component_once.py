"""Run closed-record unit regressions with exact current selected source snapshots."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1';source=r/'poc/POC-03-ats-range'
out=t/'poc003-closed-capacity-v1';out.mkdir();(out/'source').mkdir()
pins={}
for p in sorted(source.iterdir()):
    if p.is_file() and p.suffix in ('.py','.json'):
        raw=p.read_bytes();pins[p.name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        (out/'source'/p.name).write_bytes(raw)
commands=[('windows',['C:/ProgramData/anaconda3/python.exe','-X','utf8','-B',str(source/'test_media_capacity.py')]),
    ('fixed-image',['docker','run','--rm','--pull','never','--network','none','--read-only','--cap-drop','ALL',
      '--security-opt','no-new-privileges','--user','1000:1000','--pids-limit','32','--memory','256m','--cpus','1',
      '--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=256m,mode=1777',
      '--mount','type=bind,src='+str(source)+',dst=/poc,readonly','--entrypoint','python3',
      'sha256:df18428df8a0f9189c84e7424d214b4c50092af1f9dca5842a00c41c39bda316','-B','/poc/test_media_capacity.py'])]
rows=[]
for name,argv in commands:
    started=datetime.now(timezone.utc).isoformat()
    with (out/(name+'.stdout.raw')).open('xb') as stdout,(out/(name+'.stderr.raw')).open('xb') as stderr:
        child=subprocess.Popen(argv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        code=child.wait()
    output=(out/(name+'.stdout.raw')).read_bytes()+(out/(name+'.stderr.raw')).read_bytes()
    rows.append(dict(name=name,argv=argv,pid=child.pid,startedAt=started,endedAt=datetime.now(timezone.utc).isoformat(),
        exitCode=code,actualWaitCompleted=True,summaryMatched=b'Ran 7 tests' in output,noSkips=b'skipped' not in output))
after={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
       for p in source.iterdir() if p.is_file() and p.suffix in ('.py','.json')}
result=dict(before=pins,after=after,commands=rows,sourceStable=pins==after,syntheticRecordsOnly=True,
            nativeAtsExecuted=False,mediaExperimentExecuted=False,aggregateAccepted=False)
with (out/'results.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
assert pins==after and all(x['exitCode']==0 and x['summaryMatched'] and x['noSkips'] for x in rows)
print(json.dumps({'windowsTests':7,'fixedImageTests':7,'actualWaitZeroCount':2,'sourceStable':True,'aggregateAccepted':False}))
