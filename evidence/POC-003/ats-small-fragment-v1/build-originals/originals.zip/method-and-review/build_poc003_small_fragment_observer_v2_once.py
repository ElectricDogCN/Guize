"""Compile one reviewed exporter candidate; never load/start ATS or run a benchmark."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,signal,subprocess,sys
assert os.name=='posix' and os.getuid()==1000
t=Path(__file__).resolve().parent
p=json.loads((t/'poc003-small-fragment-build-v2-preparation.json').read_bytes())
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(Path(__file__))==p['methodSha256']
approval=t/'poc003-small-fragment-build-v2-independent-approval.json'
a=json.loads(approval.read_bytes())
assert a['componentBuildApproved'] and not a['mustFix'] and a['source']==p['source']
assert a['methodSha256']==p['methodSha256'] and a['maximumActualAttempts']==1
helper=t/'owned_compile_session_v1.py'
assert sha(helper)==p['ownerHelperSha256']==a['ownerHelperSha256']
from owned_compile_session_v1 import run_owned_session
assert datetime.now(timezone.utc)<datetime.fromisoformat('2026-10-29T12:47:06+00:00')
inputs=t/p['inputSnapshot'];assert sha(inputs)==p['inputSnapshotSha256'];i=json.loads(inputs.read_bytes())
bundle=t/p['bundle'];assert bundle.stat().st_size==p['bundleBytes'] and sha(bundle)==p['bundleSha256']
r=Path(p['nativeSource']);build=Path(p['newBuildOutput']);out=t/'poc003-small-fragment-build-v2'
assert not r.exists() and not build.exists() and not build.is_symlink() and not out.exists()
assert sha(i['compilerResolved'])==i['compilerSha256']
assert subprocess.check_output([i['compiler'],'--version'],text=True).splitlines()[0]==i['compilerVersion']
assert {n:sha(Path(i['sdk'])/'ts'/n) for n in i['sdkHeaderSha256']}==i['sdkHeaderSha256']
assert sha(i['oldBuildReceipt'])==i['oldBuildReceiptSha256'] and sha(i['oldPluginPath'])==i['oldPluginSha256']
out.mkdir()
subprocess.run(['git','clone','--quiet','--branch',p['branch'],str(bundle),str(r)],check=True)
assert not (r/'.git/objects/info/alternates').exists()
git=lambda *args:subprocess.check_output(['git','-C',str(r),*args]).decode().strip()
before=dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))
assert before==dict(source=p['source'],tree=p['tree'],status='')
builder=r/'poc/POC-03-ats-range/build_observer.py';cc=builder.with_name('cache_export.cc')
assert sha(builder)==i['builderSha256'] and sha(cc)==i['sourceSha256']
argv=[sys.executable,'-B',str(builder),'--include',i['sdk'],'--out',str(build)]
result=dict(source=p['source'],tree=p['tree'],before=before,argv=argv,approvalSha256=sha(approval),methodSha256=p['methodSha256'],
 startedAt=datetime.now(timezone.utc).isoformat(),actualWaitCompleted=False,builderTimedOut=False,buildCompleted=False,
 atsStarted=False,containerStarted=False,runtimeExecuted=False,experimentApproved=False,dependencyClosureAccepted=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
def record_owner(owner):
    result.update(owner=owner,pid=owner['pid']);save()
with (out/'builder.stdout.raw').open('xb') as stdout,(out/'builder.stderr.raw').open('xb') as stderr:
    owner=run_owned_session(argv,stdout,stderr,130,update=record_owner)
code=owner['exitCode']
assert owner['actualWaitCompleted'] and owner['noLiveOwnedMembers'] and owner['leaderReapedAfterGroupClosure']
result.update(actualWaitCompleted=True,exitCode=code,builderTimedOut=owner['timedOut'],finishedAt=datetime.now(timezone.utc).isoformat());save()
if code or result['builderTimedOut']:raise SystemExit(code or 1)
receipt=build/'receipt.json';b=json.loads(receipt.read_bytes());plugin=build/'cache_export.so'
assert b['exitCode']==0 and b['sourceSha256']==i['sourceSha256'] and b['sdkHeaderSha256']==i['sdkHeaderSha256']
assert b['compiler']==i['compilerVersion'] and b['pluginSha256']==sha(plugin) and b['runtimeExecuted'] is False
assert 0<plugin.stat().st_size<8*1048576
result['staticElfReads']=[]
for label,path in [('new',plugin),('old',Path(i['oldPluginPath']))]:
    for kind,args in [('dynamic',['-d']),('versions',['--version-info'])]:
        cmd=['readelf',*args,str(path)]
        q=subprocess.run(cmd,capture_output=True,timeout=15)
        assert len(q.stdout)+len(q.stderr)<1048576
        name=label+'-'+kind+'.raw';raw=q.stdout+q.stderr;(out/name).write_bytes(raw)
        result['staticElfReads'].append(dict(label=label,kind=kind,argv=cmd,exitCode=q.returncode,actualWaitCompleted=True,raw=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        save();assert q.returncode==0
after=dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))
assert before==after and sha(cc)==i['sourceSha256'] and sha(builder)==i['builderSha256']
assert sha(i['compilerResolved'])==i['compilerSha256'] and {n:sha(Path(i['sdk'])/'ts'/n) for n in i['sdkHeaderSha256']}==i['sdkHeaderSha256']
assert sha(i['oldPluginPath'])==i['oldPluginSha256'] and sha(i['oldBuildReceipt'])==i['oldBuildReceiptSha256']
assert sha(helper)==p['ownerHelperSha256']
result.update(after=after,sourceContextUnchanged=True,buildCompleted=True,buildReceipt=str(receipt),buildReceiptSha256=sha(receipt),
 pluginPath=str(plugin),pluginBytes=plugin.stat().st_size,pluginSha256=sha(plugin),finishedAt=datetime.now(timezone.utc).isoformat())
save();print(json.dumps(result),flush=True)
