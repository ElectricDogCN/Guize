from pathlib import Path
import hashlib,json,subprocess
t=Path(__file__).resolve().parent;r=t/'poc003-feature-actor-import-v1'
assert subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()=='246e264a9674326ffab4a03f11255d8580ea0ee6'
assert not subprocess.check_output(['git','-C',str(r),'status','--porcelain'],text=True).strip()
out=t/'poc003-cache-stream-v1-draft';out.mkdir();pins={}
for name in ['cache_probe.py','test_cache_body_bounds.py','test_payload_lifetime.py']:
    data=(r/'poc/POC-03-ats-range'/name).read_bytes()
    (out/(name+'.preimage')).write_bytes(data)
    pins[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'preimages.json').write_text(json.dumps(pins,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'preimages':len(pins),'source':'246e264a9674326ffab4a03f11255d8580ea0ee6'}))
