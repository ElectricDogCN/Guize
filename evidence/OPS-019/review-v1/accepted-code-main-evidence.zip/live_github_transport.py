"""Temporary live official API transport for WSL's broken localhost DNS mapping."""
import atexit
import hashlib
import http.server
import json
import os
import re
import subprocess
import threading
from datetime import datetime, timezone


def start_bridge(output):
    records = []

    class LiveAPI(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if not re.fullmatch(r'/repos/ElectricDogCN/Guize/issues/[0-9]+', self.path):
                self.send_error(404)
                return
            code = "import sys,urllib.request; req=urllib.request.Request('https://api.github.com'+sys.argv[1],headers={'Accept':'application/vnd.github+json','User-Agent':'guize-live-network-bridge'}); response=urllib.request.urlopen(req,timeout=15); sys.stdout.buffer.write(response.read())"
            try:
                response = subprocess.run(['/mnt/c/ProgramData/anaconda3/python.exe', '-c', code, self.path], capture_output=True, timeout=25)
                record = {'upstream': 'https://api.github.com' + self.path, 'retrievedAt': datetime.now(timezone.utc).isoformat(), 'windowsExitCode': response.returncode, 'sha256': hashlib.sha256(response.stdout).hexdigest()}
                if response.returncode:
                    raise RuntimeError(response.stderr.decode('utf-8', errors='replace'))
                value = json.loads(response.stdout)
                record.update({key: value.get(key) for key in ('number', 'state', 'state_reason', 'updated_at', 'closed_at', 'html_url')})
                records.append(record)
                (output / 'live-official-api.json').write_text(json.dumps(records, indent=2))
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(response.stdout)
            except Exception as exc:
                records.append({'upstream': 'https://api.github.com' + self.path, 'error': str(exc)})
                (output / 'live-official-api.json').write_text(json.dumps(records, indent=2))
                self.send_error(502, 'Live official upstream failed')

        def log_message(self, *_):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), LiveAPI)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    os.environ['GUIZE_GITHUB_API_URL'] = f'http://127.0.0.1:{server.server_port}'
    atexit.register(server.server_close)
    atexit.register(server.shutdown)
    return server
