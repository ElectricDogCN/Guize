from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
out=t/'ops019-implementation-v1-native-specialized-v9'
out.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
tools=Path('/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1')
os.environ.update(PATH=str(tools)+':'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],
    PYTHONDONTWRITEBYTECODE='1',GIT_LFS_SKIP_SMUDGE='1')
r=Path('/home/sur/.cache/guize-takeover/ops019-controlled-lfs-implementation-bb27de37-native-v1')
assert r.exists()
bundle=t/'ops019-controlled-lfs-implementation-v1-source-bb27de37.bundle'
# Reuse only the exact clean unmodified clone from the failed preparation; no tests previously ran.
git=lambda *a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
assert git('status','--porcelain=v1','--untracked-files=all')==''
assert git('rev-parse','HEAD').startswith('2e6ef2d3')
subprocess.run(['git','-C',str(r),'fetch','--no-tags',str(t/'ops019-controlled-lfs-implementation-v1-source-forward-v7.bundle'),'chore/OPS-019-controlled-lfs-delivery'],check=True,capture_output=True)
subprocess.run(['git','-C',str(r),'merge','--ff-only','FETCH_HEAD'],check=True,capture_output=True)
source=git('rev-parse','HEAD')
assert git('status','--porcelain=v1','--untracked-files=all')==''
assert source.startswith('3459ded7') and git('rev-parse','--is-shallow-repository')=='false'
assert not (r/'.git/objects/info/alternates').exists()
subprocess.run(['git','-C',str(r),'config','--local','filter.lfs.process','git-lfs filter-process'],check=True)
subprocess.run(['git','-C',str(r),'config','--local','filter.lfs.required','true'],check=True)
for key,value in [('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f')]:
    subprocess.run(['git','-C',str(r),'config','--local',key,value],check=True)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
original=t/'ops019-controlled-lfs-implementation-v1/.git/lfs/objects'/oid[:2]/oid[2:4]/oid
data=original.read_bytes()
assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
cache=r/'.git/lfs/objects'/oid[:2]/oid[2:4]
assert (cache/oid).read_bytes()==data
os.environ.pop('GIT_LFS_SKIP_SMUDGE')
hydration=subprocess.run(['git','-C',str(r),'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin'],capture_output=True,text=True)
assert hydration.returncode==0,hydration.stderr
(out/'hydration.raw').write_text(hydration.stdout+hydration.stderr)
assert (r/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data
commands=[
 [sys.executable,'-B','-m','compileall','-q','scripts/work-branch-migration.py','tests/governance/test_work_branch_migration.py'],
 [sys.executable,'-B','-m','pytest','-q','tests/governance/test_work_branch_migration.py','--durations=20','--junitxml='+str(out/'junit.xml')],
]
result=dict(source=source,base=git('rev-parse','origin/main'),repo=str(r),startedAt=datetime.now(timezone.utc).isoformat(),localLfsHydration={'actualExitCode':hydration.returncode,'bytes':len(data),'sha256':oid,'origin':'verified local LFS object cache; official remote CI download still required'},commands=[])
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for index,argv in enumerate(commands):
    row=dict(argv=argv,pid=None,raw=f'{index:02d}.raw')
    result['commands'].append(row);save()
    with (out/row['raw']).open('x') as log:
        log.write('Source Commit: '+source+'\nCommand: '+__import__('shlex').join(argv)+'\n');log.flush()
        child=subprocess.Popen(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT)
        row['pid']=child.pid;save()
        code=child.wait()
        log.write('\nExit Code: '+str(code)+'\n')
    raw=(out/row['raw']).read_bytes()
    row.update(exitCode=code,actualWaitCompleted=True,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());save()
    print(str(index)+': exit '+str(code),flush=True)
    if code:raise SystemExit(code)
result.update(finishedAt=datetime.now(timezone.utc).isoformat(),specializedChecksPassed=True)
save()
print(json.dumps({'source':source,'specializedChecksPassed':True}),flush=True)
