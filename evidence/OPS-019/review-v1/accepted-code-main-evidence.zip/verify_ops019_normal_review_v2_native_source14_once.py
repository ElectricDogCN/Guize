"""Fresh native source14 on exact normal Review source; no experiment or CI claim."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,re,shlex,subprocess,sys,time
from live_github_transport import start_bridge
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
c=json.loads((t/'ops019-normal-review-v2-current-candidate.json').read_bytes());source,base,branch=c['source'],c['base'],c['branch']
a=json.loads((t/'ops019-implementation-pr187-final-actual-main-independent-review.json').read_bytes())
assert a['actualMain']==base and a['actualImplementationMainAccepted'] and a['fullMainCiAccepted'] and not a['mustFix']
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=t/'ops019-normal-review-v2-native-source14';out.mkdir()
r=Path('/home/sur/.cache/guize-takeover/ops019-normal-review-v2-native-source-'+source[:7]);assert not r.exists()
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GIT_LFS_SKIP_SMUDGE='1')
full=t/'ops019-implementation-pr187-actual-main-02997dd-full.bundle'
assert full.stat().st_size==129706328
with full.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()=='2334328c68eaaf2f8daaa6782894f2b3338d5e34a0b97cd75146a1e84bcbe328'
increment=t/c['bundle'];assert increment.stat().st_size==c['bundleBytes'] and hashlib.sha256(increment.read_bytes()).hexdigest()==c['bundleSha256']
subprocess.run(['git','clone','--quiet','--branch','main',str(full),str(r)],check=True,timeout=300)
git=lambda *a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
assert git('rev-parse','HEAD')==base and not (r/'.git/objects/info/alternates').exists()
subprocess.run(['git','-C',str(r),'fetch','--no-tags',str(increment),branch],check=True,capture_output=True)
subprocess.run(['git','-C',str(r),'switch','--no-track','-c',branch,'FETCH_HEAD'],check=True,capture_output=True)
assert git('rev-parse','HEAD')==source and git('rev-parse','HEAD^{tree}')==c['tree'] and git('rev-parse','--is-shallow-repository')=='false'
subprocess.run(['git','-C',str(r),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
data=(t/'ops019-implementation-final2e-recovery-chain-v1/lfs-probe.bin').read_bytes();assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
cache=r/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True)
with (cache/oid).open('xb') as f:f.write(data)
for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:
 subprocess.run(['git','-C',str(r),'config','--local',key,value],check=True)
os.environ.pop('GIT_LFS_SKIP_SMUDGE')
hydration=subprocess.run(['git','-C',str(r),'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin'],capture_output=True,text=True)
(out/'hydration.raw').write_text(hydration.stdout+hydration.stderr);assert hydration.returncode==0 and (r/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data
os.environ.update(GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF=branch,GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
start_bridge(out)
state=lambda:dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),branch=git('branch','--show-current'),main=git('rev-parse','main'),originMain=git('rev-parse','origin/main'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state()
assert before['status']=='' and before['main']==before['originMain']==base
fence=chr(96)*3
sections=re.findall(fence+r'bash\n(.*?)\n'+fence,(r/'specs/tasks/OPS-019.md').read_text(),re.S)
assert len(sections)==1
commands=[shlex.split(line) for line in sections[0].splitlines() if line.strip()]
assert len(commands)==14 and commands==c['commands']
frozen=['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md']
for file in frozen:
    assert subprocess.check_output(['git','-C',str(r),'show',base+':'+file])==(r/file).read_bytes()
result=dict(source=source,base=base,branch=branch,before=before,commands=[],startedAt=datetime.now(timezone.utc).isoformat(),declared14Passed=False,fullCiAccepted=False,actualMigrationApproved=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for index,argv in enumerate(commands):
    row=dict(argv=argv,raw=f'{index:02d}.raw',startedAt=datetime.now(timezone.utc).isoformat())
    tick=time.monotonic_ns()
    with (out/row['raw']).open('x',encoding='utf-8',buffering=1) as raw:
        raw.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n')
        child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT)
        row['pid']=child.pid
        result['commands'].append(row);save()
        code=child.wait()
        raw.write('\nExit Code: '+str(code)+'\n')
    data=(out/row['raw']).read_bytes()
    row.update(exitCode=code,actualWaitCompleted=True,elapsedNs=time.monotonic_ns()-tick,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());save()
    print(f'{index:02d}: exit {code}',flush=True)
    if code:
        result.update(after=state(),failedCommandIndex=index);save()
        raise SystemExit(code)
assert state()==before
result.update(after=state(),sourceContextUnchanged=True,declared14Passed=True,finishedAt=datetime.now(timezone.utc).isoformat())
save()
print(json.dumps(dict(source=source,declared14Passed=True,fullCiAccepted=False)),flush=True)
