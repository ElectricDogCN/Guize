"""All 14 declared OPS019 source checks; no CI or migration claim."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,re,shlex,subprocess,sys,time
from live_github_transport import start_bridge
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
special=json.loads((t/'ops019-implementation-v1-native-specialized-v9/results.json').read_bytes())
assert special.get('specializedChecksPassed') is True
assert all(x['actualWaitCompleted'] and x['exitCode']==0 for x in special['commands'])
r=Path(special['repo'])
git=lambda *a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
source=git('rev-parse','HEAD')
base='7d82fb61f434f57bb97cb9d80f4613cee3be2721'
branch='chore/OPS-019-controlled-lfs-delivery'
assert source==special['source'] and source=='3459ded7edd0623908d869cf1d57507896065f16'
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=t/'ops019-implementation-v1-native-source14-v4'
out.mkdir()
assert git('rev-parse','origin/main')==base and git('branch','--show-current')==branch
assert git('rev-parse','main')==base
subprocess.run(['git','-C',str(r),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_HEAD_REF=branch,GITHUB_EVENT_NAME='pull_request',EVENT_NAME='pull_request')
start_bridge(out)
state=lambda:dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),branch=git('branch','--show-current'),main=git('rev-parse','main'),originMain=git('rev-parse','origin/main'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state()
assert before['status']=='' and before['main']==before['originMain']==base
fence=chr(96)*3
sections=re.findall(fence+r'bash\n(.*?)\n'+fence,(r/'specs/tasks/OPS-019.md').read_text(),re.S)
assert len(sections)==1
commands=[shlex.split(line) for line in sections[0].splitlines() if line.strip()]
assert len(commands)==14 and all('1b5c68bab02d98f8e11286d80033585090c7af99' not in item for argv in commands for item in argv)
frozen=['specs/poc/program.schema.yaml','specs/poc/program.yaml','specs/poc/check_program.py','specs/poc/test_program.py','docs/18-testing-and-acceptance.md']
for file in frozen:
    assert subprocess.check_output(['git','-C',str(r),'show',base+':'+file])==(r/file).read_bytes()
result=dict(source=source,base=base,branch=branch,before=before,commands=[],startedAt=datetime.now(timezone.utc).isoformat(),declared14Passed=False,fullCiAccepted=False,actualMigrationApproved=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for index,argv in enumerate(commands):
    row=dict(argv=argv,raw=f'{index:02d}.raw',startedAt=datetime.now(timezone.utc).isoformat())
    tick=time.monotonic_ns()
    with (out/row['raw']).open('x',encoding='utf-8',buffering=1) as raw:
        raw.write('Source Commit: '+source+'\nCommand: '+shlex.join(argv)+'\n')
        child=subprocess.Popen(argv,cwd=r,stdout=raw,stderr=subprocess.STDOUT)
        row['pid']=child.pid
        result['commands'].append(row);save()
        code=child.wait()
        raw.write('\nExit Code: '+str(code)+'\n')
    data=(out/row['raw']).read_bytes()
    row.update(exitCode=code,actualWaitCompleted=True,elapsedNs=time.monotonic_ns()-tick,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());save()
    print(f'{index:02d}: exit {code}',flush=True)
    if code:
        result.update(after=state(),failedCommandIndex=index);save()
        raise SystemExit(code)
assert state()==before
result.update(after=state(),sourceContextUnchanged=True,declared14Passed=True,finishedAt=datetime.now(timezone.utc).isoformat())
save()
print(json.dumps(dict(source=source,declared14Passed=True,fullCiAccepted=False)),flush=True)
