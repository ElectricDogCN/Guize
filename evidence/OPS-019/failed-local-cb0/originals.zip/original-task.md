---
schemaVersion: 2
id: OPS-019
title: Controlled external evidence and bounded work branch migration
titleZh: 大媒体证据外部存储与受限工作分支迁移
type: chore
status: reserved
baseBranch: main
baseSha: 1b5c68bab02d98f8e11286d80033585090c7af99
workBranch: chore/OPS-019-external-evidence-reservation
evidencePath: evidence/OPS-019
issue: 185
workPackage: WP-M0-01
programPlan: specs/coordination/program-plan.yaml
programTaskId: OPS-019
wave: FOUNDATION
requirementIds: REQ-V1-0010
moduleIds: MOD-GOV
producesContracts: []
consumesContracts: CONTRACT-PROGRAM-PLAN,CONTRACT-TASK-SPEC,CONTRACT-ACTIVE-WORK
exitGate: 受控LFS实物校验和唯一POC003两branch字段前瞻迁移正常收口；历史、普通merge、冻结五与全部CI义务保持
taskOwner: ElectricDogCN
coordinator: /root
implementer: /root
reviewer: /root/independent_review
integrator: /root
agentRole: coordinator
riskLevel: high
coordinationMode: registry
coordinationGroup: controlled-evidence-delivery
dependsOn: OPS-017
handoffPath: evidence/OPS-019/handoff.md
integrationStrategy: merge
integrationOrder: 14
leaseExpiresAt: '2026-11-09T23:44:30Z'
---

# OPS-019 metadata-only reservation

## 背景与目标

PR184的有效P1要求大媒体受控外存；当前CI默认不物化LFS，旧分支已有大blob祖先。本任务先登记五条MOD-GOV精确范围，建立LFS实物校验及仅一次POC003工作分支迁移，保留merge策略。此预留不实现、不迁移、不授实验。

## 输入与输出

输入为实际main 1b5c68bab02d98f8e11286d80033585090c7af99、P1独立评估和只读修复路线。输出仅自身Program/Registry/Task/Evidence及不可变delivery-migration-intent.json。原CI940成功保持原归属。

## 允许范围

预留阶段只写自身元数据及Evidence。预留真实主线完整接受后才实现五条路径。

## 独占写范围

- `.github/workflows/governance-gate.yml`
- `scripts/check-program-plan-history.py`
- `scripts/check-program-plan-transitions.py`
- `scripts/work-branch-migration.py`
- `tests/governance/test_work_branch_migration.py`

## 共享修改范围

无。

## 禁止范围

不改冻结五、POC计划/策略/样本/阈值、现有原842断言、原action pin/30分钟/runner、旧授权或完成身份。预留与实现期间不改两个POC的身份/状态/branch/base/角色/租约/claims，不直接迁移，不变integrationStrategy，不删除原件或重写refs，不冒充新源测量。无OPS017引导例外或OPS018修复授权。

## 依赖与集成顺序

依赖已正常完成OPS017。当前2 active/0 high，预留后3 active/1 high；order14；租约2026-11-02T23:44:30Z至2026-11-09T23:44:30Z。逐阶段原14及完整官方CI、独立审查、实际主线接受后前进。仅本Foundation正常完成及高容量释放后的未来独立metadata事务可迁移指定两branch字段；真实原始意图/父基线/实现/Review/Completion与全历史须证明。

## 协作与交接

Owner ElectricDogCN，Coordinator/Implementer/Integrator /root，独立Reviewer /root/independent_review。Task2/Program1/Registry1及模块所有权保持。Handoff保存实际SHA、路径、真实命令/退出码和下一角色动作。

## 验收标准

- [ ] metadata-only预留、五claims、独立角色、原始意图与有效容量合法。
- [ ] 真实LFS小探针在完整CI物化并按SHA核验，原842与默认严格行为保持。
- [ ] 唯一POC003前瞻两branch字段迁移具备真实Git正反例；拒未完成authority、改写/晚补intent、侧分支、错字段/任务/branch、过期/非独立或第二次事务。
- [ ] 正常Review/Completion及精确源/实际main完整CI全部通过；旧raw/refs保留、无source结果移绑。

## 必须执行的测试

```bash
git diff --check 1b5c68bab02d98f8e11286d80033585090c7af99...HEAD
python scripts/check-task-file.py --task OPS-019
python scripts/check-schemas.py
python scripts/check-program-plan-integrity.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99
python scripts/check-program-plan-history.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019 --branch-name chore/OPS-019-external-evidence-reservation
python scripts/check-program-plan-transitions.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019 --branch-name chore/OPS-019-external-evidence-reservation
python scripts/check-program-lifecycle-guards.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019 --branch-name chore/OPS-019-external-evidence-reservation
python scripts/run-program-lifecycle-gate.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019 --branch-name chore/OPS-019-external-evidence-reservation
python scripts/run-agent-coordination-gate.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019 --branch-name chore/OPS-019-external-evidence-reservation
python scripts/check-program-plan-finalization.py --base-ref 1b5c68bab02d98f8e11286d80033585090c7af99 --head-ref HEAD --task OPS-019
python scripts/run-task-scope-gate.py --task OPS-019 --base 1b5c68bab02d98f8e11286d80033585090c7af99
python scripts/check-evidence.py --task OPS-019
python scripts/check-project-readiness.py
python scripts/check-markdown.py
```

准备时UNEXECUTED。实现阶段增加必要真实Git回归及实际LFS探针，全部原842保持；不降低门禁。

## Evidence

标准summary/commands/handoff/changed-files与prerequisites提供真实输入。

## 风险

分支迁移与LFS物化不能隐式授旧测试对新源适用性。未来POC需新accepted anchor、新批准及真实重测；POC005原未测物理资源只能另行前瞻接受。

## 回滚

未合并撤回；合并后受审前向修复或正常释放，保留所有原始资料及Git引用，禁止reset/rebase/amend/force。
