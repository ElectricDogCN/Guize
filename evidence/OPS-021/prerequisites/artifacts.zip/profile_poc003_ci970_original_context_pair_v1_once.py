"""Four unmodified original-case runs: accepted C vs exact CI virtual commit."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,shlex,shutil,subprocess,sys,time
import xml.etree.ElementTree as ET
from live_github_transport import start_bridge
assert os.name=='posix' and os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
c=json.loads((t/'poc003-ci970-virtual-context-carrier-v1-result.json').read_bytes())
assert c['exactGitOidMatchedBeforeWrite'] and not c['canonicalOrSourceAuthorModified']
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert shutil.disk_usage('/home/sur/.cache/guize-takeover').free>=10*1024**3
out=t/'poc003-ci970-original-context-pair-profile-v1';out.mkdir()
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',GIT_LFS_SKIP_SMUDGE='1')
for key in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','GITHUB_REF_NAME','PYTHONHOME'):os.environ.pop(key,None)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
full=t/c['baseBundle'];inc=t/c['incrementBundle']
assert full.stat().st_size==c['baseBundleBytes'] and sha(full)==c['baseBundleSha256']
assert inc.stat().st_size==c['incrementBytes'] and sha(inc)==c['incrementSha256']
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
def state(root):return dict(head=git(root,'rev-parse','HEAD'),tree=git(root,'rev-parse','HEAD^{tree}'),parents=git(root,'show','-s','--format=%P','HEAD').split(),branch=git(root,'branch','--show-current'),originMain=git(root,'rev-parse','origin/main'),refs=git(root,'for-each-ref','--format=%(refname) %(objectname)'),status=git(root,'status','--porcelain=v1','--untracked-files=all'))
roots=[]
for label,head in [('accepted-C',c['base']),('ci970-virtual',c['virtualCommit'])]:
 root=Path('/home/sur/.cache/guize-takeover/poc003-ci970-original-profile-v1-'+label);assert not root.exists()
 subprocess.run(['git','clone','--quiet','--branch','main',str(full),str(root)],check=True,timeout=300)
 if label=='ci970-virtual':
  subprocess.run(['git','-C',str(root),'fetch','--no-tags',str(inc),c['diagnosticRef']],check=True,capture_output=True)
  assert git(root,'rev-parse','FETCH_HEAD')==head
 subprocess.run(['git','-C',str(root),'checkout','--detach',head],check=True,capture_output=True)
 subprocess.run(['git','-C',str(root),'remote','set-url','origin','https://github.com/ElectricDogCN/Guize.git'],check=True)
 assert not (root/'.git/objects/info/alternates').exists()
 oid='f965b526538d757ca2d6114af6517c57cbcb3650b71d8cfb92046a04ef2f566b'
 data=(t/'ops020-blocked-recovery-implementation-v1/evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes();assert len(data)==4096 and hashlib.sha256(data).hexdigest()==oid
 cache=root/'.git/lfs/objects'/oid[:2]/oid[2:4];cache.mkdir(parents=True,exist_ok=True)
 with (cache/oid).open('xb') as f:f.write(data)
 for key,value in [('filter.lfs.process','git-lfs filter-process'),('filter.lfs.clean','git-lfs clean -- %f'),('filter.lfs.smudge','git-lfs smudge -- %f'),('filter.lfs.required','true')]:subprocess.run(['git','-C',str(root),'config','--local',key,value],check=True)
 subprocess.run(['git','-C',str(root),'lfs','checkout','evidence/OPS-019/implementation-v1/lfs-probe.bin'],check=True,capture_output=True)
 assert (root/'evidence/OPS-019/implementation-v1/lfs-probe.bin').read_bytes()==data
 before=state(root);assert before['head']==head and before['originMain']==c['base'] and before['branch']=='' and not before['status']
 if label=='ci970-virtual':assert before['parents']==[c['base'],c['source']] and before['tree']==c['tree']
 roots.append((label,head,root,before))
os.environ.pop('GIT_LFS_SKIP_SMUDGE')
assert roots[0][3]['refs']==roots[1][3]['refs']
cases=[('real-current-transitions','tests/governance/test_program_plan_transitions.py::TestProgramPlanTransitions::test_current_repository_passes'),('fixed-historical-metadata','tests/governance/test_active_metadata_scope.py::test_metadata_permission_rejects_unauthorized_changes[program-policy]')]
inputs={}
for _,case in cases:
 path=case.split('::')[0];assert (roots[0][2]/path).read_bytes()==(roots[1][2]/path).read_bytes();inputs[path]=sha(roots[0][2]/path)
for path in ['scripts/check-agent-coordination.py','scripts/check-task-scope.py','scripts/check-program-plan-transitions.py','scripts/check-program-plan-history.py','scripts/work-branch-migration.py','.github/workflows/governance-gate.yml']:
 assert (roots[0][2]/path).read_bytes()==(roots[1][2]/path).read_bytes();inputs[path]=sha(roots[0][2]/path)
start_bridge(out)
result=dict(kind='PAIRED_ORIGINAL_CASE_CONTEXT_DIAGNOSTIC_NOT_OFFICIAL_CI',startedAt=datetime.now(timezone.utc).isoformat(),base=c['base'],source=c['source'],exactCiVirtual=c['virtualCommit'],ciTree=c['tree'],inputs=inputs,commands=[],sameHostAndInterpreter=True,python=sys.version,assertionsOrProductionChanged=False,officialCiRerunRequested=False,uniqueCloudCauseClaimed=False,publicCiContextOnly=True,providerCredentialsCopied=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for short,case in cases:
 for label,head,root,initial in roots:
  before=state(root);assert before==initial
  env=dict(os.environ,GITHUB_ACTIONS='true',CI='true',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_EVENT_NAME='pull_request',GITHUB_HEAD_REF='chore/POC-003-qualified-lfs-evidence-v2',GITHUB_BASE_REF='main',GITHUB_REF='refs/pull/200/merge',GITHUB_REF_NAME='200/merge',GITHUB_SHA=head,GITHUB_WORKSPACE=str(root))
  prefix=short+'-'+label;profile=out/(prefix+'.pstats');raw=out/(prefix+'.raw');junit=out/(prefix+'.xml')
  argv=[sys.executable,'-B','-m','cProfile','-o',str(profile),'-m','pytest','-q',case,'--durations=10','--junitxml='+str(junit)]
  row=dict(case=case,label=label,source=head,root=str(root),before=before,argv=argv,publicCiEnv={key:env[key] for key in ('GITHUB_EVENT_NAME','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_REF','GITHUB_SHA')},startedAt=datetime.now(timezone.utc).isoformat());result['commands'].append(row);save();tick=time.monotonic()
  with raw.open('x',encoding='utf-8',buffering=1) as stream:
   stream.write('Source Commit: '+head+'\nCommand: '+shlex.join(argv)+'\n');child=subprocess.Popen(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait();stream.write('\nExit Code: '+str(code)+'\n')
  row.update(exitCode=code,actualWaitCompleted=True,elapsedSeconds=time.monotonic()-tick,rawFile=raw.name,rawBytes=raw.stat().st_size,rawSha256=sha(raw),after=state(root));save()
  assert code==0 and row['after']==before
  testcases=list(ET.fromstring(junit.read_bytes()).iter('testcase'));assert len(testcases)==1 and not any(x.find(tag) is not None for x in testcases for tag in ('failure','error','skipped'))
  stats=pstats.Stats(str(profile));ranking=sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)
  row.update(junitFile=junit.name,junitBytes=junit.stat().st_size,junitSha256=sha(junit),junitCases=1,profileBytes=profile.stat().st_size,profileSha256=sha(profile),topFunctions=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in ranking[:25]])
  save();print(json.dumps(dict(case=short,context=label,exitCode=code,elapsedSeconds=row['elapsedSeconds'])),flush=True)
result.update(finishedAt=datetime.now(timezone.utc).isoformat(),allFourOriginalCasesPassed=True,sourceAndReferencesUnchanged=True);save()
