"""Instrument the original real-current-repository checker's cost, without edits."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,shlex,subprocess,sys,time
from live_github_transport import start_bridge
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
t=Path(__file__).resolve().parent
paired=json.loads((t/'poc003-ci970-original-context-pair-profile-v1/results.json').read_bytes())
assert paired['allFourOriginalCasesPassed'] and paired['sourceAndReferencesUnchanged']
subject=next(x for x in paired['commands'] if x['label']=='ci970-virtual' and 'test_current_repository_passes' in x['case'])
r=Path(subject['root']);S=subject['source'];assert S=='67bd11a7ac504f76083ebd584498654e73f13382'
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=t/'poc003-ci970-transition-child-profile-v1';out.mkdir()
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
for key in ('GITHUB_TOKEN','GIT_LFS_SKIP_SMUDGE','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):os.environ.pop(key,None)
os.environ.update(subject['publicCiEnv'],GITHUB_ACTIONS='true',CI='true',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_REF_NAME='200/merge',GITHUB_WORKSPACE=str(r))
start_bridge(out)
git=lambda *a:subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
state=lambda:dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),parents=git('show','-s','--format=%P','HEAD').split(),branch=git('branch','--show-current'),originMain=git('rev-parse','origin/main'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'))
before=state();assert before==subject['after'] and before['head']==S
profile=out/'transition-child.pstats';raw=out/'transition-child.raw'
argv=[sys.executable,'-B','-m','cProfile','-o',str(profile),str(r/'scripts/check-program-plan-transitions.py'),'--repo-root',str(r),'--base-ref','origin/main','--head-ref','HEAD','--task','GZ-014','--branch-name','chore/GZ-014-post-merge-review-repair']
result=dict(kind='INSTRUMENTED_ORIGINAL_CHECKER_COST_ONLY',source=S,tree=before['tree'],before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),productionOrTestsChanged=False,officialCiRerunRequested=False,thirdAttemptAuthorized=False,untracedTimingClaimed=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save();tick=time.monotonic()
with raw.open('x',encoding='utf-8',buffering=1) as stream:
 stream.write('Source Commit: '+S+'\nCommand: '+shlex.join(argv)+'\n');child=subprocess.Popen(argv,cwd=r,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait();stream.write('\nExit Code: '+str(code)+'\n')
result.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=raw.stat().st_size,rawSha256=hashlib.sha256(raw.read_bytes()).hexdigest(),after=state());save();assert code==0 and result['after']==before
stats=pstats.Stats(str(profile));ranking=sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)
rows=[dict(file=k[0],line=k[1],function=k[2],primitiveCalls=v[0],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in ranking]
result.update(profileBytes=profile.stat().st_size,profileSha256=hashlib.sha256(profile.read_bytes()).hexdigest(),topFunctions=rows[:45],governanceFunctions=[x for x in rows if '/scripts/' in x['file']],finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(exitCode=code,seconds=result['elapsedSeconds'],topFunctions=rows[:15])),flush=True)
