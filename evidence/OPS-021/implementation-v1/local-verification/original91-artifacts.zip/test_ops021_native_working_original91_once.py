from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,shlex,subprocess,sys,time,xml.etree.ElementTree as ET
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
T=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();new=json.loads((T/'ops021-implementation-v1-native-working-tests-v2/results.json').read_bytes())
assert new['newTestsAccepted'] and new['exitCode']==0 and new['before']==new['after']
R=Path(new['nativeRepo']);c=json.loads((T/new['snapshotFile']).read_bytes());assert sha((T/new['snapshotFile']).read_bytes())==new['snapshotSha256']
O=T/'ops021-implementation-v1-native-working-original91-v2';O.mkdir()
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
for k in ('GITHUB_TOKEN','GITHUB_HEAD_REF','GITHUB_BASE_REF','GITHUB_EVENT_NAME','GITHUB_REF_NAME','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):os.environ.pop(k,None)
git=lambda *x:subprocess.check_output(['git','-C',str(R),*x]).decode().strip()
def state():return dict(head=git('rev-parse','HEAD'),branch=git('branch','--show-current'),refs=git('for-each-ref','--format=%(refname) %(objectname)'),status=git('status','--porcelain=v1','--untracked-files=all'),pins=[dict(path=p['path'],sha256=sha((R/p['path']).read_bytes())) for p in c['fileSnapshot']])
before=state();assert before==new['after']
path='tests/governance/test_work_branch_migration.py';assert (R/path).read_bytes()==subprocess.check_output(['git','-C',str(R),'show',c['base']+':'+path])
argv=[sys.executable,'-B','-m','pytest','-q',path,'--junitxml='+str(O/'original91.xml')]
result=dict(kind='ORIGINAL91_UNCOMMITTED_WORKING_SNAPSHOT',base=c['base'],workingSnapshot=new['snapshotFile'],workingSnapshotSha256=new['snapshotSha256'],nativeRepo=str(R),before=before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),actualWaitCompleted=False,original91Accepted=False,sourceCommitted=False,fullCiAccepted=False)
save=lambda:(O/'results.json').write_text(json.dumps(result,indent=2)+'\n');save();tick=time.monotonic()
with (O/'original91.raw').open('x',encoding='utf-8',buffering=1) as stream:
    stream.write('Source Code Commit: '+c['base']+'\nWorking Tree Snapshot SHA256: '+new['snapshotSha256']+'\nCommand: '+shlex.join(argv)+'\n')
    child=subprocess.Popen(argv,cwd=R,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait();stream.write('\nExit Code: '+str(code)+'\n')
data=(O/'original91.raw').read_bytes();result.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=len(data),rawSha256=sha(data),after=state());save()
assert before==result['after'];tree=ET.parse(O/'original91.xml');cases=tree.findall('.//testcase');bad=tree.findall('.//failure')+tree.findall('.//error')+tree.findall('.//skipped');result.update(testCases=len(cases),failedErroredSkipped=len(bad));save();assert code==0 and len(cases)==91 and not bad
result.update(original91Accepted=True,finishedAt=datetime.now(timezone.utc).isoformat());save();print(json.dumps(dict(actualWaitCompleted=True,exitCode=code,original91Passed=True,testCases=91,elapsedSeconds=result['elapsedSeconds'],fullCiAccepted=False)),flush=True)
