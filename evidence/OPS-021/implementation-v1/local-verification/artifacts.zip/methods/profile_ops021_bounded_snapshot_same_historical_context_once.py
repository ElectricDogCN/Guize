"""One instrumented new-checker run against unchanged old67 repository context."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,pstats,shlex,subprocess,sys,time
from live_github_transport import start_bridge
assert os.getuid()==1000 and sys.version_info[:3]==(3,11,17)
T=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
tested=json.loads((T/'ops021-implementation-v1-native-working-tests-v2/results.json').read_bytes())
assert tested['newTestsAccepted'] and tested['actualWaitCompleted'] and tested['exitCode']==0 and tested['before']==tested['after'] and tested['testCases']==21 and tested['failedErroredSkipped']==0
snapshot=T/tested['snapshotFile'];assert sha(snapshot.read_bytes())==tested['snapshotSha256'];c=json.loads(snapshot.read_bytes());checker=Path(tested['nativeRepo'])
index=json.loads((T.parent/'Guize/evidence/OPS-021/prerequisites/index.json').read_bytes())
baseline_name='poc003-ci970-transition-child-profile-v1/results.json';pin=next(x for x in index['records'] if x['path']==baseline_name)
raw=(T/baseline_name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];baseline=json.loads(raw)
assert baseline['actualWaitCompleted'] and baseline['exitCode']==0 and baseline['before']==baseline['after']
# Select the actual preserved context by source, rather than command ordering.
pair=json.loads((T/'poc003-ci970-original-context-pair-profile-v1/results.json').read_bytes())
old=Path(next(x['root'] for x in pair['commands'] if x['source']=='67bd11a7ac504f76083ebd584498654e73f13382'))
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
def old_state():return dict(head=git(old,'rev-parse','HEAD'),tree=git(old,'rev-parse','HEAD^{tree}'),parents=git(old,'show','-s','--format=%P','HEAD').split(),branch=git(old,'branch','--show-current'),originMain=git(old,'rev-parse','origin/main'),refs=git(old,'for-each-ref','--format=%(refname) %(objectname)'),status=git(old,'status','--porcelain=v1','--untracked-files=all'))
def checker_state():return dict(head=git(checker,'rev-parse','HEAD'),branch=git(checker,'branch','--show-current'),refs=git(checker,'for-each-ref','--format=%(refname) %(objectname)'),status=git(checker,'status','--porcelain=v1','--untracked-files=all'),pins=[dict(path=p['path'],sha256=sha((checker/p['path']).read_bytes())) for p in c['fileSnapshot']])
before=old_state();code_before=checker_state();assert before==baseline['after'] and before['head']=='67bd11a7ac504f76083ebd584498654e73f13382'
assert code_before['head']==c['base'] and code_before['pins']==tested['after']['pins']
surrounding=[]
for file in sorted((checker/'scripts').glob('*.py')):
    relative=file.relative_to(checker).as_posix()
    if relative=='scripts/check-program-plan-history.py':continue
    payload=file.read_bytes();assert payload==(old/relative).read_bytes();surrounding.append(dict(path=relative,sha256=sha(payload)))
for p in c['fileSnapshot']:assert sha((checker/p['path']).read_bytes())==p['sha256']
lock=Path('/home/sur/.cache/guize-takeover/guize-performance-domain.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=T/'ops021-bounded-snapshot-fixed67-instrumented-profile-v1';out.mkdir()
subject=next(x for x in pair['commands'] if x['source']==before['head'] and 'test_current_repository_passes' in x['case'])
for k in ('GITHUB_TOKEN','GIT_LFS_SKIP_SMUDGE','EVENT_NAME','PUSH_BEFORE','BASE_SHA','HEAD_SHA','TASK_ID','BRANCH_NAME','GUIZE_GITHUB_API_URL','PYTHONHOME'):os.environ.pop(k,None)
os.environ.update(PATH='/home/sur/.cache/guize-takeover/git-lfs-3.8.1-private-v1:'+str(Path(sys.executable).parent)+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
os.environ.update(subject['publicCiEnv'])
os.environ.update(GITHUB_ACTIONS='true',CI='true',GITHUB_REPOSITORY='ElectricDogCN/Guize',GITHUB_REF_NAME='200/merge',GITHUB_WORKSPACE=str(old))
start_bridge(out)
argv=[sys.executable,'-B','-m','cProfile','-o',str(out/'transition-child.pstats'),str(checker/'scripts/check-program-plan-transitions.py'),'--repo-root',str(old),'--base-ref','origin/main','--head-ref','HEAD','--task','GZ-014','--branch-name','chore/GZ-014-post-merge-review-repair']
result=dict(kind='INSTRUMENTED_CHECKER_CHANGE_AGAINST_FIXED_OLD_CONTEXT_ONLY',checkedRepositorySource=before['head'],checkerGitBase=c['base'],checkerWorkingSnapshot=tested['snapshotFile'],checkerWorkingSnapshotSha256=tested['snapshotSha256'],checkerUncommitted=True,checkerHistorySha256=sha((checker/'scripts/check-program-plan-history.py').read_bytes()),surroundingScripts=surrounding,baselineResult=baseline_name,baselineResultSha256=pin['sha256'],baselineInstrumentedSeconds=baseline['elapsedSeconds'],before=before,checkerBefore=code_before,argv=argv,startedAt=datetime.now(timezone.utc).isoformat(),actualWaitCompleted=False,officialCiAccepted=False,untracedTimingClaimed=False)
save=lambda:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');save();tick=time.monotonic()
with (out/'transition-child.raw').open('x',encoding='utf-8',buffering=1) as stream:
    stream.write('Checked Repository Commit: '+before['head']+'\nChecker Base Commit: '+c['base']+'\nChecker Working Snapshot SHA256: '+tested['snapshotSha256']+'\nCommand: '+shlex.join(argv)+'\n')
    child=subprocess.Popen(argv,cwd=old,stdout=stream,stderr=subprocess.STDOUT);result['pid']=child.pid;save();code=child.wait();stream.write('\nExit Code: '+str(code)+'\n')
data=(out/'transition-child.raw').read_bytes();result.update(actualWaitCompleted=True,exitCode=code,elapsedSeconds=time.monotonic()-tick,rawBytes=len(data),rawSha256=sha(data),after=old_state(),checkerAfter=checker_state());save()
assert code==0 and result['before']==result['after'] and result['checkerBefore']==result['checkerAfter']
stats=pstats.Stats(str(out/'transition-child.pstats'));rows=[dict(file=k[0],line=k[1],function=k[2],calls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3]) for k,v in sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)]
profile=(out/'transition-child.pstats').read_bytes();result.update(profileBytes=len(profile),profileSha256=sha(profile),topFunctions=rows[:25],governanceFunctions=[x for x in rows if '/scripts/' in x['file']],finishedAt=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(actualWaitCompleted=True,exitCode=code,instrumentedSeconds=result['elapsedSeconds'],baselineInstrumentedSeconds=baseline['elapsedSeconds'],checkout=[x for x in rows if x['function']=='checkout_task_snapshot'],checkedContextUnchanged=True,checkerUncommitted=True,officialCiAccepted=False)),flush=True)
