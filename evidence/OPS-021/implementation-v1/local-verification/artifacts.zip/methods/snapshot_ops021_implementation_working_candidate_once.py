from pathlib import Path
from datetime import datetime,timezone
import argparse,ast,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('--version',required=True);a=p.parse_args();assert a.version in {'v1','v2','v3'}
T=Path(__file__).resolve().parent;c=json.loads((T/'ops021-implementation-v1-source-copy.json').read_bytes());R=Path(c['author']);B=c['base'];sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *x:subprocess.check_output(['git','-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(R),*x])
dec=lambda *x:git(*x).decode().strip()
assert dec('rev-parse','HEAD')==B and dec('branch','--show-current')==c['branch'] and not dec('diff','--cached','--name-only')
paths=sorted(set(dec('diff','--name-only').splitlines())|set(dec('ls-files','--others','--exclude-standard').splitlines()))
code=['scripts/check-program-plan-history.py','tests/governance/test_historical_task_snapshot.py']
assert all(x in set(code+['specs/tasks/OPS-021.md','specs/coordination/program-plan.yaml','specs/coordination/active-work.yaml']) or x.startswith('evidence/OPS-021/') for x in paths)
for name in paths:
    if Path(name).suffix in {'.py','.yaml','.json','.txt','.md'}:
        file=R/name;data=file.read_bytes()
        if b'\r\n' in data:file.write_bytes(data.replace(b'\r\n',b'\n'))
for name in code:ast.parse((R/name).read_text(encoding='utf-8'))
old=git('show',B+':'+code[0]);new=(R/code[0]).read_bytes();start=b'def checkout_task_snapshot(';end=b'\ndef historical_task_snapshot('
before=old.split(start,1);after=new.split(start,1)
assert len(before)==len(after)==2 and before[0]==after[0] and before[1].split(end,1)[1]==after[1].split(end,1)[1]
assert (R/'specs/tasks/OPS-021.md').read_bytes().split(b'---',2)[2]==git('show',B+':specs/tasks/OPS-021.md').split(b'---',2)[2]
for pin in c['sourcePins']:
    if pin['path'] not in paths:assert (R/pin['path']).read_bytes()==git('show',B+':'+pin['path'])
assert (R/'tests/governance/test_work_branch_migration.py').read_bytes()==git('show',B+':tests/governance/test_work_branch_migration.py')
record=dict(kind='UNCOMMITTED_WORKING_TREE_SNAPSHOT',version=a.version,base=B,branch=c['branch'],author=str(R),parentFinalReceiptSha256=c['parentFinalReceiptSha256'],changedPaths=paths,fileSnapshot=[dict(path=x,bytes=(R/x).stat().st_size,sha256=sha((R/x).read_bytes())) for x in paths],historyOnlyCheckoutHelperChanged=True,original91Unchanged=True,otherTestsUnchanged=True,frozenUnchanged=True,originalTaskBodyUnchanged=True,sourceCommitted=False,newTestsExecuted=False,fullCiAccepted=False,createdAt=datetime.now(timezone.utc).isoformat())
out=T/('ops021-implementation-v1-working-candidate-'+a.version+'.json')
with out.open('x',encoding='utf-8') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(candidate=out.name,bytes=out.stat().st_size,sha256=sha(out.read_bytes()),changedPaths=len(paths),original91Unchanged=True,sourceCommitted=False)))
